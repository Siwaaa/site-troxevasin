const interopDefault = r => r.default || r || [];
const styles = {
  "pages/capsules.vue": () => import('./_nuxt/capsules-styles.afc60757.mjs').then(interopDefault),
  "pages/case-hemorrhoids.vue": () => import('./_nuxt/case-hemorrhoids-styles.26e57a24.mjs').then(interopDefault),
  "pages/case-varikoz-hard.vue": () => import('./_nuxt/case-varikoz-hard-styles.1ea5be73.mjs').then(interopDefault),
  "pages/case-varikoz-lite.vue": () => import('./_nuxt/case-varikoz-lite-styles.5e5b3642.mjs').then(interopDefault),
  "pages/case-varikoz-middle.vue": () => import('./_nuxt/case-varikoz-middle-styles.504f7610.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.fe1b4509.mjs').then(interopDefault),
  "pages/gel.vue": () => import('./_nuxt/gel-styles.b35c4eeb.mjs').then(interopDefault),
  "pages/neo.vue": () => import('./_nuxt/neo-styles.318905d6.mjs').then(interopDefault),
  "pages/troxactive.vue": () => import('./_nuxt/troxactive-styles.174b87d0.mjs').then(interopDefault),
  "components/Button.vue": () => import('./_nuxt/Button-styles.169685b9.mjs').then(interopDefault),
  "components/modal/Uteka.vue": () => import('./_nuxt/Uteka-styles.b3db05ea.mjs').then(interopDefault),
  "components/modal/Hemorrhoids.vue": () => import('./_nuxt/Hemorrhoids-styles.beee2b99.mjs').then(interopDefault),
  "components/modal/Moff.vue": () => import('./_nuxt/Moff-styles.805d2d94.mjs').then(interopDefault),
  "components/MedInfo.vue": () => import('./_nuxt/MedInfo-styles.94a6b4bb.mjs').then(interopDefault),
  "components/Cart.vue": () => import('./_nuxt/Cart-styles.3e7eeb40.mjs').then(interopDefault),
  "components/Footer.vue": () => import('./_nuxt/Footer-styles.a2a7c1d4.mjs').then(interopDefault),
  "components/Navbar.vue": () => import('./_nuxt/Navbar-styles.6fb5e8f6.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.b525e333.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.030a513c.mjs').then(interopDefault),
  "components/BannerTeva.vue": () => import('./_nuxt/BannerTeva-styles.12043721.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
