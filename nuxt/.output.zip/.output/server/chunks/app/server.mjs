import { version, getCurrentInstance, inject, ref, watchEffect, watch, defineComponent, computed, h, resolveComponent, mergeProps, useSSRContext, createApp, reactive, unref, isRef, provide, onErrorCaptured, onServerPrefetch, toRef, shallowRef, isReadonly, defineAsyncComponent, nextTick, withCtx, createVNode, createTextVNode, openBlock, createBlock, Suspense, Transition } from 'vue';
import { $fetch } from 'ofetch';
import { createHooks } from 'hookable';
import { getContext, executeAsync } from 'unctx';
import { renderSSRHead } from '@unhead/ssr';
import { composableNames, getActiveHead, createServerHead as createServerHead$1 } from 'unhead';
import { HasElementTags, defineHeadPlugin } from '@unhead/shared';
import { createMemoryHistory, createRouter, RouterView } from 'vue-router';
import { createError as createError$1, sendRedirect } from 'h3';
import { hasProtocol, parseURL, parseQuery, withTrailingSlash, withoutTrailingSlash, joinURL, isEqual } from 'ufo';
import { ssrRenderAttrs, ssrRenderSlot, ssrInterpolate, ssrRenderAttr, ssrRenderSuspense, ssrRenderComponent, ssrRenderClass, ssrRenderStyle } from 'vue/server-renderer';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Navigation } from 'swiper';
import { defu } from 'defu';
import { a as useRuntimeConfig$1 } from '../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const appConfig = useRuntimeConfig$1().app;
const baseURL = () => appConfig.baseURL;
const nuxtAppCtx = /* @__PURE__ */ getContext("nuxt-app");
const NuxtPluginIndicator = "__nuxt_plugin";
function createNuxtApp(options) {
  let hydratingCount = 0;
  const nuxtApp = {
    provide: void 0,
    globalName: "nuxt",
    versions: {
      get nuxt() {
        return "3.3.1";
      },
      get vue() {
        return nuxtApp.vueApp.version;
      }
    },
    payload: reactive({
      data: {},
      state: {},
      _errors: {},
      ...{ serverRendered: true }
    }),
    static: {
      data: {}
    },
    isHydrating: false,
    deferHydration() {
      if (!nuxtApp.isHydrating) {
        return () => {
        };
      }
      hydratingCount++;
      let called = false;
      return () => {
        if (called) {
          return;
        }
        called = true;
        hydratingCount--;
        if (hydratingCount === 0) {
          nuxtApp.isHydrating = false;
          return nuxtApp.callHook("app:suspense:resolve");
        }
      };
    },
    _asyncDataPromises: {},
    _asyncData: {},
    ...options
  };
  nuxtApp.hooks = createHooks();
  nuxtApp.hook = nuxtApp.hooks.hook;
  nuxtApp.callHook = nuxtApp.hooks.callHook;
  nuxtApp.provide = (name, value) => {
    const $name = "$" + name;
    defineGetter(nuxtApp, $name, value);
    defineGetter(nuxtApp.vueApp.config.globalProperties, $name, value);
  };
  defineGetter(nuxtApp.vueApp, "$nuxt", nuxtApp);
  defineGetter(nuxtApp.vueApp.config.globalProperties, "$nuxt", nuxtApp);
  {
    if (nuxtApp.ssrContext) {
      nuxtApp.ssrContext.nuxt = nuxtApp;
    }
    nuxtApp.ssrContext = nuxtApp.ssrContext || {};
    if (nuxtApp.ssrContext.payload) {
      Object.assign(nuxtApp.payload, nuxtApp.ssrContext.payload);
    }
    nuxtApp.ssrContext.payload = nuxtApp.payload;
    nuxtApp.payload.config = {
      public: options.ssrContext.runtimeConfig.public,
      app: options.ssrContext.runtimeConfig.app
    };
  }
  const runtimeConfig = options.ssrContext.runtimeConfig;
  const compatibilityConfig = new Proxy(runtimeConfig, {
    get(target, prop) {
      if (prop === "public") {
        return target.public;
      }
      return target[prop] ?? target.public[prop];
    },
    set(target, prop, value) {
      {
        return false;
      }
    }
  });
  nuxtApp.provide("config", compatibilityConfig);
  return nuxtApp;
}
async function applyPlugin(nuxtApp, plugin) {
  if (typeof plugin !== "function") {
    return;
  }
  const { provide: provide2 } = await callWithNuxt(nuxtApp, plugin, [nuxtApp]) || {};
  if (provide2 && typeof provide2 === "object") {
    for (const key in provide2) {
      nuxtApp.provide(key, provide2[key]);
    }
  }
}
async function applyPlugins(nuxtApp, plugins2) {
  for (const plugin of plugins2) {
    await applyPlugin(nuxtApp, plugin);
  }
}
function normalizePlugins(_plugins2) {
  const plugins2 = _plugins2.map((plugin) => {
    if (typeof plugin !== "function") {
      return null;
    }
    if (plugin.length > 1) {
      return (nuxtApp) => plugin(nuxtApp, nuxtApp.provide);
    }
    return plugin;
  }).filter(Boolean);
  return plugins2;
}
function defineNuxtPlugin(plugin) {
  plugin[NuxtPluginIndicator] = true;
  return plugin;
}
function callWithNuxt(nuxt, setup, args) {
  const fn = () => args ? setup(...args) : setup();
  {
    return nuxtAppCtx.callAsync(nuxt, fn);
  }
}
function useNuxtApp() {
  const nuxtAppInstance = nuxtAppCtx.tryUse();
  if (!nuxtAppInstance) {
    const vm = getCurrentInstance();
    if (!vm) {
      throw new Error("nuxt instance unavailable");
    }
    return vm.appContext.app.$nuxt;
  }
  return nuxtAppInstance;
}
function useRuntimeConfig() {
  return useNuxtApp().$config;
}
function defineGetter(obj, key, val) {
  Object.defineProperty(obj, key, { get: () => val });
}
const components = {};
const components_plugin_KR1HBZs4kY = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  for (const name in components) {
    nuxtApp.vueApp.component(name, components[name]);
    nuxtApp.vueApp.component("Lazy" + name, components[name]);
  }
});
function resolveUnref(r) {
  return typeof r === "function" ? r() : unref(r);
}
function resolveUnrefHeadInput(ref2, lastKey = "") {
  if (ref2 instanceof Promise)
    return ref2;
  const root = resolveUnref(ref2);
  if (!ref2 || !root)
    return root;
  if (Array.isArray(root))
    return root.map((r) => resolveUnrefHeadInput(r, lastKey));
  if (typeof root === "object") {
    let dynamic = false;
    const unrefdObj = Object.fromEntries(
      Object.entries(root).map(([k, v]) => {
        if (k === "titleTemplate" || k.startsWith("on"))
          return [k, unref(v)];
        if (typeof v === "function" || isRef(v))
          dynamic = true;
        return [k, resolveUnrefHeadInput(v, k)];
      })
    );
    if (dynamic && HasElementTags.includes(String(lastKey)))
      unrefdObj._dynamic = true;
    return unrefdObj;
  }
  return root;
}
const Vue3 = version.startsWith("3");
const headSymbol = "usehead";
function injectHead() {
  return getCurrentInstance() && inject(headSymbol) || getActiveHead();
}
function vueInstall(head) {
  const plugin = {
    install(app) {
      if (Vue3) {
        app.config.globalProperties.$unhead = head;
        app.config.globalProperties.$head = head;
        app.provide(headSymbol, head);
      }
    }
  };
  return plugin.install;
}
function createServerHead(options = {}) {
  const head = createServerHead$1({
    ...options,
    plugins: [
      VueReactiveUseHeadPlugin(),
      ...(options == null ? void 0 : options.plugins) || []
    ]
  });
  head.install = vueInstall(head);
  return head;
}
const VueReactiveUseHeadPlugin = () => {
  return defineHeadPlugin({
    hooks: {
      "entries:resolve": function(ctx) {
        for (const entry2 of ctx.entries)
          entry2.resolvedInput = resolveUnrefHeadInput(entry2.input);
      }
    }
  });
};
function clientUseHead(input, options = {}) {
  const head = injectHead();
  const deactivated = ref(false);
  const resolvedInput = ref({});
  watchEffect(() => {
    resolvedInput.value = deactivated.value ? {} : resolveUnrefHeadInput(input);
  });
  const entry2 = head.push(resolvedInput.value, options);
  watch(resolvedInput, (e) => {
    entry2.patch(e);
  });
  getCurrentInstance();
  return entry2;
}
function serverUseHead(input, options = {}) {
  const head = injectHead();
  return head.push(input, options);
}
function useHead(input, options = {}) {
  var _a;
  const head = injectHead();
  if (head) {
    const isBrowser = !!((_a = head.resolvedOptions) == null ? void 0 : _a.document);
    if (options.mode === "server" && isBrowser || options.mode === "client" && !isBrowser)
      return;
    return isBrowser ? clientUseHead(input, options) : serverUseHead(input, options);
  }
}
const coreComposableNames = [
  "injectHead"
];
({
  "@unhead/vue": [...coreComposableNames, ...composableNames]
});
const appHead = { "meta": [{ "name": "viewport", "content": "width=device-width, initial-scale=1" }, { "charset": "utf-8" }], "link": [], "style": [], "script": [], "noscript": [] };
const appPageTransition = false;
const appKeepalive = false;
const unhead_KgADcZ0jPj = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  const createHead = createServerHead;
  const head = createHead();
  head.push(appHead);
  nuxtApp.vueApp.use(head);
  {
    nuxtApp.ssrContext.renderMeta = async () => {
      const meta = await renderSSRHead(head);
      return {
        ...meta,
        bodyScriptsPrepend: meta.bodyTagsOpen,
        // resolves naming difference with NuxtMeta and Unhead
        bodyScripts: meta.bodyTags
      };
    };
  }
});
function polyfillAsVueUseHead(head) {
  const polyfilled = head;
  polyfilled.headTags = head.resolveTags;
  polyfilled.addEntry = head.push;
  polyfilled.addHeadObjs = head.push;
  polyfilled.addReactiveEntry = (input, options) => {
    const api = useHead(input, options);
    if (typeof api !== "undefined")
      return api.dispose;
    return () => {
    };
  };
  polyfilled.removeHeadObjs = () => {
  };
  polyfilled.updateDOM = () => {
    head.hooks.callHook("entries:updated", head);
  };
  polyfilled.unhead = head;
  return polyfilled;
}
const vueuse_head_polyfill_M7DKUOwKp5 = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  polyfillAsVueUseHead(nuxtApp.vueApp._context.provides.usehead);
});
function useState(...args) {
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  const [_key, init] = args;
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useState] key must be a string: " + _key);
  }
  if (init !== void 0 && typeof init !== "function") {
    throw new Error("[nuxt] [useState] init must be a function: " + init);
  }
  const key = "$s" + _key;
  const nuxt = useNuxtApp();
  const state = toRef(nuxt.payload.state, key);
  if (state.value === void 0 && init) {
    const initialValue = init();
    if (isRef(initialValue)) {
      nuxt.payload.state[key] = initialValue;
      return initialValue;
    }
    state.value = initialValue;
  }
  return state;
}
function useRequestEvent(nuxtApp = useNuxtApp()) {
  var _a;
  return (_a = nuxtApp.ssrContext) == null ? void 0 : _a.event;
}
function setResponseStatus(code, message) {
  const event = useRequestEvent();
  if (event) {
    event.node.res.statusCode = code;
    if (message) {
      event.node.res.statusMessage = message;
    }
  }
}
const useRouter = () => {
  var _a;
  return (_a = useNuxtApp()) == null ? void 0 : _a.$router;
};
const useRoute = () => {
  if (getCurrentInstance()) {
    return inject("_route", useNuxtApp()._route);
  }
  return useNuxtApp()._route;
};
const defineNuxtRouteMiddleware = (middleware) => middleware;
const isProcessingMiddleware = () => {
  try {
    if (useNuxtApp()._processingMiddleware) {
      return true;
    }
  } catch {
    return true;
  }
  return false;
};
const navigateTo = (to, options) => {
  if (!to) {
    to = "/";
  }
  const toPath = typeof to === "string" ? to : to.path || "/";
  const isExternal = hasProtocol(toPath, { acceptRelative: true });
  if (isExternal && !(options == null ? void 0 : options.external)) {
    throw new Error("Navigating to external URL is not allowed by default. Use `navigateTo (url, { external: true })`.");
  }
  if (isExternal && parseURL(toPath).protocol === "script:") {
    throw new Error("Cannot navigate to an URL with script protocol.");
  }
  const router = useRouter();
  {
    const nuxtApp = useNuxtApp();
    if (nuxtApp.ssrContext && nuxtApp.ssrContext.event) {
      if (isProcessingMiddleware() && !isExternal) {
        setResponseStatus((options == null ? void 0 : options.redirectCode) || 302);
        return to;
      }
      const redirectLocation = isExternal ? toPath : joinURL(useRuntimeConfig().app.baseURL, router.resolve(to).fullPath || "/");
      return nuxtApp.callHook("app:redirected").then(() => sendRedirect(nuxtApp.ssrContext.event, redirectLocation, (options == null ? void 0 : options.redirectCode) || 302));
    }
  }
  if (isExternal) {
    if (options == null ? void 0 : options.replace) {
      location.replace(toPath);
    } else {
      location.href = toPath;
    }
    return Promise.resolve();
  }
  return (options == null ? void 0 : options.replace) ? router.replace(to) : router.push(to);
};
const useError = () => toRef(useNuxtApp().payload, "error");
const showError = (_err) => {
  const err = createError(_err);
  try {
    const nuxtApp = useNuxtApp();
    nuxtApp.callHook("app:error", err);
    const error = useError();
    error.value = error.value || err;
  } catch {
    throw err;
  }
  return err;
};
const createError = (err) => {
  const _err = createError$1(err);
  _err.__nuxt_error = true;
  return _err;
};
const _routes = [
  {
    name: "capsules",
    path: "/capsules",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/capsules-cc393592.mjs').then((m) => m.default || m)
  },
  {
    name: "case-hemorrhoids",
    path: "/case-hemorrhoids",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/case-hemorrhoids-8eb29937.mjs').then((m) => m.default || m)
  },
  {
    name: "case-varikoz-hard",
    path: "/case-varikoz-hard",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/case-varikoz-hard-3a2441c6.mjs').then((m) => m.default || m)
  },
  {
    name: "case-varikoz-lite",
    path: "/case-varikoz-lite",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/case-varikoz-lite-80b35133.mjs').then((m) => m.default || m)
  },
  {
    name: "case-varikoz-middle",
    path: "/case-varikoz-middle",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/case-varikoz-middle-83b4bc3c.mjs').then((m) => m.default || m)
  },
  {
    name: "gel",
    path: "/gel",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/gel-1540b3d9.mjs').then((m) => m.default || m)
  },
  {
    name: "index",
    path: "/",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-98feecfd.mjs').then((m) => m.default || m)
  },
  {
    name: "neo",
    path: "/neo",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/neo-c57d2f0e.mjs').then((m) => m.default || m)
  },
  {
    name: "troxactive",
    path: "/troxactive",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/troxactive-1de0a250.mjs').then((m) => m.default || m)
  }
];
const routerOptions0 = {
  scrollBehavior(to, from, savedPosition) {
    const nuxtApp = useNuxtApp();
    let position = savedPosition || void 0;
    if (!position && from && to && to.meta.scrollToTop !== false && _isDifferentRoute(from, to)) {
      position = { left: 0, top: 0 };
    }
    if (to.path === from.path) {
      if (from.hash && !to.hash) {
        return { left: 0, top: 0 };
      }
      if (to.hash) {
        return { el: to.hash, top: _getHashElementScrollMarginTop(to.hash) };
      }
    }
    const hasTransition = (route) => !!(route.meta.pageTransition ?? appPageTransition);
    const hookToWait = hasTransition(from) && hasTransition(to) ? "page:transition:finish" : "page:finish";
    return new Promise((resolve) => {
      nuxtApp.hooks.hookOnce(hookToWait, async () => {
        await nextTick();
        if (to.hash) {
          position = { el: to.hash, top: _getHashElementScrollMarginTop(to.hash) };
        }
        resolve(position);
      });
    });
  }
};
function _getHashElementScrollMarginTop(selector) {
  try {
    const elem = document.querySelector(selector);
    if (elem) {
      return parseFloat(getComputedStyle(elem).scrollMarginTop);
    }
  } catch {
  }
  return 0;
}
function _isDifferentRoute(a, b) {
  const samePageComponent = a.matched[0] === b.matched[0];
  if (!samePageComponent) {
    return true;
  }
  if (samePageComponent && JSON.stringify(a.params) !== JSON.stringify(b.params)) {
    return true;
  }
  return false;
}
const configRouterOptions = {};
const routerOptions = {
  ...configRouterOptions,
  ...routerOptions0
};
const validate = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to) => {
  var _a;
  let __temp, __restore;
  if (!((_a = to.meta) == null ? void 0 : _a.validate)) {
    return;
  }
  useNuxtApp();
  useRouter();
  const result = ([__temp, __restore] = executeAsync(() => Promise.resolve(to.meta.validate(to))), __temp = await __temp, __restore(), __temp);
  if (result === true) {
    return;
  }
  {
    return result;
  }
});
const globalMiddleware = [
  validate
];
const namedMiddleware = {};
const router_jmwsqit4Rs = /* @__PURE__ */ defineNuxtPlugin(async (nuxtApp) => {
  var _a, _b;
  let __temp, __restore;
  let routerBase = useRuntimeConfig().app.baseURL;
  if (routerOptions.hashMode && !routerBase.includes("#")) {
    routerBase += "#";
  }
  const history = ((_a = routerOptions.history) == null ? void 0 : _a.call(routerOptions, routerBase)) ?? createMemoryHistory(routerBase);
  const routes = ((_b = routerOptions.routes) == null ? void 0 : _b.call(routerOptions, _routes)) ?? _routes;
  const initialURL = nuxtApp.ssrContext.url;
  const router = createRouter({
    ...routerOptions,
    history,
    routes
  });
  nuxtApp.vueApp.use(router);
  const previousRoute = shallowRef(router.currentRoute.value);
  router.afterEach((_to, from) => {
    previousRoute.value = from;
  });
  Object.defineProperty(nuxtApp.vueApp.config.globalProperties, "previousRoute", {
    get: () => previousRoute.value
  });
  const _route = shallowRef(router.resolve(initialURL));
  const syncCurrentRoute = () => {
    _route.value = router.currentRoute.value;
  };
  nuxtApp.hook("page:finish", syncCurrentRoute);
  router.afterEach((to, from) => {
    var _a2, _b2, _c, _d;
    if (((_b2 = (_a2 = to.matched[0]) == null ? void 0 : _a2.components) == null ? void 0 : _b2.default) === ((_d = (_c = from.matched[0]) == null ? void 0 : _c.components) == null ? void 0 : _d.default)) {
      syncCurrentRoute();
    }
  });
  const route = {};
  for (const key in _route.value) {
    route[key] = computed(() => _route.value[key]);
  }
  nuxtApp._route = reactive(route);
  nuxtApp._middleware = nuxtApp._middleware || {
    global: [],
    named: {}
  };
  useError();
  try {
    if (true) {
      ;
      [__temp, __restore] = executeAsync(() => router.push(initialURL)), await __temp, __restore();
      ;
    }
    ;
    [__temp, __restore] = executeAsync(() => router.isReady()), await __temp, __restore();
    ;
  } catch (error2) {
    [__temp, __restore] = executeAsync(() => callWithNuxt(nuxtApp, showError, [error2])), await __temp, __restore();
  }
  const initialLayout = useState("_layout");
  router.beforeEach(async (to, from) => {
    var _a2;
    to.meta = reactive(to.meta);
    if (nuxtApp.isHydrating && initialLayout.value && !isReadonly(to.meta.layout)) {
      to.meta.layout = initialLayout.value;
    }
    nuxtApp._processingMiddleware = true;
    const middlewareEntries = /* @__PURE__ */ new Set([...globalMiddleware, ...nuxtApp._middleware.global]);
    for (const component of to.matched) {
      const componentMiddleware = component.meta.middleware;
      if (!componentMiddleware) {
        continue;
      }
      if (Array.isArray(componentMiddleware)) {
        for (const entry2 of componentMiddleware) {
          middlewareEntries.add(entry2);
        }
      } else {
        middlewareEntries.add(componentMiddleware);
      }
    }
    for (const entry2 of middlewareEntries) {
      const middleware = typeof entry2 === "string" ? nuxtApp._middleware.named[entry2] || await ((_a2 = namedMiddleware[entry2]) == null ? void 0 : _a2.call(namedMiddleware).then((r) => r.default || r)) : entry2;
      if (!middleware) {
        throw new Error(`Unknown route middleware: '${entry2}'.`);
      }
      const result = await callWithNuxt(nuxtApp, middleware, [to, from]);
      {
        if (result === false || result instanceof Error) {
          const error2 = result || createError$1({
            statusCode: 404,
            statusMessage: `Page Not Found: ${initialURL}`
          });
          await callWithNuxt(nuxtApp, showError, [error2]);
          return false;
        }
      }
      if (result || result === false) {
        return result;
      }
    }
  });
  router.afterEach(async (to) => {
    delete nuxtApp._processingMiddleware;
    if (to.matched.length === 0) {
      await callWithNuxt(nuxtApp, showError, [createError$1({
        statusCode: 404,
        fatal: false,
        statusMessage: `Page not found: ${to.fullPath}`
      })]);
    } else {
      const currentURL = to.fullPath || "/";
      if (!isEqual(currentURL, initialURL, { trailingSlash: true })) {
        const event = await callWithNuxt(nuxtApp, useRequestEvent);
        const options = { redirectCode: event.node.res.statusCode !== 200 ? event.node.res.statusCode || 302 : 302 };
        await callWithNuxt(nuxtApp, navigateTo, [currentURL, options]);
      }
    }
  });
  nuxtApp.hooks.hookOnce("app:created", async () => {
    try {
      await router.replace({
        ...router.resolve(initialURL),
        name: void 0,
        // #4920, #$4982
        force: true
      });
    } catch (error2) {
      await callWithNuxt(nuxtApp, showError, [error2]);
    }
  });
  return { provide: { router } };
});
const _plugins = [
  components_plugin_KR1HBZs4kY,
  unhead_KgADcZ0jPj,
  vueuse_head_polyfill_M7DKUOwKp5,
  router_jmwsqit4Rs
];
const firstNonUndefined = (...args) => args.find((arg) => arg !== void 0);
const DEFAULT_EXTERNAL_REL_ATTRIBUTE = "noopener noreferrer";
function defineNuxtLink(options) {
  const componentName = options.componentName || "NuxtLink";
  const resolveTrailingSlashBehavior = (to, resolve) => {
    if (!to || options.trailingSlash !== "append" && options.trailingSlash !== "remove") {
      return to;
    }
    const normalizeTrailingSlash = options.trailingSlash === "append" ? withTrailingSlash : withoutTrailingSlash;
    if (typeof to === "string") {
      return normalizeTrailingSlash(to, true);
    }
    const path = "path" in to ? to.path : resolve(to).path;
    return {
      ...to,
      name: void 0,
      // named routes would otherwise always override trailing slash behavior
      path: normalizeTrailingSlash(path, true)
    };
  };
  return /* @__PURE__ */ defineComponent({
    name: componentName,
    props: {
      // Routing
      to: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      href: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      // Attributes
      target: {
        type: String,
        default: void 0,
        required: false
      },
      rel: {
        type: String,
        default: void 0,
        required: false
      },
      noRel: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Prefetching
      prefetch: {
        type: Boolean,
        default: void 0,
        required: false
      },
      noPrefetch: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Styling
      activeClass: {
        type: String,
        default: void 0,
        required: false
      },
      exactActiveClass: {
        type: String,
        default: void 0,
        required: false
      },
      prefetchedClass: {
        type: String,
        default: void 0,
        required: false
      },
      // Vue Router's `<RouterLink>` additional props
      replace: {
        type: Boolean,
        default: void 0,
        required: false
      },
      ariaCurrentValue: {
        type: String,
        default: void 0,
        required: false
      },
      // Edge cases handling
      external: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Slot API
      custom: {
        type: Boolean,
        default: void 0,
        required: false
      }
    },
    setup(props, { slots }) {
      const router = useRouter();
      const to = computed(() => {
        const path = props.to || props.href || "";
        return resolveTrailingSlashBehavior(path, router.resolve);
      });
      const isExternal = computed(() => {
        if (props.external) {
          return true;
        }
        if (props.target && props.target !== "_self") {
          return true;
        }
        if (typeof to.value === "object") {
          return false;
        }
        return to.value === "" || hasProtocol(to.value, { acceptRelative: true });
      });
      const prefetched = ref(false);
      const el = void 0;
      return () => {
        var _a, _b;
        if (!isExternal.value) {
          const routerLinkProps = {
            ref: void 0,
            to: to.value,
            activeClass: props.activeClass || options.activeClass,
            exactActiveClass: props.exactActiveClass || options.exactActiveClass,
            replace: props.replace,
            ariaCurrentValue: props.ariaCurrentValue,
            custom: props.custom
          };
          if (!props.custom) {
            if (prefetched.value) {
              routerLinkProps.class = props.prefetchedClass || options.prefetchedClass;
            }
            routerLinkProps.rel = props.rel;
          }
          return h(
            resolveComponent("RouterLink"),
            routerLinkProps,
            slots.default
          );
        }
        const href = typeof to.value === "object" ? ((_a = router.resolve(to.value)) == null ? void 0 : _a.href) ?? null : to.value || null;
        const target = props.target || null;
        const rel = props.noRel ? null : firstNonUndefined(props.rel, options.externalRelAttribute, href ? DEFAULT_EXTERNAL_REL_ATTRIBUTE : "") || null;
        const navigate = () => navigateTo(href, { replace: props.replace });
        if (props.custom) {
          if (!slots.default) {
            return null;
          }
          return slots.default({
            href,
            navigate,
            get route() {
              if (!href) {
                return void 0;
              }
              const url = parseURL(href);
              return {
                path: url.pathname,
                fullPath: url.pathname,
                get query() {
                  return parseQuery(url.search);
                },
                hash: url.hash,
                // stub properties for compat with vue-router
                params: {},
                name: void 0,
                matched: [],
                redirectedFrom: void 0,
                meta: {},
                href
              };
            },
            rel,
            target,
            isExternal: isExternal.value,
            isActive: false,
            isExactActive: false
          });
        }
        return h("a", { ref: el, href, rel, target }, (_b = slots.default) == null ? void 0 : _b.call(slots));
      };
    }
  });
}
const __nuxt_component_0$2 = /* @__PURE__ */ defineNuxtLink({ componentName: "NuxtLink" });
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const _sfc_main$7 = {
  name: "Button",
  props: {
    type: {
      type: String,
      default: "button"
    },
    label: {
      type: String,
      default: null
    },
    rounded: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    size: {
      type: String,
      default: "normal"
    },
    arrowRight: {
      type: Boolean,
      default: false
    },
    arrowTop: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    buttonClass() {
      return [
        "btn",
        {
          "btn-rounded": this.rounded,
          "btn-up": this.arrowTop,
          "btn-sm": this.size === "small",
          "btn-lg": this.size === "large"
        }
      ];
    }
  }
};
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<button${ssrRenderAttrs(mergeProps({
    class: $options.buttonClass,
    type: $props.type,
    disabled: $props.disabled
  }, _attrs))}>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, () => {
    _push(`<span class="btn__label">${ssrInterpolate($props.label || " ")}</span>`);
    if ($props.arrowRight) {
      _push(`<span class="btn__arrow"><svg width="5" height="10" viewBox="0 0 5 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229"></path></svg></span>`);
    } else {
      _push(`<!---->`);
    }
    if ($props.arrowTop) {
      _push(`<span class="btn__arrow"><svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.790527 4.69873L4.94855 1.31873L9.09375 4.69873"></path></svg></span>`);
    } else {
      _push(`<!---->`);
    }
  }, _push, _parent);
  _push(`</button>`);
}
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Button.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["ssrRender", _sfc_ssrRender$3]]);
const _imports_0$3 = "" + __publicAssetsURL("img/apteks/zdravsiti.png");
const _imports_1$1 = "" + __publicAssetsURL("img/apteks/gorzdrav.png");
const _imports_2$1 = "" + __publicAssetsURL("img/apteks/36.png");
const _imports_3$1 = "" + __publicAssetsURL("img/apteks/rigla.png");
const _imports_4$1 = "" + __publicAssetsURL("img/apteks/ozerki.png");
const _imports_5 = "" + __publicAssetsURL("img/apteks/stoletov.png");
const _imports_6 = "" + __publicAssetsURL("img/apteks/superapteka.png");
const _imports_7 = "" + __publicAssetsURL("img/apteks/planet.png");
const _imports_8 = "" + __publicAssetsURL("img/apteks/eapteka.png");
const _imports_0$2 = "" + __publicAssetsURL("img/apteks/aptekaru.png");
const _sfc_main$6 = {
  emits: ["update:visible"],
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    urlProducts: {
      type: String,
      default: "https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=365040&productIds=266995&productIds=376941&productIds=376944&productIds=377032&productIds=33271&productIds=33267&productIds=33264"
    },
    troxactive: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      mask: null
    };
  },
  methods: {
    closeModal() {
      this.$emit("update:visible", false);
    },
    maskRef(el) {
      this.mask = el;
    },
    onMaskClick(event) {
      if (this.mask === event.target) {
        this.closeModal();
      }
    },
    onEnter() {
      document.body.style.overflow = "hidden";
    },
    onAfterLeave() {
      document.body.style.overflow = "auto";
    }
  }
};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  if ($props.visible) {
    _push(`<div${ssrRenderAttrs(mergeProps({
      id: "modal-uteka",
      ref: $options.maskRef
    }, _attrs))}><div class="uteka-widget"><div class="uteka-widget-header"><div class="uteka-widget__container"><div class="uteka-widget-header__inner"><a class="uteka-widget-header__logo" href="https://uteka.ru/" target="_blank"><img src="https://widget.uteka.ru/static/img/widgets/logo-light.svg" alt="Заказать в Ютеке" title="поиск в аптеках"></a><div class="uteka-widget-header__title"></div><a href="#" class="uteka-widget-header__close"></a></div></div></div><iframe${ssrRenderAttr("src", $props.urlProducts)}></iframe>`);
    if ($props.troxactive) {
      _push(`<div class="pharma-container"><div class="pharma-title">Забронировать в ближайшей аптеке или заказать с доставкой на дом</div><div class="pharma-wrap"><div class="pharms__item"><a href="https://zdravcity.ru/g_troksaktiv/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_0$3)} alt="Здрависти"></a></div><div class="pharms__item"><a href="https://gorzdrav.org/catalog/troksaktiv/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_1$1)} alt="Горздрав"></a></div><div class="pharms__item"><a href="https://366.ru/g/troksaktiv/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_2$1)} alt="36"></a></div><div class="pharms__item"><a href="https://www.rigla.ru/forms/troksaktiv" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_3$1)} alt="ригла"></a></div><div class="pharms__item"><a href="https://ozerki.ru/alphabet_brand/t/troksaktiv/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_4$1)} alt="Озерки"></a></div><div class="pharms__item"><a href="https://stoletov.ru/alphabet_brand/t/troksaktiv/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_5)} alt="Столетов"></a></div><div class="pharms__item"><a href="https://superapteka.ru/alphabet_brand/t/troksaktiv-10/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_6)} alt="Супераптека"></a></div><div class="pharms__item"><a href="https://planetazdorovo.ru/reclame/?reclame=207&amp;utm_source=teva_troksevazin&amp;utm_medium=button" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_7)} alt="Планета здоровья"></a></div><div class="pharms__item"><a href="https://www.eapteka.ru/goods/drugs/cardio/veins/troksaktiv_/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_8)} alt="сбераптека"></a></div><div class="pharms__item"><a href="https://apteka.ru/product/troksaktiv-1-gr-30-sht-tabletki-pokrytye-plenochnoj-obolochkoj-618a1f4b8216709bb72ec74a/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_0$2)} alt="Аптека РУ"></a></div></div></div>`);
    } else {
      _push(`<div class="pharma-container"><div class="pharma-title">Забронировать в ближайшей аптеке или заказать с доставкой на дом</div><div class="pharma-wrap"><div class="pharms__item"><a href="https://zdravcity.ru/g_troksevazin/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_0$3)} alt="Здрависти"></a></div><div class="pharms__item"><a href="https://gorzdrav.org/catalog/troksevazin/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_1$1)} alt="Горздрав"></a></div><div class="pharms__item"><a href="https://366.ru/g/troksevazin/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_2$1)} alt="36"></a></div><div class="pharms__item"><a href="https://www.rigla.ru/forms/troksevazin" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_3$1)} alt="ригла"></a></div><div class="pharms__item"><a href="https://ozerki.ru/alphabet_brand/t/troksevazin/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_4$1)} alt="Озерки"></a></div><div class="pharms__item"><a href="https://stoletov.ru/alphabet_brand/t/troksevazin-1/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_5)} alt="Столетов"></a></div><div class="pharms__item"><a href="https://superapteka.ru/alphabet_brand/t/troksevazin/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_6)} alt="Супераптека"></a></div><div class="pharms__item"><a href="https://planetazdorovo.ru/reclame/?reclame=207&amp;utm_source=teva_troksevazin&amp;utm_medium=button" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_7)} alt="Планета здоровья"></a></div><div class="pharms__item"><a href="https://www.eapteka.ru/goods/drugs/cardio/veins/troksevazin_aktavis/" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_8)} alt="сбераптека"></a></div><div class="pharms__item"><a href="https://apteka.ru/search/?q=%D1%82%D1%80%D0%BE%D0%BA%D1%81%D0%B5%D0%B2%D0%B0%D0%B7%D0%B8%D0%BD&amp;utm_source=teva&amp;utm_medium=buy_now&amp;utm_campaign=troxevasin" target="_blank"><img loading="lazy"${ssrRenderAttr("src", _imports_0$2)} alt="Аптека РУ"></a></div></div></div>`);
    }
    _push(`</div></div>`);
  } else {
    _push(`<!---->`);
  }
}
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/modal/Uteka.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_3$1 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["ssrRender", _sfc_ssrRender$2]]);
const _imports_0$1 = "" + __publicAssetsURL("img/logo.svg");
const _imports_1 = "" + __publicAssetsURL("img/navbar/item-3.png");
const _imports_2 = "" + __publicAssetsURL("img/navbar/item-2.png");
const _imports_3 = "" + __publicAssetsURL("img/navbar/item-1.png");
const _imports_4 = "" + __publicAssetsURL("img/navbar/item-4.png");
const _sfc_main$5 = {
  __name: "Navbar",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const checkTroxactive = computed(() => {
      if (route.path === "/troxactive") {
        return true;
      }
      return false;
    });
    const showMenu = ref(false);
    const header = ref();
    const onSwiper = (swiper) => {
    };
    const breakpoints = ref({
      320: {
        slidesPerView: 2,
        slidesPerGroup: 2,
        spaceBetween: 20
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 50
      },
      1024: {
        slidesPerView: 4
      }
    });
    const toggleMenu = (e) => {
      e.currentTarget.classList.toggle("menu-open");
      showMenu.value = !showMenu.value;
    };
    const visible = ref(false);
    let productsForUteka = null;
    const openUteka = (i) => {
      i && typeof i === "string" ? productsForUteka = i : productsForUteka = "https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=365040&productIds=266995&productIds=376941&productIds=376944&productIds=377032&productIds=33271&productIds=33267&productIds=33264";
      visible.value = true;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_Button = __nuxt_component_0$1;
      const _component_ModalUteka = __nuxt_component_3$1;
      _push(`<nav${ssrRenderAttrs(mergeProps({
        class: ["navbar", { active: unref(showMenu) }],
        ref_key: "header",
        ref: header
      }, _attrs))}><div class="navbar__wrapper container">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img class="logo"${ssrRenderAttr("src", _imports_0$1)} alt="Логотип"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                class: "logo",
                src: _imports_0$1,
                alt: "Логотип"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="navbar__nav"><div class="navbar__item navbar__link"><button class="${ssrRenderClass([{ active: unref(showMenu) }, "navbar__product-more"])}" type="button"> Продукты <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.790527 4.69873L4.94855 1.31873L9.09375 4.69873" stroke="#A71680"></path></svg></button></div><div class="navbar__item navbar__cta"><button class="btn-sale" type="button" id="buy_main">Купить</button></div></div><button type="button" class="navbar__burger" aria-label="menu"><svg width="30px" height="30px" viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg"><g><line x1="0" y1="11" x2="30" y2="11" stroke-width="2"></line><line x1="0" y1="21" x2="30" y2="21" stroke-width="2"></line></g><g><line x1="0" y1="15" x2="30" y2="15" stroke-width="2"></line><line x1="0" y1="15" x2="30" y2="15" stroke-width="2"></line></g></svg></button><div class="menu" style="${ssrRenderStyle(unref(showMenu) ? null : { display: "none" })}"><div class="menu__wrapper container">`);
      _push(ssrRenderComponent(unref(Swiper), {
        "slides-per-view": 2,
        "slides-per-group": 2,
        "space-between": 20,
        modules: [unref(Navigation)],
        breakpoints: unref(breakpoints),
        navigation: "",
        onSwiper
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/gel",
                    onClick: toggleMenu,
                    class: "menu__item",
                    id: "nav_gel"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div${_scopeId3}><img${ssrRenderAttr("src", _imports_1)} alt="" loading="lazy"${_scopeId3}><h4${_scopeId3}>Троксевазин<sup${_scopeId3}>®</sup> гель 2 %</h4><p${_scopeId3}> Гель против тяжести и боли в ногах при варикозе<sup${_scopeId3}>*</sup><svg width="5" height="10" viewBox="0 0 5 10" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId3}><path d="M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229" stroke="#A71680"${_scopeId3}></path></svg></p></div><div class="menu__item_btn-link"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "Узнать больше",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", null, [
                            createVNode("img", {
                              src: _imports_1,
                              alt: "",
                              loading: "lazy"
                            }),
                            createVNode("h4", null, [
                              createTextVNode("Троксевазин"),
                              createVNode("sup", null, "®"),
                              createTextVNode(" гель 2 %")
                            ]),
                            createVNode("p", null, [
                              createTextVNode(" Гель против тяжести и боли в ногах при варикозе"),
                              createVNode("sup", null, "*"),
                              (openBlock(), createBlock("svg", {
                                width: "5",
                                height: "10",
                                viewBox: "0 0 5 10",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg"
                              }, [
                                createVNode("path", {
                                  d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                                  stroke: "#A71680"
                                })
                              ]))
                            ])
                          ]),
                          createVNode("div", { class: "menu__item_btn-link" }, [
                            createVNode(_component_Button, {
                              label: "Узнать больше",
                              rounded: ""
                            })
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_NuxtLink, {
                      to: "/gel",
                      onClick: toggleMenu,
                      class: "menu__item",
                      id: "nav_gel"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", null, [
                          createVNode("img", {
                            src: _imports_1,
                            alt: "",
                            loading: "lazy"
                          }),
                          createVNode("h4", null, [
                            createTextVNode("Троксевазин"),
                            createVNode("sup", null, "®"),
                            createTextVNode(" гель 2 %")
                          ]),
                          createVNode("p", null, [
                            createTextVNode(" Гель против тяжести и боли в ногах при варикозе"),
                            createVNode("sup", null, "*"),
                            (openBlock(), createBlock("svg", {
                              width: "5",
                              height: "10",
                              viewBox: "0 0 5 10",
                              fill: "none",
                              xmlns: "http://www.w3.org/2000/svg"
                            }, [
                              createVNode("path", {
                                d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                                stroke: "#A71680"
                              })
                            ]))
                          ])
                        ]),
                        createVNode("div", { class: "menu__item_btn-link" }, [
                          createVNode(_component_Button, {
                            label: "Узнать больше",
                            rounded: ""
                          })
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/neo",
                    onClick: toggleMenu,
                    class: "menu__item",
                    id: "nav_neo"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div${_scopeId3}><img${ssrRenderAttr("src", _imports_2)} alt="" loading="lazy"${_scopeId3}><h4${_scopeId3}>Троксевазин<sup${_scopeId3}>®</sup> Нео гель</h4><p${_scopeId3}> Гель для укрепления вен и уменьшения воспаления при варикозе<sup${_scopeId3}>*</sup><svg width="5" height="10" viewBox="0 0 5 10" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId3}><path d="M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229" stroke="#A71680"${_scopeId3}></path></svg></p></div><div class="menu__item_btn-link"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "Узнать больше",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", null, [
                            createVNode("img", {
                              src: _imports_2,
                              alt: "",
                              loading: "lazy"
                            }),
                            createVNode("h4", null, [
                              createTextVNode("Троксевазин"),
                              createVNode("sup", null, "®"),
                              createTextVNode(" Нео гель")
                            ]),
                            createVNode("p", null, [
                              createTextVNode(" Гель для укрепления вен и уменьшения воспаления при варикозе"),
                              createVNode("sup", null, "*"),
                              (openBlock(), createBlock("svg", {
                                width: "5",
                                height: "10",
                                viewBox: "0 0 5 10",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg"
                              }, [
                                createVNode("path", {
                                  d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                                  stroke: "#A71680"
                                })
                              ]))
                            ])
                          ]),
                          createVNode("div", { class: "menu__item_btn-link" }, [
                            createVNode(_component_Button, {
                              label: "Узнать больше",
                              rounded: ""
                            })
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_NuxtLink, {
                      to: "/neo",
                      onClick: toggleMenu,
                      class: "menu__item",
                      id: "nav_neo"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", null, [
                          createVNode("img", {
                            src: _imports_2,
                            alt: "",
                            loading: "lazy"
                          }),
                          createVNode("h4", null, [
                            createTextVNode("Троксевазин"),
                            createVNode("sup", null, "®"),
                            createTextVNode(" Нео гель")
                          ]),
                          createVNode("p", null, [
                            createTextVNode(" Гель для укрепления вен и уменьшения воспаления при варикозе"),
                            createVNode("sup", null, "*"),
                            (openBlock(), createBlock("svg", {
                              width: "5",
                              height: "10",
                              viewBox: "0 0 5 10",
                              fill: "none",
                              xmlns: "http://www.w3.org/2000/svg"
                            }, [
                              createVNode("path", {
                                d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                                stroke: "#A71680"
                              })
                            ]))
                          ])
                        ]),
                        createVNode("div", { class: "menu__item_btn-link" }, [
                          createVNode(_component_Button, {
                            label: "Узнать больше",
                            rounded: ""
                          })
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/troxactive",
                    onClick: toggleMenu,
                    class: "menu__item",
                    id: "nav_troxactive"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div${_scopeId3}><img${ssrRenderAttr("src", _imports_3)} alt="" loading="lazy"${_scopeId3}><h4${_scopeId3}>Троксактив таблетки</h4><p${_scopeId3}> Таблетки для лечения варикоза<sup${_scopeId3}>*</sup> и геморроя изнутри <svg width="5" height="10" viewBox="0 0 5 10" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId3}><path d="M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229" stroke="#A71680"${_scopeId3}></path></svg></p></div><div class="menu__item_btn-link"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "Узнать больше",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", null, [
                            createVNode("img", {
                              src: _imports_3,
                              alt: "",
                              loading: "lazy"
                            }),
                            createVNode("h4", null, "Троксактив таблетки"),
                            createVNode("p", null, [
                              createTextVNode(" Таблетки для лечения варикоза"),
                              createVNode("sup", null, "*"),
                              createTextVNode(" и геморроя изнутри "),
                              (openBlock(), createBlock("svg", {
                                width: "5",
                                height: "10",
                                viewBox: "0 0 5 10",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg"
                              }, [
                                createVNode("path", {
                                  d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                                  stroke: "#A71680"
                                })
                              ]))
                            ])
                          ]),
                          createVNode("div", { class: "menu__item_btn-link" }, [
                            createVNode(_component_Button, {
                              label: "Узнать больше",
                              rounded: ""
                            })
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_NuxtLink, {
                      to: "/troxactive",
                      onClick: toggleMenu,
                      class: "menu__item",
                      id: "nav_troxactive"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", null, [
                          createVNode("img", {
                            src: _imports_3,
                            alt: "",
                            loading: "lazy"
                          }),
                          createVNode("h4", null, "Троксактив таблетки"),
                          createVNode("p", null, [
                            createTextVNode(" Таблетки для лечения варикоза"),
                            createVNode("sup", null, "*"),
                            createTextVNode(" и геморроя изнутри "),
                            (openBlock(), createBlock("svg", {
                              width: "5",
                              height: "10",
                              viewBox: "0 0 5 10",
                              fill: "none",
                              xmlns: "http://www.w3.org/2000/svg"
                            }, [
                              createVNode("path", {
                                d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                                stroke: "#A71680"
                              })
                            ]))
                          ])
                        ]),
                        createVNode("div", { class: "menu__item_btn-link" }, [
                          createVNode(_component_Button, {
                            label: "Узнать больше",
                            rounded: ""
                          })
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/capsules",
                    onClick: toggleMenu,
                    class: "menu__item",
                    id: "nav_capsules"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div${_scopeId3}><img${ssrRenderAttr("src", _imports_4)} alt="" loading="lazy"${_scopeId3}><h4${_scopeId3}>Троксевазин<sup${_scopeId3}>®</sup> капсулы</h4><p${_scopeId3}> Капсулы при хронической венозной недостаточности и геморрое <svg width="5" height="10" viewBox="0 0 5 10" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId3}><path d="M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229" stroke="#A71680"${_scopeId3}></path></svg></p></div><div class="menu__item_btn-link"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "Узнать больше",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", null, [
                            createVNode("img", {
                              src: _imports_4,
                              alt: "",
                              loading: "lazy"
                            }),
                            createVNode("h4", null, [
                              createTextVNode("Троксевазин"),
                              createVNode("sup", null, "®"),
                              createTextVNode(" капсулы")
                            ]),
                            createVNode("p", null, [
                              createTextVNode(" Капсулы при хронической венозной недостаточности и геморрое "),
                              (openBlock(), createBlock("svg", {
                                width: "5",
                                height: "10",
                                viewBox: "0 0 5 10",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg"
                              }, [
                                createVNode("path", {
                                  d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                                  stroke: "#A71680"
                                })
                              ]))
                            ])
                          ]),
                          createVNode("div", { class: "menu__item_btn-link" }, [
                            createVNode(_component_Button, {
                              label: "Узнать больше",
                              rounded: ""
                            })
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_NuxtLink, {
                      to: "/capsules",
                      onClick: toggleMenu,
                      class: "menu__item",
                      id: "nav_capsules"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", null, [
                          createVNode("img", {
                            src: _imports_4,
                            alt: "",
                            loading: "lazy"
                          }),
                          createVNode("h4", null, [
                            createTextVNode("Троксевазин"),
                            createVNode("sup", null, "®"),
                            createTextVNode(" капсулы")
                          ]),
                          createVNode("p", null, [
                            createTextVNode(" Капсулы при хронической венозной недостаточности и геморрое "),
                            (openBlock(), createBlock("svg", {
                              width: "5",
                              height: "10",
                              viewBox: "0 0 5 10",
                              fill: "none",
                              xmlns: "http://www.w3.org/2000/svg"
                            }, [
                              createVNode("path", {
                                d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                                stroke: "#A71680"
                              })
                            ]))
                          ])
                        ]),
                        createVNode("div", { class: "menu__item_btn-link" }, [
                          createVNode(_component_Button, {
                            label: "Узнать больше",
                            rounded: ""
                          })
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode(_component_NuxtLink, {
                    to: "/gel",
                    onClick: toggleMenu,
                    class: "menu__item",
                    id: "nav_gel"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", null, [
                        createVNode("img", {
                          src: _imports_1,
                          alt: "",
                          loading: "lazy"
                        }),
                        createVNode("h4", null, [
                          createTextVNode("Троксевазин"),
                          createVNode("sup", null, "®"),
                          createTextVNode(" гель 2 %")
                        ]),
                        createVNode("p", null, [
                          createTextVNode(" Гель против тяжести и боли в ногах при варикозе"),
                          createVNode("sup", null, "*"),
                          (openBlock(), createBlock("svg", {
                            width: "5",
                            height: "10",
                            viewBox: "0 0 5 10",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg"
                          }, [
                            createVNode("path", {
                              d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                              stroke: "#A71680"
                            })
                          ]))
                        ])
                      ]),
                      createVNode("div", { class: "menu__item_btn-link" }, [
                        createVNode(_component_Button, {
                          label: "Узнать больше",
                          rounded: ""
                        })
                      ])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode(_component_NuxtLink, {
                    to: "/neo",
                    onClick: toggleMenu,
                    class: "menu__item",
                    id: "nav_neo"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", null, [
                        createVNode("img", {
                          src: _imports_2,
                          alt: "",
                          loading: "lazy"
                        }),
                        createVNode("h4", null, [
                          createTextVNode("Троксевазин"),
                          createVNode("sup", null, "®"),
                          createTextVNode(" Нео гель")
                        ]),
                        createVNode("p", null, [
                          createTextVNode(" Гель для укрепления вен и уменьшения воспаления при варикозе"),
                          createVNode("sup", null, "*"),
                          (openBlock(), createBlock("svg", {
                            width: "5",
                            height: "10",
                            viewBox: "0 0 5 10",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg"
                          }, [
                            createVNode("path", {
                              d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                              stroke: "#A71680"
                            })
                          ]))
                        ])
                      ]),
                      createVNode("div", { class: "menu__item_btn-link" }, [
                        createVNode(_component_Button, {
                          label: "Узнать больше",
                          rounded: ""
                        })
                      ])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode(_component_NuxtLink, {
                    to: "/troxactive",
                    onClick: toggleMenu,
                    class: "menu__item",
                    id: "nav_troxactive"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", null, [
                        createVNode("img", {
                          src: _imports_3,
                          alt: "",
                          loading: "lazy"
                        }),
                        createVNode("h4", null, "Троксактив таблетки"),
                        createVNode("p", null, [
                          createTextVNode(" Таблетки для лечения варикоза"),
                          createVNode("sup", null, "*"),
                          createTextVNode(" и геморроя изнутри "),
                          (openBlock(), createBlock("svg", {
                            width: "5",
                            height: "10",
                            viewBox: "0 0 5 10",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg"
                          }, [
                            createVNode("path", {
                              d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                              stroke: "#A71680"
                            })
                          ]))
                        ])
                      ]),
                      createVNode("div", { class: "menu__item_btn-link" }, [
                        createVNode(_component_Button, {
                          label: "Узнать больше",
                          rounded: ""
                        })
                      ])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode(_component_NuxtLink, {
                    to: "/capsules",
                    onClick: toggleMenu,
                    class: "menu__item",
                    id: "nav_capsules"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", null, [
                        createVNode("img", {
                          src: _imports_4,
                          alt: "",
                          loading: "lazy"
                        }),
                        createVNode("h4", null, [
                          createTextVNode("Троксевазин"),
                          createVNode("sup", null, "®"),
                          createTextVNode(" капсулы")
                        ]),
                        createVNode("p", null, [
                          createTextVNode(" Капсулы при хронической венозной недостаточности и геморрое "),
                          (openBlock(), createBlock("svg", {
                            width: "5",
                            height: "10",
                            viewBox: "0 0 5 10",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg"
                          }, [
                            createVNode("path", {
                              d: "M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229",
                              stroke: "#A71680"
                            })
                          ]))
                        ])
                      ]),
                      createVNode("div", { class: "menu__item_btn-link" }, [
                        createVNode(_component_Button, {
                          label: "Узнать больше",
                          rounded: ""
                        })
                      ])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="menu-btn">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: openUteka,
        label: "Купить",
        arrowRight: "",
        id: "buy_main"
      }, null, _parent));
      _push(`</div></div></div></div>`);
      _push(ssrRenderComponent(_component_ModalUteka, {
        visible: unref(visible),
        "onUpdate:visible": ($event) => isRef(visible) ? visible.value = $event : null,
        "url-products": unref(productsForUteka),
        troxactive: unref(checkTroxactive)
      }, null, _parent));
      _push(`</nav>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Navbar.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$5;
const interpolatePath = (route, match) => {
  return match.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, (r) => {
    var _a;
    return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
  });
};
const generateRouteKey = (routeProps, override) => {
  const matchedRoute = routeProps.route.matched.find((m) => {
    var _a;
    return ((_a = m.components) == null ? void 0 : _a.default) === routeProps.Component.type;
  });
  const source = override ?? (matchedRoute == null ? void 0 : matchedRoute.meta.key) ?? (matchedRoute && interpolatePath(routeProps.route, matchedRoute));
  return typeof source === "function" ? source(routeProps.route) : source;
};
const wrapInKeepAlive = (props, children) => {
  return { default: () => children };
};
const Fragment = /* @__PURE__ */ defineComponent({
  name: "FragmentWrapper",
  setup(_props, { slots }) {
    return () => {
      var _a;
      return (_a = slots.default) == null ? void 0 : _a.call(slots);
    };
  }
});
const _wrapIf = (component, props, slots) => {
  return { default: () => props ? h(component, props === true ? {} : props, slots) : h(Fragment, {}, slots) };
};
const __nuxt_component_1 = /* @__PURE__ */ defineComponent({
  name: "NuxtPage",
  inheritAttrs: false,
  props: {
    name: {
      type: String
    },
    transition: {
      type: [Boolean, Object],
      default: void 0
    },
    keepalive: {
      type: [Boolean, Object],
      default: void 0
    },
    route: {
      type: Object
    },
    pageKey: {
      type: [Function, String],
      default: null
    }
  },
  setup(props, { attrs }) {
    const nuxtApp = useNuxtApp();
    return () => {
      return h(RouterView, { name: props.name, route: props.route, ...attrs }, {
        default: (routeProps) => {
          if (!routeProps.Component) {
            return;
          }
          const key = generateRouteKey(routeProps, props.pageKey);
          const done = nuxtApp.deferHydration();
          const hasTransition = !!(props.transition ?? routeProps.route.meta.pageTransition ?? appPageTransition);
          const transitionProps = hasTransition && _mergeTransitionProps([
            props.transition,
            routeProps.route.meta.pageTransition,
            appPageTransition,
            { onAfterLeave: () => {
              nuxtApp.callHook("page:transition:finish", routeProps.Component);
            } }
          ].filter(Boolean));
          return _wrapIf(
            Transition,
            hasTransition && transitionProps,
            wrapInKeepAlive(
              props.keepalive ?? routeProps.route.meta.keepalive ?? appKeepalive,
              h(Suspense, {
                onPending: () => nuxtApp.callHook("page:start", routeProps.Component),
                onResolve: () => {
                  nextTick(() => nuxtApp.callHook("page:finish", routeProps.Component).finally(done));
                }
              }, { default: () => h(RouteProvider, { key, routeProps, pageKey: key, hasTransition }) })
            )
          ).default();
        }
      });
    };
  }
});
function _toArray(val) {
  return Array.isArray(val) ? val : val ? [val] : [];
}
function _mergeTransitionProps(routeProps) {
  const _props = routeProps.map((prop) => ({
    ...prop,
    onAfterLeave: _toArray(prop.onAfterLeave)
  }));
  return defu(..._props);
}
const RouteProvider = /* @__PURE__ */ defineComponent({
  name: "RouteProvider",
  // TODO: Type props
  // eslint-disable-next-line vue/require-prop-types
  props: ["routeProps", "pageKey", "hasTransition"],
  setup(props) {
    const previousKey = props.pageKey;
    const previousRoute = props.routeProps.route;
    const route = {};
    for (const key in props.routeProps.route) {
      route[key] = computed(() => previousKey === props.pageKey ? props.routeProps.route[key] : previousRoute[key]);
    }
    provide("_route", reactive(route));
    return () => {
      return h(props.routeProps.Component);
    };
  }
});
const _imports_0 = "" + __publicAssetsURL("img/teva.svg");
const _sfc_main$4 = {
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    const pageUp = () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Button = __nuxt_component_0$1;
      _push(`<footer${ssrRenderAttrs(mergeProps({ class: "footer" }, _attrs))}><div class="footer__wrapper container"><div class="footer__top"><div class="footer__top-links"><a href="https://www.teva.ru/contact-us/med-info/" target="_blank"> Запросить медицинскую информацию <svg width="5" height="10" viewBox="0 0 5 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229" stroke="#A71680"></path></svg></a><a href="https://www.teva.ru/contact-us/unwanted-information/" target="_blank"> Сообщить о нежелательном явлении <svg width="5" height="10" viewBox="0 0 5 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229" stroke="#A71680"></path></svg></a><a href="https://www.teva.ru/contact-us/" target="_blank"> Отправить вопрос на горячую линию <svg width="5" height="10" viewBox="0 0 5 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.407715 0.789062L3.78772 4.94709L0.407715 9.09229" stroke="#A71680"></path></svg></a></div><div class="footer__top-up">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: pageUp,
        label: "Наверх",
        rounded: "",
        arrowTop: ""
      }, null, _parent));
      _push(`</div></div><div class="footer__bottom"><img${ssrRenderAttr("src", _imports_0)} alt="Логотип Teva"><div class="footer__bottom-address">За дополнительной информацией обращайтесь: <br>ООО «Тева». Россия, Москва, 115054, <br>ул. Валовая, д. 35 <br>TRAV-RU-00126- Cons-12.2022 </div><div class="footer__bottom-phone">тел. +7 495 644 22 34 <br>факс. +7 495 644 22 35 </div><div class="footer__bottom-internet">E-mail: info@teva.ru <br>www.teva.ru </div></div></div></footer>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$4;
const _sfc_main$3 = {
  name: "Medinfo",
  data() {
    return {
      showMed: false
    };
  },
  methods: {
    resizeMedInfo() {
      document.documentElement.clientWidth;
    }
  },
  mounted() {
    this.showMed = true;
    this.resizeMedInfo();
    window.addEventListener("resize", this.resizeMedInfo);
  },
  destroyed() {
    window.removeEventListener("resize", this.resizeMedInfo);
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: "medinfo",
    style: $data.showMed ? null : { display: "none" }
  }, _attrs))}><div class="medinfo__content"><p>ИМЕЮТСЯ ПРОТИВОПОКАЗАНИЯ, НЕОБХОДИМО ПРОКОНСУЛЬТИРОВАТЬСЯ СО СПЕЦИАЛИСТОМ</p></div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MedInfo.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$2 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "cart" }, _attrs))}><svg viewBox="0 0 44 39" fill="none" xmlns="http://www.w3.org/2000/svg" class="cart__image"><path d="M36.99 5.624h5.039a.925.925 0 01.925 1.193L38.33 21.88a1.85 1.85 0 01-1.766 1.314H14.796m23.118 6.473H18.023a1.849 1.849 0 01-1.776-1.323L8.72 3.247a1.85 1.85 0 00-1.775-1.322H0M26 6v4m0 0v4m0-4h4m-4 0h-4m-7.204-4.376H9.247M19.42 35.206a2.783 2.783 0 11-5.567 0 2.783 2.783 0 015.567 0zm18.513 0a2.783 2.783 0 11-5.567 0 2.783 2.783 0 015.567 0zM34 10a8 8 0 11-16 0 8 8 0 0116 0z" stroke="#fff" stroke-width="2" stroke-miterlimit="10"></path></svg><a target="_blank" href="https://apteka.ru/search/?q=%D1%82%D1%80%D0%BE%D0%BA%D1%81%D0%B5%D0%B2%D0%B0%D0%B7%D0%B8%D0%BD&amp;utm_source=teva&amp;utm_medium=buy_now&amp;utm_campaign=troxevasin" class="cart__link"><img${ssrRenderAttr("src", _imports_0$2)} alt="apteka.ru"></a></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Cart.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$1 = {
  __name: "app",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      meta: [
        { charset: "utf-8" },
        { name: "viewport", content: "width=device-width, initial-scale=1" },
        { name: "theme-color", content: "#fff" },
        { name: "description", content: "Троксевазин – препарат, который улучшает микроциркуляцию крови и лимфы, снижает воспалительные процессы, уменьшает отеки и улучшает состояние кожи при варикозе, тромбофлебите, флебите, геморрое и других заболеваниях. Инструкция по применению, цена, аналоги и отзывы пациентов – на официальном сайте." }
      ],
      htmlAttrs: {
        lang: "ru"
      },
      link: [
        { rel: "icon", type: "image/x-icon", href: "/favicon.ico" },
        { rel: "preconnect", href: "https://geolocation.onetrust.com" },
        { rel: "preconnect", href: "https://fonts.gstatic.com" },
        { rel: "preconnect", href: "https://fonts.googleapis.com" }
      ],
      script: [
        // <!-- OneTrust Cookies Consent Notice start for troxevasin.ru -->
        { src: "https://cdn.cookielaw.org/consent/34381627-2539-4fd3-be0e-4d904b5e84d7/OtAutoBlock.js" },
        { src: "https://cdn.cookielaw.org/scripttemplates/otSDKStub.js", "data-document-language": "true", "charset": "UTF-8", "data-domain-script": "34381627-2539-4fd3-be0e-4d904b5e84d7", type: "text/javascript" },
        { innerHTML: "function OptanonWrapper() { }", type: "text/javascript" },
        // <!-- OneTrust Cookies Consent Notice end for troxevasin.ru -->
        // <!-- UTEKA start -->
        {
          type: "text/javascript",
          innerHTML: `var script = document.createElement('script')
      script.src = 'https://widget.uteka.ru/static/widgets/widget.simple.compiled.js?l=' + Date.now()
      script.async = true
      document.head.appendChild(script)`
        },
        // <!-- UTEKA end -->
        // <!-- Yandex.Metrika counter -->
        {
          type: "text/javascript",
          innerHTML: `(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
      m[i].l=1*new Date();
      for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
      k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
      (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

      ym(92925175, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true,
            webvisor:true
      });`
        },
        // <!-- /Yandex.Metrika counter -->
        // <!-- Google tag (gtag.js) -->
        { async: true, src: "https://www.googletagmanager.com/gtag/js?id=G-0TGE7W06YH" },
        {
          type: "text/javascript",
          innerHTML: `window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-0TGE7W06YH');`
        },
        // <!-- /Google tag (gtag.js) -->
        // <!-- Google Tag Manager -->
        {
          type: "text/javascript",
          innerHTML: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NJ4F4WC');`
        }
      ],
      noscript: [
        { innerHTML: '<div><img src="https://mc.yandex.ru/watch/92925175" style="position:absolute; left:-9999px;" alt="" /></div>', tagPosition: "head" },
        { innerHTML: '<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NJ4F4WC" height="0" width="0" style="display:none;visibility:hidden"></iframe>', tagPosition: "bodyOpen" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Navbar = __nuxt_component_0;
      const _component_NuxtPage = __nuxt_component_1;
      const _component_Footer = __nuxt_component_2;
      const _component_MedInfo = __nuxt_component_3;
      const _component_Cart = __nuxt_component_4;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Navbar, null, null, _parent));
      _push(ssrRenderComponent(_component_NuxtPage, null, null, _parent));
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(ssrRenderComponent(_component_MedInfo, null, null, _parent));
      _push(ssrRenderComponent(_component_Cart, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("app.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const AppComponent = _sfc_main$1;
const _sfc_main = {
  __name: "nuxt-root",
  __ssrInlineRender: true,
  setup(__props) {
    const ErrorComponent = /* @__PURE__ */ defineAsyncComponent(() => import('./_nuxt/error-component-29f8fd2d.mjs').then((r) => r.default || r));
    const IslandRenderer = /* @__PURE__ */ defineAsyncComponent(() => import('./_nuxt/island-renderer-b3e688f3.mjs').then((r) => r.default || r));
    const nuxtApp = useNuxtApp();
    nuxtApp.deferHydration();
    provide("_route", useRoute());
    nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
    const error = useError();
    onErrorCaptured((err, target, info) => {
      nuxtApp.hooks.callHook("vue:error", err, target, info).catch((hookError) => console.error("[nuxt] Error in `vue:error` hook", hookError));
      {
        const p = callWithNuxt(nuxtApp, showError, [err]);
        onServerPrefetch(() => p);
      }
    });
    const { islandContext } = nuxtApp.ssrContext;
    return (_ctx, _push, _parent, _attrs) => {
      ssrRenderSuspense(_push, {
        default: () => {
          if (unref(error)) {
            _push(ssrRenderComponent(unref(ErrorComponent), { error: unref(error) }, null, _parent));
          } else if (unref(islandContext)) {
            _push(ssrRenderComponent(unref(IslandRenderer), { context: unref(islandContext) }, null, _parent));
          } else {
            _push(ssrRenderComponent(unref(AppComponent), null, null, _parent));
          }
        },
        _: 1
      });
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/nuxt-root.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const RootComponent = _sfc_main;
if (!globalThis.$fetch) {
  globalThis.$fetch = $fetch.create({
    baseURL: baseURL()
  });
}
let entry;
const plugins = normalizePlugins(_plugins);
{
  entry = async function createNuxtAppServer(ssrContext) {
    const vueApp = createApp(RootComponent);
    const nuxt = createNuxtApp({ vueApp, ssrContext });
    try {
      await applyPlugins(nuxt, plugins);
      await nuxt.hooks.callHook("app:created", vueApp);
    } catch (err) {
      await nuxt.callHook("app:error", err);
      nuxt.payload.error = nuxt.payload.error || err;
    }
    return vueApp;
  };
}
const entry$1 = (ctx) => entry(ctx);

export { __nuxt_component_0$1 as _, __nuxt_component_0$2 as a, __nuxt_component_3$1 as b, createError as c, _export_sfc as d, entry$1 as default, useHead as u };
//# sourceMappingURL=server.mjs.map
