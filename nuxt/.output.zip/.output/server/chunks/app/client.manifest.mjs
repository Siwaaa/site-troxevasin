const client_manifest = {
  "_doc.41692760.js": {
    "resourceType": "script",
    "module": true,
    "file": "doc.41692760.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_effect-fade.min.e405b33e.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "effect-fade.96acdb02.css"
    ],
    "file": "effect-fade.min.e405b33e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "effect-fade.96acdb02.css": {
    "file": "effect-fade.96acdb02.css",
    "resourceType": "style"
  },
  "_header-1_2x.26266fe7.js": {
    "resourceType": "script",
    "module": true,
    "file": "header-1_2x.26266fe7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_maternity.b7805ae5.js": {
    "resourceType": "script",
    "module": true,
    "file": "maternity.b7805ae5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-gel-neo.5c14452d.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-gel-neo.5c14452d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-gel.43fc0ae5.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-gel.43fc0ae5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-troxactive.f1bf31ea.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-troxactive.f1bf31ea.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_step-4.fe216e5d.js": {
    "resourceType": "script",
    "module": true,
    "file": "step-4.fe216e5d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-3_2x.1461f239.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-3_2x.1461f239.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-6_2x.82f04a43.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-6_2x.82f04a43.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-8_2x.547a21c7.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-8_2x.547a21c7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-case-3_2x.46cacef2.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "symptom-case-3_2x.ea65c6d9.css"
    ],
    "file": "symptom-case-3_2x.46cacef2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "symptom-case-3_2x.ea65c6d9.css": {
    "file": "symptom-case-3_2x.ea65c6d9.css",
    "resourceType": "style"
  },
  "effect-fade.css": {
    "resourceType": "style",
    "file": "effect-fade.96acdb02.css",
    "src": "effect-fade.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.627b132b.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.ec625a2b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.627b132b.css": {
    "file": "error-404.627b132b.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.02d991ef.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.a14b7a8d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.02d991ef.css": {
    "file": "error-500.02d991ef.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.3755f3a2.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.3755f3a2.css"
    ],
    "dynamicImports": [
      "virtual:nuxt:/Users/fyy/Sites/commers/landing-troxevasinum/nuxt/.nuxt/error-component.mjs"
    ],
    "file": "entry.910d3bd0.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.3755f3a2.css": {
    "file": "entry.3755f3a2.css",
    "resourceType": "style"
  },
  "pages/capsules.css": {
    "resourceType": "style",
    "file": "gel.4345bb17.css",
    "src": "pages/neo.css"
  },
  "pages/capsules.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "capsules.9d0b7bab.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.b7805ae5.js",
      "_symptom-8_2x.547a21c7.js",
      "_other-gel.43fc0ae5.js",
      "_other-gel-neo.5c14452d.js",
      "_effect-fade.min.e405b33e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/capsules.vue"
  },
  "gel.4345bb17.css": {
    "file": "gel.4345bb17.css",
    "resourceType": "style"
  },
  "pages/case-hemorrhoids.css": {
    "resourceType": "style",
    "file": "case-hemorrhoids.c49e69b7.css",
    "src": "pages/case-hemorrhoids.css"
  },
  "pages/case-hemorrhoids.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-hemorrhoids.0e9f8a20.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_doc.41692760.js",
      "_other-troxactive.f1bf31ea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-hemorrhoids.vue"
  },
  "case-hemorrhoids.c49e69b7.css": {
    "file": "case-hemorrhoids.c49e69b7.css",
    "resourceType": "style"
  },
  "pages/case-varikoz-hard.css": {
    "resourceType": "style",
    "file": "case-varikoz-lite.c67f7879.css",
    "src": "pages/case-varikoz-hard.css"
  },
  "pages/case-varikoz-hard.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-hard.4c9c5a2b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.46cacef2.js",
      "_header-1_2x.26266fe7.js",
      "_doc.41692760.js",
      "_other-gel-neo.5c14452d.js",
      "_other-troxactive.f1bf31ea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-hard.vue"
  },
  "case-varikoz-lite.c67f7879.css": {
    "file": "case-varikoz-lite.c67f7879.css",
    "resourceType": "style"
  },
  "pages/case-varikoz-lite.css": {
    "resourceType": "style",
    "file": "case-varikoz-lite.c67f7879.css",
    "src": "pages/case-varikoz-hard.css"
  },
  "pages/case-varikoz-lite.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-lite.0f26031a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.46cacef2.js",
      "_doc.41692760.js",
      "_other-gel.43fc0ae5.js",
      "_other-gel-neo.5c14452d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-lite.vue"
  },
  "pages/case-varikoz-middle.css": {
    "resourceType": "style",
    "file": "case-varikoz-lite.c67f7879.css",
    "src": "pages/case-varikoz-hard.css"
  },
  "pages/case-varikoz-middle.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-middle.09192869.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.46cacef2.js",
      "_header-1_2x.26266fe7.js",
      "_doc.41692760.js",
      "_other-gel-neo.5c14452d.js",
      "_other-troxactive.f1bf31ea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-middle.vue"
  },
  "pages/gel.css": {
    "resourceType": "style",
    "file": "gel.4345bb17.css",
    "src": "pages/neo.css"
  },
  "pages/gel.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "gel.4fb62359.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.b7805ae5.js",
      "_symptom-3_2x.1461f239.js",
      "_step-4.fe216e5d.js",
      "_other-gel-neo.5c14452d.js",
      "_other-troxactive.f1bf31ea.js",
      "_effect-fade.min.e405b33e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/gel.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.78f6b5aa.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.fcfe8d59.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.78f6b5aa.css": {
    "file": "index.78f6b5aa.css",
    "resourceType": "style"
  },
  "pages/neo.css": {
    "resourceType": "style",
    "file": "gel.4345bb17.css",
    "src": "pages/neo.css"
  },
  "pages/neo.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "neo.c0e9a1ff.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.b7805ae5.js",
      "_symptom-6_2x.82f04a43.js",
      "_symptom-3_2x.1461f239.js",
      "_step-4.fe216e5d.js",
      "_other-gel.43fc0ae5.js",
      "_other-troxactive.f1bf31ea.js",
      "_effect-fade.min.e405b33e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/neo.vue"
  },
  "pages/troxactive.css": {
    "resourceType": "style",
    "file": "troxactive.dbc8c02b.css",
    "src": "pages/troxactive.css"
  },
  "pages/troxactive.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "troxactive.be6fa48a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-3_2x.1461f239.js",
      "_symptom-6_2x.82f04a43.js",
      "_symptom-8_2x.547a21c7.js",
      "_other-gel-neo.5c14452d.js",
      "_other-gel.43fc0ae5.js",
      "_effect-fade.min.e405b33e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/troxactive.vue"
  },
  "troxactive.dbc8c02b.css": {
    "file": "troxactive.dbc8c02b.css",
    "resourceType": "style"
  },
  "symptom-case-3_2x.css": {
    "resourceType": "style",
    "file": "symptom-case-3_2x.ea65c6d9.css",
    "src": "symptom-case-3_2x.css"
  },
  "virtual:nuxt:/Users/fyy/Sites/commers/landing-troxevasinum/nuxt/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.53f5e0f2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:/Users/fyy/Sites/commers/landing-troxevasinum/nuxt/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
