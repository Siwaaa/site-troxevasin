const client_manifest = {
  "_doc.d07aeab5.js": {
    "resourceType": "script",
    "module": true,
    "file": "doc.d07aeab5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_effect-fade.min.89effc40.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "effect-fade.96acdb02.css"
    ],
    "file": "effect-fade.min.89effc40.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "effect-fade.96acdb02.css": {
    "file": "effect-fade.96acdb02.css",
    "resourceType": "style"
  },
  "_header-1_2x.a816f54a.js": {
    "resourceType": "script",
    "module": true,
    "file": "header-1_2x.a816f54a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_maternity.af60a341.js": {
    "resourceType": "script",
    "module": true,
    "file": "maternity.af60a341.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-gel-neo.8b91ea1e.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-gel-neo.8b91ea1e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-gel.39e02974.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-gel.39e02974.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-troxactive.21f4120f.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-troxactive.21f4120f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_step-4.f807f21d.js": {
    "resourceType": "script",
    "module": true,
    "file": "step-4.f807f21d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-3_2x.964e754c.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-3_2x.964e754c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-6_2x.444a7ca9.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-6_2x.444a7ca9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-8_2x.ff637d88.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-8_2x.ff637d88.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-case-3_2x.97e20884.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "symptom-case-3_2x.ea65c6d9.css"
    ],
    "file": "symptom-case-3_2x.97e20884.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "symptom-case-3_2x.ea65c6d9.css": {
    "file": "symptom-case-3_2x.ea65c6d9.css",
    "resourceType": "style"
  },
  "effect-fade.css": {
    "resourceType": "style",
    "file": "effect-fade.96acdb02.css",
    "src": "effect-fade.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.627b132b.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.1bcd0476.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.627b132b.css": {
    "file": "error-404.627b132b.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.02d991ef.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.6c6c4c3a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.02d991ef.css": {
    "file": "error-500.02d991ef.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.3755f3a2.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.3755f3a2.css"
    ],
    "dynamicImports": [
      "virtual:nuxt:/Users/fyy/Sites/commers/landing-troxevasinum/nuxt/.nuxt/error-component.mjs"
    ],
    "file": "entry.430943a1.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.3755f3a2.css": {
    "file": "entry.3755f3a2.css",
    "resourceType": "style"
  },
  "pages/capsules.css": {
    "resourceType": "style",
    "file": "capsules.4345bb17.css",
    "src": "pages/gel.css"
  },
  "pages/capsules.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "capsules.a77b2226.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.af60a341.js",
      "_symptom-8_2x.ff637d88.js",
      "_other-gel.39e02974.js",
      "_other-gel-neo.8b91ea1e.js",
      "_effect-fade.min.89effc40.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/capsules.vue"
  },
  "capsules.4345bb17.css": {
    "file": "capsules.4345bb17.css",
    "resourceType": "style"
  },
  "pages/case-hemorrhoids.css": {
    "resourceType": "style",
    "file": "case-hemorrhoids.c49e69b7.css",
    "src": "pages/case-hemorrhoids.css"
  },
  "pages/case-hemorrhoids.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-hemorrhoids.5f9d965e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_doc.d07aeab5.js",
      "_other-troxactive.21f4120f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-hemorrhoids.vue"
  },
  "case-hemorrhoids.c49e69b7.css": {
    "file": "case-hemorrhoids.c49e69b7.css",
    "resourceType": "style"
  },
  "pages/case-varikoz-hard.css": {
    "resourceType": "style",
    "file": "case-varikoz-lite.c67f7879.css",
    "src": "pages/case-varikoz-hard.css"
  },
  "pages/case-varikoz-hard.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-hard.4d670b72.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.97e20884.js",
      "_header-1_2x.a816f54a.js",
      "_doc.d07aeab5.js",
      "_other-gel-neo.8b91ea1e.js",
      "_other-troxactive.21f4120f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-hard.vue"
  },
  "case-varikoz-lite.c67f7879.css": {
    "file": "case-varikoz-lite.c67f7879.css",
    "resourceType": "style"
  },
  "pages/case-varikoz-lite.css": {
    "resourceType": "style",
    "file": "case-varikoz-lite.c67f7879.css",
    "src": "pages/case-varikoz-hard.css"
  },
  "pages/case-varikoz-lite.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-lite.db7e7c7c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.97e20884.js",
      "_doc.d07aeab5.js",
      "_other-gel.39e02974.js",
      "_other-gel-neo.8b91ea1e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-lite.vue"
  },
  "pages/case-varikoz-middle.css": {
    "resourceType": "style",
    "file": "case-varikoz-lite.c67f7879.css",
    "src": "pages/case-varikoz-hard.css"
  },
  "pages/case-varikoz-middle.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-middle.7fcff6ba.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.97e20884.js",
      "_header-1_2x.a816f54a.js",
      "_doc.d07aeab5.js",
      "_other-gel-neo.8b91ea1e.js",
      "_other-troxactive.21f4120f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-middle.vue"
  },
  "pages/gel.css": {
    "resourceType": "style",
    "file": "capsules.4345bb17.css",
    "src": "pages/gel.css"
  },
  "pages/gel.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "gel.32b551fd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.af60a341.js",
      "_symptom-3_2x.964e754c.js",
      "_step-4.f807f21d.js",
      "_other-gel-neo.8b91ea1e.js",
      "_other-troxactive.21f4120f.js",
      "_effect-fade.min.89effc40.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/gel.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.78f6b5aa.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.4b82367b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.78f6b5aa.css": {
    "file": "index.78f6b5aa.css",
    "resourceType": "style"
  },
  "pages/neo.css": {
    "resourceType": "style",
    "file": "capsules.4345bb17.css",
    "src": "pages/gel.css"
  },
  "pages/neo.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "neo.d661dac5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.af60a341.js",
      "_symptom-6_2x.444a7ca9.js",
      "_symptom-3_2x.964e754c.js",
      "_step-4.f807f21d.js",
      "_other-gel.39e02974.js",
      "_other-troxactive.21f4120f.js",
      "_effect-fade.min.89effc40.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/neo.vue"
  },
  "pages/troxactive.css": {
    "resourceType": "style",
    "file": "troxactive.dbc8c02b.css",
    "src": "pages/troxactive.css"
  },
  "pages/troxactive.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "troxactive.843c6c39.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-3_2x.964e754c.js",
      "_symptom-6_2x.444a7ca9.js",
      "_symptom-8_2x.ff637d88.js",
      "_other-gel-neo.8b91ea1e.js",
      "_other-gel.39e02974.js",
      "_effect-fade.min.89effc40.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/troxactive.vue"
  },
  "troxactive.dbc8c02b.css": {
    "file": "troxactive.dbc8c02b.css",
    "resourceType": "style"
  },
  "symptom-case-3_2x.css": {
    "resourceType": "style",
    "file": "symptom-case-3_2x.ea65c6d9.css",
    "src": "symptom-case-3_2x.css"
  },
  "virtual:nuxt:/Users/fyy/Sites/commers/landing-troxevasinum/nuxt/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.6b4b81d2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:/Users/fyy/Sites/commers/landing-troxevasinum/nuxt/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
