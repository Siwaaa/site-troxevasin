const client_manifest = {
  "_doc.9e482b1c.js": {
    "resourceType": "script",
    "module": true,
    "file": "doc.9e482b1c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_effect-fade.min.c61bd347.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "effect-fade.96acdb02.css"
    ],
    "file": "effect-fade.min.c61bd347.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "effect-fade.96acdb02.css": {
    "file": "effect-fade.96acdb02.css",
    "resourceType": "style"
  },
  "_header-1_2x.3f67ad47.js": {
    "resourceType": "script",
    "module": true,
    "file": "header-1_2x.3f67ad47.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_maternity.da06d47d.js": {
    "resourceType": "script",
    "module": true,
    "file": "maternity.da06d47d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-gel-neo.715a20f0.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-gel-neo.715a20f0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-gel.8b4a23a3.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-gel.8b4a23a3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-troxactive.b2f59460.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-troxactive.b2f59460.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_step-4.79d78125.js": {
    "resourceType": "script",
    "module": true,
    "file": "step-4.79d78125.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-3_2x.9d538e33.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-3_2x.9d538e33.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-6_2x.8ca7f0d3.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-6_2x.8ca7f0d3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-8_2x.8a41d41d.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-8_2x.8a41d41d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-case-3_2x.ead6d70b.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "symptom-case-3_2x.ea65c6d9.css"
    ],
    "file": "symptom-case-3_2x.ead6d70b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "symptom-case-3_2x.ea65c6d9.css": {
    "file": "symptom-case-3_2x.ea65c6d9.css",
    "resourceType": "style"
  },
  "effect-fade.css": {
    "resourceType": "style",
    "file": "effect-fade.96acdb02.css",
    "src": "effect-fade.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.627b132b.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.d5fd13e2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.627b132b.css": {
    "file": "error-404.627b132b.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.02d991ef.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.fec79d61.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.02d991ef.css": {
    "file": "error-500.02d991ef.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.f43e3416.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.f43e3416.css"
    ],
    "dynamicImports": [
      "virtual:nuxt:/Users/fyy/Sites/commers/site-troxevasin/nuxt/.nuxt/error-component.mjs"
    ],
    "file": "entry.7fba306a.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.f43e3416.css": {
    "file": "entry.f43e3416.css",
    "resourceType": "style"
  },
  "pages/capsules.css": {
    "resourceType": "style",
    "file": "gel.4345bb17.css",
    "src": "pages/neo.css"
  },
  "pages/capsules.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "capsules.b14ae5ae.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.da06d47d.js",
      "_symptom-8_2x.8a41d41d.js",
      "_other-gel.8b4a23a3.js",
      "_other-gel-neo.715a20f0.js",
      "_effect-fade.min.c61bd347.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/capsules.vue"
  },
  "gel.4345bb17.css": {
    "file": "gel.4345bb17.css",
    "resourceType": "style"
  },
  "pages/case-hemorrhoids.css": {
    "resourceType": "style",
    "file": "case-hemorrhoids.c49e69b7.css",
    "src": "pages/case-hemorrhoids.css"
  },
  "pages/case-hemorrhoids.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-hemorrhoids.2bf0a942.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_doc.9e482b1c.js",
      "_other-troxactive.b2f59460.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-hemorrhoids.vue"
  },
  "case-hemorrhoids.c49e69b7.css": {
    "file": "case-hemorrhoids.c49e69b7.css",
    "resourceType": "style"
  },
  "pages/case-varikoz-hard.css": {
    "resourceType": "style",
    "file": "case-varikoz-middle.c67f7879.css",
    "src": "pages/case-varikoz-lite.css"
  },
  "pages/case-varikoz-hard.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-hard.e53d3fbf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.ead6d70b.js",
      "_header-1_2x.3f67ad47.js",
      "_doc.9e482b1c.js",
      "_other-gel-neo.715a20f0.js",
      "_other-troxactive.b2f59460.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-hard.vue"
  },
  "case-varikoz-middle.c67f7879.css": {
    "file": "case-varikoz-middle.c67f7879.css",
    "resourceType": "style"
  },
  "pages/case-varikoz-lite.css": {
    "resourceType": "style",
    "file": "case-varikoz-middle.c67f7879.css",
    "src": "pages/case-varikoz-lite.css"
  },
  "pages/case-varikoz-lite.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-lite.fca0e090.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.ead6d70b.js",
      "_doc.9e482b1c.js",
      "_other-gel.8b4a23a3.js",
      "_other-gel-neo.715a20f0.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-lite.vue"
  },
  "pages/case-varikoz-middle.css": {
    "resourceType": "style",
    "file": "case-varikoz-middle.c67f7879.css",
    "src": "pages/case-varikoz-lite.css"
  },
  "pages/case-varikoz-middle.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-middle.f5743a20.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.ead6d70b.js",
      "_header-1_2x.3f67ad47.js",
      "_doc.9e482b1c.js",
      "_other-gel-neo.715a20f0.js",
      "_other-troxactive.b2f59460.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-middle.vue"
  },
  "pages/gel.css": {
    "resourceType": "style",
    "file": "gel.4345bb17.css",
    "src": "pages/neo.css"
  },
  "pages/gel.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "gel.f2f47359.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.da06d47d.js",
      "_symptom-3_2x.9d538e33.js",
      "_step-4.79d78125.js",
      "_other-gel-neo.715a20f0.js",
      "_other-troxactive.b2f59460.js",
      "_effect-fade.min.c61bd347.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/gel.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.78f6b5aa.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.d221f251.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.78f6b5aa.css": {
    "file": "index.78f6b5aa.css",
    "resourceType": "style"
  },
  "pages/neo.css": {
    "resourceType": "style",
    "file": "gel.4345bb17.css",
    "src": "pages/neo.css"
  },
  "pages/neo.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "neo.76d32f26.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.da06d47d.js",
      "_symptom-6_2x.8ca7f0d3.js",
      "_symptom-3_2x.9d538e33.js",
      "_step-4.79d78125.js",
      "_other-gel.8b4a23a3.js",
      "_other-troxactive.b2f59460.js",
      "_effect-fade.min.c61bd347.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/neo.vue"
  },
  "pages/troxactive.css": {
    "resourceType": "style",
    "file": "troxactive.dbc8c02b.css",
    "src": "pages/troxactive.css"
  },
  "pages/troxactive.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "troxactive.ed5ae4a8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-3_2x.9d538e33.js",
      "_symptom-6_2x.8ca7f0d3.js",
      "_symptom-8_2x.8a41d41d.js",
      "_other-gel-neo.715a20f0.js",
      "_other-gel.8b4a23a3.js",
      "_effect-fade.min.c61bd347.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/troxactive.vue"
  },
  "troxactive.dbc8c02b.css": {
    "file": "troxactive.dbc8c02b.css",
    "resourceType": "style"
  },
  "symptom-case-3_2x.css": {
    "resourceType": "style",
    "file": "symptom-case-3_2x.ea65c6d9.css",
    "src": "symptom-case-3_2x.css"
  },
  "virtual:nuxt:/Users/fyy/Sites/commers/site-troxevasin/nuxt/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.7452a167.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:/Users/fyy/Sites/commers/site-troxevasin/nuxt/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
