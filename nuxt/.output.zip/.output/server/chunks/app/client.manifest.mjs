const client_manifest = {
  "_doc.3185f56d.js": {
    "resourceType": "script",
    "module": true,
    "file": "doc.3185f56d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_effect-fade.min.1e691b27.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "effect-fade.96acdb02.css"
    ],
    "file": "effect-fade.min.1e691b27.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "effect-fade.96acdb02.css": {
    "file": "effect-fade.96acdb02.css",
    "resourceType": "style"
  },
  "_header-1_2x.c78c104e.js": {
    "resourceType": "script",
    "module": true,
    "file": "header-1_2x.c78c104e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_maternity.ee167aa5.js": {
    "resourceType": "script",
    "module": true,
    "file": "maternity.ee167aa5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-gel-neo.c1272b0f.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-gel-neo.c1272b0f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-gel.24557925.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-gel.24557925.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_other-troxactive.2de7e0c7.js": {
    "resourceType": "script",
    "module": true,
    "file": "other-troxactive.2de7e0c7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_step-4.7ce1710e.js": {
    "resourceType": "script",
    "module": true,
    "file": "step-4.7ce1710e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-3_2x.b642725e.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-3_2x.b642725e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-6_2x.f6488810.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-6_2x.f6488810.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-8_2x.8f965ef8.js": {
    "resourceType": "script",
    "module": true,
    "file": "symptom-8_2x.8f965ef8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_symptom-case-3_2x.e7bba1f9.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "symptom-case-3_2x.d9ccac88.css"
    ],
    "file": "symptom-case-3_2x.e7bba1f9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "symptom-case-3_2x.d9ccac88.css": {
    "file": "symptom-case-3_2x.d9ccac88.css",
    "resourceType": "style"
  },
  "effect-fade.css": {
    "resourceType": "style",
    "file": "effect-fade.96acdb02.css",
    "src": "effect-fade.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.627b132b.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.37ad8ae0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.627b132b.css": {
    "file": "error-404.627b132b.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.02d991ef.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.cb056021.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.02d991ef.css": {
    "file": "error-500.02d991ef.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.f43e3416.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.f43e3416.css"
    ],
    "dynamicImports": [
      "virtual:nuxt:/Users/andy/Sites/site-troxevasin/nuxt/.nuxt/error-component.mjs"
    ],
    "file": "entry.eb3e4f68.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.f43e3416.css": {
    "file": "entry.f43e3416.css",
    "resourceType": "style"
  },
  "pages/capsules.css": {
    "resourceType": "style",
    "file": "gel.4345bb17.css",
    "src": "pages/capsules.css"
  },
  "pages/capsules.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "capsules.bf4f7610.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.ee167aa5.js",
      "_symptom-8_2x.8f965ef8.js",
      "_other-gel.24557925.js",
      "_other-gel-neo.c1272b0f.js",
      "_effect-fade.min.1e691b27.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/capsules.vue"
  },
  "gel.4345bb17.css": {
    "file": "gel.4345bb17.css",
    "resourceType": "style"
  },
  "pages/case-hemorrhoids.css": {
    "resourceType": "style",
    "file": "case-hemorrhoids.c49e69b7.css",
    "src": "pages/case-hemorrhoids.css"
  },
  "pages/case-hemorrhoids.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-hemorrhoids.ba1e37c5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_doc.3185f56d.js",
      "_other-troxactive.2de7e0c7.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-hemorrhoids.vue"
  },
  "case-hemorrhoids.c49e69b7.css": {
    "file": "case-hemorrhoids.c49e69b7.css",
    "resourceType": "style"
  },
  "pages/case-varikoz-hard.css": {
    "resourceType": "style",
    "file": "case-varikoz-middle.c67f7879.css",
    "src": "pages/case-varikoz-lite.css"
  },
  "pages/case-varikoz-hard.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-hard.14875c83.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.e7bba1f9.js",
      "_header-1_2x.c78c104e.js",
      "_doc.3185f56d.js",
      "_other-gel-neo.c1272b0f.js",
      "_other-troxactive.2de7e0c7.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-hard.vue"
  },
  "case-varikoz-middle.c67f7879.css": {
    "file": "case-varikoz-middle.c67f7879.css",
    "resourceType": "style"
  },
  "pages/case-varikoz-lite.css": {
    "resourceType": "style",
    "file": "case-varikoz-middle.c67f7879.css",
    "src": "pages/case-varikoz-lite.css"
  },
  "pages/case-varikoz-lite.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-lite.29a284ea.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.e7bba1f9.js",
      "_doc.3185f56d.js",
      "_other-gel.24557925.js",
      "_other-gel-neo.c1272b0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-lite.vue"
  },
  "pages/case-varikoz-middle.css": {
    "resourceType": "style",
    "file": "case-varikoz-middle.c67f7879.css",
    "src": "pages/case-varikoz-lite.css"
  },
  "pages/case-varikoz-middle.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "case-varikoz-middle.ea17d3ad.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-case-3_2x.e7bba1f9.js",
      "_header-1_2x.c78c104e.js",
      "_doc.3185f56d.js",
      "_other-gel-neo.c1272b0f.js",
      "_other-troxactive.2de7e0c7.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/case-varikoz-middle.vue"
  },
  "pages/gel.css": {
    "resourceType": "style",
    "file": "gel.4345bb17.css",
    "src": "pages/capsules.css"
  },
  "pages/gel.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "gel.40ace41c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.ee167aa5.js",
      "_symptom-3_2x.b642725e.js",
      "_step-4.7ce1710e.js",
      "_other-gel-neo.c1272b0f.js",
      "_other-troxactive.2de7e0c7.js",
      "_effect-fade.min.1e691b27.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/gel.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.78f6b5aa.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.4f5adace.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.78f6b5aa.css": {
    "file": "index.78f6b5aa.css",
    "resourceType": "style"
  },
  "pages/neo.css": {
    "resourceType": "style",
    "file": "gel.4345bb17.css",
    "src": "pages/capsules.css"
  },
  "pages/neo.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "neo.b6b69ffc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_maternity.ee167aa5.js",
      "_symptom-6_2x.f6488810.js",
      "_symptom-3_2x.b642725e.js",
      "_step-4.7ce1710e.js",
      "_other-gel.24557925.js",
      "_other-troxactive.2de7e0c7.js",
      "_effect-fade.min.1e691b27.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/neo.vue"
  },
  "pages/troxactive.css": {
    "resourceType": "style",
    "file": "troxactive.dbc8c02b.css",
    "src": "pages/troxactive.css"
  },
  "pages/troxactive.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "troxactive.2f59db8b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_symptom-3_2x.b642725e.js",
      "_symptom-6_2x.f6488810.js",
      "_symptom-8_2x.8f965ef8.js",
      "_other-gel-neo.c1272b0f.js",
      "_other-gel.24557925.js",
      "_effect-fade.min.1e691b27.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/troxactive.vue"
  },
  "troxactive.dbc8c02b.css": {
    "file": "troxactive.dbc8c02b.css",
    "resourceType": "style"
  },
  "symptom-case-3_2x.css": {
    "resourceType": "style",
    "file": "symptom-case-3_2x.d9ccac88.css",
    "src": "symptom-case-3_2x.css"
  },
  "virtual:nuxt:/Users/andy/Sites/site-troxevasin/nuxt/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.4e38b4d6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:/Users/andy/Sites/site-troxevasin/nuxt/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
