import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_12 = "" + publicAssetsURL("img/product/symptom-8.png");
const _imports_13 = "" + publicAssetsURL("img/product/symptom-8@2x.webp");

export { _imports_12 as _, _imports_13 as a };
//# sourceMappingURL=symptom-8_2x-46da890a.mjs.map
