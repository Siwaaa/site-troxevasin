const MedInfo_vue_vue_type_style_index_0_lang = ".medinfo{background-color:var(--color-white);bottom:0;-webkit-box-shadow:4px -15px 40px -25px rgba(0,0,0,.1);box-shadow:4px -15px 40px -25px rgba(0,0,0,.1);color:var(--color-violet);position:fixed;width:100%;z-index:10}.medinfo__content{-webkit-box-align:center;-ms-flex-align:center;align-items:center;display:-webkit-box;display:-ms-flexbox;display:flex;height:var(--med-h);overflow:hidden;padding:0 10px}@media (max-width:650px){.medinfo__content{padding:10px;text-align:center}}.medinfo__content>p{display:block;font-size:45px;font-weight:300;line-height:1;-webkit-transform-origin:left;-ms-transform-origin:left;transform-origin:left;white-space:nowrap;width:100%}@media (max-width:650px){.medinfo__content>p{font-size:16px;line-height:1.2;white-space:normal}}@media (max-width:480px){.medinfo__content>p{font-size:12px}}.medinfo__btn{display:none}@media (max-width:480px){.medinfo__btn{display:inline-block!important;margin-bottom:5px;text-align:center}}";

const MedInfoStyles_94a6b4bb = [MedInfo_vue_vue_type_style_index_0_lang];

export { MedInfoStyles_94a6b4bb as default };
//# sourceMappingURL=MedInfo-styles.94a6b4bb.mjs.map
