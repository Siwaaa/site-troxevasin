import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_8 = "" + publicAssetsURL("img/product/symptom-3.png");
const _imports_9 = "" + publicAssetsURL("img/product/symptom-3@2x.webp");

export { _imports_8 as _, _imports_9 as a };
//# sourceMappingURL=symptom-3_2x-91dbf5e3.mjs.map
