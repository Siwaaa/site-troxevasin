import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const Uteka_vue_vue_type_style_index_0_lang = "#modal-uteka{background:var(--color-white);height:100%;left:0;position:fixed;top:0;width:100%;z-index:100}.uteka-widget{height:calc(100vh - 80px);outline:1px solid #e0e0e0;overflow:auto;width:100%}.uteka-widget iframe{border:none;height:480px;width:100%}.uteka-widget__container{margin:0 auto;padding:0 16px}@media (min-width:600px){.uteka-widget__container{padding:0 20px}}@media (min-width:768px){.uteka-widget__container{padding:0 40px}}@media (min-width:1024px){.uteka-widget__container{padding:0 44px}}@media (min-width:1440px){.uteka-widget__container{max-width:1440px;padding:0 60px}}.uteka-widget-header{background:#fff;border-bottom:1px solid #e0e0e0}.uteka-widget-header__inner{-webkit-box-pack:center;-ms-flex-pack:center;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-box-align:center;-ms-flex-align:center;align-items:center;display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;height:56px;justify-content:center;position:relative}.uteka-widget-header__title{background:url(https://widget.uteka.ru/static/img/widgets/title_2@mobile.svg) no-repeat;background-position:50%;height:24px;width:230px}.uteka-widget-header__logo{height:16px}.uteka-widget-header__logo img{height:100%}.uteka-widget-header__close{background:url(https://widget.uteka.ru/static/img/widgets/close_2.svg) no-repeat 50%;bottom:0;height:32px;margin:auto;position:absolute;right:-8px;top:0;width:32px;z-index:5}@media (min-width:1024px){.uteka-widget-header__inner{-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-direction:row;flex-direction:row}.uteka-widget-header__title{background-image:url(https://widget.uteka.ru/static/img/widgets/title_2.svg);height:24px;width:264px}.uteka-widget-header__logo{bottom:0;height:32px;left:0;margin:auto;position:absolute;top:0}}.pharma-wrap{background:url(" + publicAssetsURL("img/uteka_fon.jpg") + ") no-repeat 50%/cover;display:inline-block;padding:40px 0;text-align:center}.pharma-title{font-size:24px;font-weight:700;margin-bottom:3.75vh;margin-top:30px;text-align:center}.pharma-title.promo{font-size:12px}.pharms__item{background:var(--color-white);border:1px solid #e2e3ec;border-radius:15px;-webkit-box-sizing:border-box;box-sizing:border-box;cursor:pointer;display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex;height:120px;margin:10px;overflow:hidden;padding:13px 20px;text-align:center;-webkit-transition:border .4s ease,-webkit-box-shadow .4s ease;transition:border .4s ease,-webkit-box-shadow .4s ease;-o-transition:border .4s ease,box-shadow .4s ease;transition:border .4s ease,box-shadow .4s ease;transition:border .4s ease,box-shadow .4s ease,-webkit-box-shadow .4s ease;width:270px}.pharms__item:hover{-webkit-box-shadow:0 4px 10px var(--color-violet);box-shadow:0 4px 10px var(--color-violet)}.pharms__item a{margin:auto}.pharms__item img{height:96px;margin:auto;max-width:90%;min-height:24px;-o-object-fit:contain;object-fit:contain}@media only screen and (max-width:600px){.pharma-wrap{width:100%}.pharma-title{font-size:16px;font-weight:700;margin:3.75vh;text-align:center}.uteka-widget iframe{border:0;width:100%}.pharms__item{border:1px solid #e2e3ec;border-radius:15px;-webkit-box-sizing:border-box;box-sizing:border-box;cursor:pointer;display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex;height:39px;margin:5px;overflow:hidden;padding:.5vh 0;text-align:center;-webkit-transition:border .4s ease,-webkit-box-shadow .4s ease;transition:border .4s ease,-webkit-box-shadow .4s ease;-o-transition:border .4s ease,box-shadow .4s ease;transition:border .4s ease,box-shadow .4s ease;transition:border .4s ease,box-shadow .4s ease,-webkit-box-shadow .4s ease;width:calc(100% - 15px)}.pharms__item img{height:24px;margin:auto;max-width:90%;-o-object-fit:contain;object-fit:contain}}";

const UtekaStyles_b3db05ea = [Uteka_vue_vue_type_style_index_0_lang];

export { UtekaStyles_b3db05ea as default };
//# sourceMappingURL=Uteka-styles.b3db05ea.mjs.map
