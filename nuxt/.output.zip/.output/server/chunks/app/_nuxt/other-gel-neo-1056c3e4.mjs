import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_28 = "" + publicAssetsURL("img/product/other-gel-neo.png");

export { _imports_28 as _ };
//# sourceMappingURL=other-gel-neo-1056c3e4.mjs.map
