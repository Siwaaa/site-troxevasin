import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_14 = "" + publicAssetsURL("img/product/secret-1.png");
const _imports_15 = "" + publicAssetsURL("img/product/secret-1@2x.png");
const _imports_22 = "" + publicAssetsURL("img/product/step-1.svg");
const _imports_23 = "" + publicAssetsURL("img/product/step-2.svg");
const _imports_24 = "" + publicAssetsURL("img/product/step-3.svg");
const _imports_25 = "" + publicAssetsURL("img/product/step-4.svg");

export { _imports_14 as _, _imports_15 as a, _imports_22 as b, _imports_23 as c, _imports_24 as d, _imports_25 as e };
//# sourceMappingURL=step-4-15e3c594.mjs.map
