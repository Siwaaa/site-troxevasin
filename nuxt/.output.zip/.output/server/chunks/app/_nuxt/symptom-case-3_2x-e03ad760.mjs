import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';
import { d as _export_sfc } from '../server.mjs';

const _imports_0 = "" + publicAssetsURL("img/modal/c0.png");
const _imports_1 = "" + publicAssetsURL("img/modal/c0@2x.png");
const _imports_2$1 = "" + publicAssetsURL("img/modal/c1.png");
const _imports_3$1 = "" + publicAssetsURL("img/modal/c1@2x.png");
const _imports_4 = "" + publicAssetsURL("img/modal/c2.png");
const _imports_5 = "" + publicAssetsURL("img/modal/c2@2x.png");
const _imports_6$1 = "" + publicAssetsURL("img/modal/c3.png");
const _imports_7$1 = "" + publicAssetsURL("img/modal/c3@2x.png");
const _imports_8$1 = "" + publicAssetsURL("img/modal/c4-1.png");
const _imports_9$1 = "" + publicAssetsURL("img/modal/c4-1@2x.png");
const _imports_10 = "" + publicAssetsURL("img/modal/c5.png");
const _imports_11$1 = "" + publicAssetsURL("img/modal/c5@2x.png");
const _imports_12$1 = "" + publicAssetsURL("img/modal/c6.png");
const _imports_13 = "" + publicAssetsURL("img/modal/c6@2x.png");
const _sfc_main = {
  emits: ["update:visible"],
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      mask: null
    };
  },
  methods: {
    closeModal() {
      this.$emit("update:visible", false);
    },
    maskRef(el) {
      this.mask = el;
    },
    onMaskClick(event) {
      if (this.mask === event.target) {
        this.closeModal();
      }
    },
    onEnter() {
      document.body.style.overflow = "hidden";
    },
    onAfterLeave() {
      document.body.style.overflow = "auto";
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  if ($props.visible) {
    _push(`<div${ssrRenderAttrs(mergeProps({
      ref: $options.maskRef,
      class: "modal-mask"
    }, _attrs))} data-v-abff094e><div class="modal" data-v-abff094e><div class="modal__content" data-v-abff094e><div class="modal__header" data-v-abff094e><h3 class="title-h1" data-v-abff094e>7 \u043A\u043B\u0430\u0441\u0441\u043E\u0432 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 <br data-v-abff094e>\u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0439 \u0432\u0435\u043D<sup data-v-abff094e>1</sup></h3></div><div class="modal__main" data-v-abff094e><div class="veins__list" data-v-abff094e><div class="veins__item" data-v-abff094e><div class="veins__img" data-v-abff094e><img${ssrRenderAttr("src", _imports_0)}${ssrRenderAttr("srcset", _imports_1 + " 2x")} alt="" data-v-abff094e></div><span data-v-abff094e>C0</span><p data-v-abff094e>\u041D\u0435\u0442 \u0432\u0438\u0437\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439</p></div><div class="veins__item" data-v-abff094e><div class="veins__img" data-v-abff094e><img${ssrRenderAttr("src", _imports_2$1)}${ssrRenderAttr("srcset", _imports_3$1 + " 2x")} alt="" data-v-abff094e></div><span data-v-abff094e>C1</span><p data-v-abff094e>\u0421\u043E\u0441\u0443\u0434\u0438\u0441\u0442\u044B\u0435 \u0437\u0432\u0435\u0437\u0434\u043E\u0447\u043A\u0438</p></div><div class="veins__item" data-v-abff094e><div class="veins__img" data-v-abff094e><img${ssrRenderAttr("src", _imports_4)}${ssrRenderAttr("srcset", _imports_5 + " 2x")} alt="" data-v-abff094e></div><span data-v-abff094e>C2</span><p data-v-abff094e>\u0412\u0430\u0440\u0438\u043A\u043E\u0437\u043D\u043E\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0432\u0435\u043D</p></div><div class="veins__item" data-v-abff094e><div class="veins__img" data-v-abff094e><img${ssrRenderAttr("src", _imports_6$1)}${ssrRenderAttr("srcset", _imports_7$1 + " 2x")} alt="" data-v-abff094e></div><span data-v-abff094e>C3</span><p data-v-abff094e>\u041E\u0442\u0435\u043A</p></div><div class="veins__item" data-v-abff094e><div class="veins__img" data-v-abff094e><img${ssrRenderAttr("src", _imports_8$1)}${ssrRenderAttr("srcset", _imports_9$1 + " 2x")} alt="" data-v-abff094e></div><span data-v-abff094e>C4</span><p data-v-abff094e>\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043A\u043E\u0436\u0438 (\u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, \u0433\u0438\u043F\u0435\u0440\u043F\u0438\u0433\u043C\u0435\u043D\u0442\u0430\u0446\u0438\u044F)</p></div><div class="veins__item" data-v-abff094e><div class="veins__img" data-v-abff094e><img${ssrRenderAttr("src", _imports_10)}${ssrRenderAttr("srcset", _imports_11$1 + " 2x")} alt="" data-v-abff094e></div><span data-v-abff094e>C5</span><p data-v-abff094e>\u0417\u0430\u0436\u0438\u0432\u0448\u0430\u044F \u044F\u0437\u0432\u0430</p></div><div class="veins__item" data-v-abff094e><div class="veins__img" data-v-abff094e><img${ssrRenderAttr("src", _imports_12$1)}${ssrRenderAttr("srcset", _imports_13 + " 2x")} alt="" data-v-abff094e></div><span data-v-abff094e>C6</span><p data-v-abff094e>\u0410\u043A\u0442\u0438\u0432\u043D\u0430\u044F \u044F\u0437\u0432\u0430</p></div></div></div><div class="modal__footer" data-v-abff094e><p data-v-abff094e>1. Ekl\xF6f B., Rutherford R.B., Bergan J.J. \u0438 \u0441\u043E\u0430\u0432\u0442.; American Venous Forum International Ad Hoc Committee for Revision of the CEAP Classification: Revision of the CEAP classification for chronic venous disorders: consensus statement. J. Vasc. Surg., 2004; 40 (6): 1251\u20131252 <br data-v-abff094e> 2. \u0417\u043E\u043B\u043E\u0442\u0443\u0445\u0438\u043D \u0418.\u0410, \u0421\u0435\u043B\u0438\u0432\u0435\u0440\u0441\u0442\u043E\u0432 \u0415., \u0428\u0435\u0432\u0446\u043E\u0432 \u042E., \u0410\u0432\u0430\u043A\u044C\u044F\u043D\u0446 \u0418., \u041D\u0438\u043A\u0438\u0448\u043A\u043E\u0432 \u0410., \u0422\u0430\u0442\u0430\u0440\u0438\u043D\u0446\u0435\u0432 \u0410., \u041A\u0438\u0440\u0438\u0435\u043D\u043A\u043E \u0410. \u0420\u0430\u0441\u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0435\u043D\u043D\u043E\u0441\u0442\u044C \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0439 \u0432\u0435\u043D: \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u043F\u043E\u043F\u0443\u043B\u044F\u0446\u0438\u043E\u043D\u043D\u043E\u0433\u043E \u044D\u043F\u0438\u0434\u0435\u043C\u0438\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F. \u0424\u043B\u0435\u0431\u043E\u043B\u043E\u0433\u0438\u044F. 2016;10(3):119-125</p></div></div><button class="modal__close" type="button" aria-label="close" data-v-abff094e><div class="modal__close-right" data-v-abff094e></div><div class="modal__close-left" data-v-abff094e></div></button></div></div>`);
  } else {
    _push(`<!---->`);
  }
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/modal/Veni.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-abff094e"]]);
const _imports_2 = "" + publicAssetsURL("img/case/h-list-1.png");
const _imports_3 = "" + publicAssetsURL("img/case/h-list-1@2x.png");
const _imports_6 = "" + publicAssetsURL("img/case/factor-1.png");
const _imports_7 = "" + publicAssetsURL("img/case/factor-2.png");
const _imports_8 = "" + publicAssetsURL("img/case/factor-3.png");
const _imports_9 = "" + publicAssetsURL("img/case/factor-4.png");
const _imports_11 = "" + publicAssetsURL("img/product/symptoms-varikoz.png");
const _imports_12 = "" + publicAssetsURL("img/product/symptoms-varikoz@2x.webp");
const _imports_15 = "" + publicAssetsURL("img/product/symptom-case-2.png");
const _imports_16 = "" + publicAssetsURL("img/product/symptom-case-2@2x.webp");
const _imports_17 = "" + publicAssetsURL("img/product/symptom-case-3.png");
const _imports_18 = "" + publicAssetsURL("img/product/symptom-case-3@2x.webp");

export { _imports_2 as _, _imports_3 as a, _imports_6 as b, _imports_7 as c, _imports_8 as d, _imports_9 as e, _imports_11 as f, _imports_12 as g, _imports_15 as h, _imports_16 as i, _imports_17 as j, _imports_18 as k, __nuxt_component_2 as l };
//# sourceMappingURL=symptom-case-3_2x-e03ad760.mjs.map
