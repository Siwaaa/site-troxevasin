import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { u as useHead, _ as __nuxt_component_0$1, a as __nuxt_component_0$2, b as __nuxt_component_3$1, d as _export_sfc } from '../server.mjs';
import { ref, withCtx, createVNode, unref, createTextVNode, isRef, useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderStyle, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _imports_4$1, a as _imports_5$1, b as _imports_10$1, c as _imports_13$1, d as _imports_14$1, e as _imports_19, f as _imports_20$1, g as _imports_21$1 } from './doc-269ff25e.mjs';
import { _ as _imports_28 } from './other-troxactive-4cd7fa82.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Navigation } from 'swiper';
import 'vue-bundle-renderer/runtime';
import 'h3';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _imports_0$1 = "" + publicAssetsURL("img/modal/gem-1.png");
const _imports_1$1 = "" + publicAssetsURL("img/modal/gem-1@2x.png");
const _imports_2$1 = "" + publicAssetsURL("img/modal/gem-2.png");
const _imports_3$1 = "" + publicAssetsURL("img/modal/gem-2@2x.png");
const _imports_4 = "" + publicAssetsURL("img/modal/gem-3.png");
const _imports_5 = "" + publicAssetsURL("img/modal/gem-3@2x.png");
const _imports_6$1 = "" + publicAssetsURL("img/modal/gem-4.png");
const _imports_7$1 = "" + publicAssetsURL("img/modal/gem-4@2x.png");
const _sfc_main$1 = {
  emits: ["update:visible"],
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      mask: null
    };
  },
  methods: {
    closeModal() {
      this.$emit("update:visible", false);
    },
    maskRef(el) {
      this.mask = el;
    },
    onMaskClick(event) {
      if (this.mask === event.target) {
        this.closeModal();
      }
    },
    onEnter() {
      document.body.style.overflow = "hidden";
    },
    onAfterLeave() {
      document.body.style.overflow = "auto";
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  if ($props.visible) {
    _push(`<div${ssrRenderAttrs(mergeProps({
      ref: $options.maskRef,
      class: "modal-mask"
    }, _attrs))}><div class="modal"><div class="modal__content"><div class="modal__header"><h3 class="title-h1">4 \u0441\u0442\u0430\u0434\u0438\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E <br>\u0433\u0435\u043C\u043E\u0440\u0440\u043E\u044F<sup>*</sup></h3></div><div class="modal__main"><div class="hemorrhoids__list"><div class="hemorrhoids__item"><div class="hemorrhoids__img"><img${ssrRenderAttr("src", _imports_0$1)}${ssrRenderAttr("srcset", _imports_1$1 + " 2x")} alt=""></div><p>\u041A\u0440\u043E\u0432\u043E\u0442\u0435\u0447\u0435\u043D\u0438\u0435, \u0431\u0435\u0437 \u0432\u044B\u043F\u0430\u0434\u0435\u043D\u0438\u044F \u0443\u0437\u043B\u043E\u0432.</p></div><div class="hemorrhoids__item"><div class="hemorrhoids__img"><img${ssrRenderAttr("src", _imports_2$1)}${ssrRenderAttr("srcset", _imports_3$1 + " 2x")} alt=""></div><p>\u0412\u044B\u043F\u0430\u0434\u0435\u043D\u0438\u0435 \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0438\u0434\u0430\u043B\u044C\u043D\u044B\u0445 \u0443\u0437\u043B\u043E\u0432 \u0441 \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u044B\u043C \u0432\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435\u043C \u0432 \u0430\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u0430\u043D\u0430\u043B, \u0441/\u0431\u0435\u0437 \u043A\u0440\u043E\u0432\u043E\u0442\u0435\u0447\u0435\u043D\u0438\u044F.</p></div><div class="hemorrhoids__item"><div class="hemorrhoids__img"><img${ssrRenderAttr("src", _imports_4)}${ssrRenderAttr("srcset", _imports_5 + " 2x")} alt=""></div><p>\u0412\u044B\u043F\u0430\u0434\u0435\u043D\u0438\u0435 \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0438\u0434\u0430\u043B\u044C\u043D\u044B\u0445 \u0443\u0437\u043B\u043E\u0432 \u0441 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u044C\u044E \u0438\u0445 \u0440\u0443\u0447\u043D\u043E\u0433\u043E \u0432\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0432 \u0430\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u0430\u043D\u0430\u043B, \u0441/\u0431\u0435\u0437 \u043A\u0440\u043E\u0432\u043E\u0442\u0435\u0447\u0435\u043D\u0438\u044F.</p></div><div class="hemorrhoids__item"><div class="hemorrhoids__img"><img${ssrRenderAttr("src", _imports_6$1)}${ssrRenderAttr("srcset", _imports_7$1 + " 2x")} alt=""></div><p>\u041F\u043E\u0441\u0442\u043E\u044F\u043D\u043D\u043E\u0435 \u0432\u044B\u043F\u0430\u0434\u0435\u043D\u0438\u0435 \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0438\u0434\u0430\u043B\u044C\u043D\u044B\u0445 \u0443\u0437\u043B\u043E\u0432 \u0438 \u043D\u0435\u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u044C \u0438\u0445 \u0432\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0432 \u0430\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u0430\u043D\u0430\u043B, \u0441/\u0431\u0435\u0437 \u043A\u0440\u043E\u0432\u043E\u0442\u0435\u0447\u0435\u043D\u0438\u044F.</p></div></div></div><div class="modal__footer"><p>https://cr.minzdrav.gov.ru/schema/178_1. \u0414\u0430\u0442\u0430 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F:\u0438 21.04.2025</p></div></div><button class="modal__close" type="button" aria-label="close"><div class="modal__close-right"></div><div class="modal__close-left"></div></button></div></div>`);
  } else {
    _push(`<!---->`);
  }
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/modal/Hemorrhoids.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _imports_0 = "" + publicAssetsURL("img/case/header-hemo.png");
const _imports_1 = "" + publicAssetsURL("img/case/header-hemo@2x.png");
const _imports_2 = "" + publicAssetsURL("img/case/h-list-3.png");
const _imports_3 = "" + publicAssetsURL("img/case/h-list-3@2x.png");
const _imports_6 = "" + publicAssetsURL("img/case/factor-4-v2.png");
const _imports_7 = "" + publicAssetsURL("img/case/factor-6.png");
const _imports_9 = "" + publicAssetsURL("img/case/factor-7-v2.png");
const _imports_10 = "" + publicAssetsURL("img/case/factor-8.png");
const _imports_11 = "" + publicAssetsURL("img/case/factor-9.png");
const _imports_12 = "" + publicAssetsURL("img/product/symptoms-hemo.png");
const _imports_13 = "" + publicAssetsURL("img/product/symptoms-hemo@2x.webp");
const _imports_14 = "" + publicAssetsURL("img/product/symptom-case-5.png");
const _imports_15 = "" + publicAssetsURL("img/product/symptom-case-5@2x.webp");
const _imports_20 = "" + publicAssetsURL("img/product/symptom-case-6.png");
const _imports_21 = "" + publicAssetsURL("img/product/symptom-case-6@2x.webp");
const _imports_23 = "" + publicAssetsURL("img/case/stats-hemo.png");
const _imports_25 = "" + publicAssetsURL("img/product/other-caps.png");
const _sfc_main = {
  __name: "case-hemorrhoids",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"
    });
    const onSwiper = (swiper) => {
    };
    ref(null);
    const visible = ref(false);
    const visibleUteka = ref(false);
    let productsForUteka = null;
    const openUteka = (i) => {
      if (i && typeof i === "string")
        productsForUteka = i;
      visibleUteka.value = true;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Button = __nuxt_component_0$1;
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_ModalHemorrhoids = __nuxt_component_2;
      const _component_ModalUteka = __nuxt_component_3$1;
      _push(`<main${ssrRenderAttrs(_attrs)}><header class="header-case" id="header"><div class="header-case__wrapper container"><div class="header-case__top"><h1 class="title-h1 header-case__title"><strong>\u0413\u0435\u043C\u043E\u0440\u0440\u043E\u0439</strong> \u2013 \u0440\u0430\u0441\u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0435\u043D\u043D\u043E\u0435 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0435 \u0441\u0440\u0435\u0434\u0438 \u0432\u0437\u0440\u043E\u0441\u043B\u043E\u0433\u043E \u043D\u0430\u0441\u0435\u043B\u0435\u043D\u0438\u044F<sup>1</sup></h1><div class="header-case__img"><img${ssrRenderAttr("src", _imports_0)}${ssrRenderAttr("srcset", _imports_1 + " 2x")} alt="" loading="lazy"></div></div><div class="header-case__list"><div class="header-case__item"><img${ssrRenderAttr("src", _imports_2)}${ssrRenderAttr("srcset", _imports_3 + " 2x")} alt="" loading="lazy"><p>\u0417\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0435 \u043C\u043E\u0436\u0435\u0442 \u0441\u043E\u043F\u0440\u043E\u0432\u043E\u0436\u0434\u0430\u0442\u044C\u0441\u044F \u0442\u0430\u043A\u0438\u043C\u0438 \u043A\u0440\u0430\u0439\u043D\u0435 \u043D\u0435\u043F\u0440\u0438\u044F\u0442\u043D\u044B\u043C\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u0430\u043C\u0438 \u043A\u0430\u043A <strong>\u0431\u043E\u043B\u044C, \u0437\u0443\u0434 \u0438 \u043A\u0440\u043E\u0432\u043E\u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u0438\u0437 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0438\u0434\u0430\u043B\u044C\u043D\u044B\u0445 \u0443\u0437\u043B\u043E\u0432</strong>, \u0430 \u043F\u0440\u0438 \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u0438 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u044F \u043C\u043E\u0436\u0435\u0442 \u043F\u0440\u0438\u0432\u0435\u0441\u0442\u0438 \u043A <strong>\u0432\u044B\u043F\u0430\u0434\u0435\u043D\u0438\u044E \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0438\u0434\u0430\u043B\u044C\u043D\u044B\u0445 \u0443\u0437\u043B\u043E\u0432.</strong> \u0423\u0447\u0435\u043D\u044B\u0435<sup>2</sup> \u0432\u044B\u0434\u0435\u043B\u044F\u044E\u0442 4 \u0441\u0442\u0430\u0434\u0438\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u044F. \u0412\u043E\u0442 \u043A\u0430\u043A \u043E\u043D\u0438 <i>\u0440\u0430\u0437\u043B\u0438\u0447\u0430\u044E\u0442\u0441\u044F</i>. </p></div><div class="header-case__item"><img${ssrRenderAttr("src", _imports_4$1)}${ssrRenderAttr("srcset", _imports_5$1 + " 2x")} alt="" loading="lazy"><p>\u041F\u0440\u0438 \u043F\u0435\u0440\u0432\u044B\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0430\u0445 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u044F <strong>\u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u044C\u0441\u044F \u043A \u0432\u0440\u0430\u0447\u0443</strong> \u0438 \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043F\u043B\u0430\u043D \u043B\u0435\u0447\u0435\u043D\u0438\u044F, \u0447\u0442\u043E\u0431\u044B \u0438\u0437\u0431\u0435\u0436\u0430\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0435\u0441\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u044F. </p></div></div></div></header><section class="factors" id="factors"><div class="factors__wrapper container"><div class="factors__content"><h2 class="title-h1">\u0424\u0430\u043A\u0442\u043E\u0440\u044B \u0440\u0438\u0441\u043A\u0430 <br> \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u044F<sup>2</sup></h2><ul class="factors__list"><li class="factors__item"><img${ssrRenderAttr("src", _imports_6)} alt="" loading="lazy"><p style="${ssrRenderStyle({ "word-break": "break-all" })}">\u0417\u043B\u043E\u0443\u043F\u043E\u0442\u0440\u0435\u0431\u043B\u0435\u043D\u0438\u0435 \u0430\u043B\u043A\u043E\u0433\u043E\u043B\u0435\u043C</p></li><li class="factors__item"><img${ssrRenderAttr("src", _imports_7)} alt="" loading="lazy"><p>\u0422\u044F\u0436\u0435\u043B\u044B\u0435 \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043D\u0430\u0433\u0440\u0443\u0437\u043A\u0438</p></li><li class="factors__item"><img${ssrRenderAttr("src", _imports_10$1)} alt="" loading="lazy"><p style="${ssrRenderStyle({ "word-break": "break-all" })}">\u041C\u0430\u043B\u043E\u043F\u043E\u0434\u0432\u0438\u0436\u043D\u044B\u0439 \u0438 \u0441\u0438\u0434\u044F\u0447\u0438\u0439 \u043E\u0431\u0440\u0430\u0437 \u0436\u0438\u0437\u043D\u0438</p></li><li class="factors__item"><img${ssrRenderAttr("src", _imports_9)} alt="" loading="lazy"><p>\u0411\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u044C \u0438 \u0440\u043E\u0434\u044B</p></li><li class="factors__item"><img${ssrRenderAttr("src", _imports_10)} alt="" loading="lazy"><p>\u0416\u0435\u043B\u0443\u0434\u043E\u0447\u043D\u043E-\u043A\u0438\u0448\u0435\u0447\u043D\u044B\u0435 \u0440\u0430\u0441\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0430 (\u0437\u0430\u043F\u043E\u0440, \u0434\u0438\u0430\u0440\u0435\u044F, \u043D\u0435\u0443\u0441\u0442\u043E\u0439\u0447\u0438\u0432\u044B\u0439 \u0441\u0442\u0443\u043B)</p></li><li class="factors__item"><img${ssrRenderAttr("src", _imports_11)} alt="" loading="lazy"><p>\u041F\u043E\u0433\u0440\u0435\u0448\u043D\u043E\u0441\u0442\u0438 \u0432 \u0434\u0438\u0435\u0442\u0435</p></li></ul></div></div></section><section class="symptoms" id="symptoms"><div class="symptoms__wrapper container"><div class="symptoms__content"><div class="symptoms__head"><h2 class="title-h1">\u041A\u0430\u043A \u0431\u043E\u0440\u043E\u0442\u044C\u0441\u044F \u0441 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435\u043C<sup>2</sup></h2></div><div class="symptoms__img"><img${ssrRenderAttr("src", _imports_12)}${ssrRenderAttr("srcset", _imports_13 + " 2x")} alt="" loading="lazy"></div><ul class="symptoms__list"><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_14)}${ssrRenderAttr("srcset", _imports_15 + " 2x")} alt="" loading="lazy"><p>\u0414\u0438\u0435\u0442\u043E\u0442\u0435\u0440\u0430\u043F\u0438\u044F</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_13$1)}${ssrRenderAttr("srcset", _imports_14$1 + " 2x")} alt="" loading="lazy"><p>\u041C\u0435\u0434\u0438\u043A\u0430\u043C\u0435\u043D\u0442\u043E\u0437\u043D\u043E\u0435 \u043B\u0435\u0447\u0435\u043D\u0438\u0435</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_19)}${ssrRenderAttr("srcset", _imports_20$1 + " 2x")} alt="" loading="lazy"><p>\u0425\u0438\u0440\u0443\u0440\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0432\u043C\u0435\u0448\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_20)}${ssrRenderAttr("srcset", _imports_21 + " 2x")} alt="" loading="lazy"><p>\u041C\u0430\u043B\u043E\u0438\u043D\u0432\u0430\u0437\u0438\u0432\u043D\u043E\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u043E\u0435 \u0432\u043C\u0435\u0448\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E</p></li></ul><div class="symptoms__doctor"><img${ssrRenderAttr("src", _imports_21$1)} alt="" loading="lazy"><p>\u041D\u0435 \u0437\u0430\u0431\u044B\u0432\u0430\u0439\u0442\u0435 \u2014 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0432 \u043A\u0430\u0436\u0434\u043E\u043C \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u043E\u043C \u0441\u043B\u0443\u0447\u0430\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0430\u0435\u0442 \u0432\u0440\u0430\u0447 </p></div></div></div></section><section class="stats" id="stats"><div class="stats__wrapper container"><div class="stats__content"><div class="stats__left"><img${ssrRenderAttr("src", _imports_23)} alt="" loading="lazy"></div><div class="stats__right"><h2 class="title-h1">\u0414\u043B\u044F \u0432\u043E\u0437\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F <br>\u043D\u0430 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u044B \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u044F</h2><p>\u0423\u0434\u043E\u0431\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u043D\u0435\u0443\u0434\u043E\u0431\u043D\u043E\u0439 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B. \u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u0438 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u043A\u0430\u043F\u0441\u0443\u043B\u044B \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0442 \u043D\u0430 \u0432\u0435\u043D\u044B \u0438\u0437\u043D\u0443\u0442\u0440\u0438<sup>5</sup> \u043F\u0440\u0438 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435.</p></div></div></div></section><section class="others" id="products"><div class="others__wrapper container"><div class="others__content"><div class="others__list"><div class="others__item swiper-gel-1"><h2 class="title-h1">\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 <br>\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438</h2><img${ssrRenderAttr("src", _imports_28)} alt="" loading="lazy"><p><strong class="others-orange">\u041A\u0443\u0440\u0441 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u2013 7 \u0434\u043D\u0435\u0439 \u043F\u0440\u0438 \u043E\u0441\u0442\u0440\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435. 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 (1000 \u043C\u0433) \u0432 \u0434\u0435\u043D\u044C \u043F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435.<sup>6</sup></strong></p><div class="others__btns">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944"),
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_troxactive"
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/troxactive",
        id: "troxactive"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="others__item swiper-gel-1"><h2 class="title-h1">\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> <br> \u043A\u0430\u043F\u0441\u0443\u043B\u044B</h2><img${ssrRenderAttr("src", _imports_25)} alt="" loading="lazy"><p><strong class="others-violet">\u0414\u043E\u0441\u0442\u0443\u043F\u043D\u0430\u044F \u0446\u0435\u043D\u0430<sup>3</sup>, <br> \u0435\u0432\u0440\u043E\u043F\u0435\u0439\u0441\u043A\u043E\u0435 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u043E<sup>4</sup></strong></p><div class="others__btns">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=33267&productIds=33264"),
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_capsules"
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/capsules",
        id: "capsules"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div><div class="others__swiper">`);
      _push(ssrRenderComponent(unref(Swiper), {
        "slides-per-view": 1,
        "space-between": 20,
        onSwiper,
        modules: [unref(Navigation)],
        navigation: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="others__item"${_scopeId2}><h2 class="title-h1"${_scopeId2}>\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 <br${_scopeId2}>\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438</h2><img${ssrRenderAttr("src", _imports_28)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}><strong class="others-orange"${_scopeId2}>\u041A\u0443\u0440\u0441 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u2013 \u0432\u0441\u0435\u0433\u043E 7 \u0434\u043D\u0435\u0439 \u043F\u0440\u0438 \u043E\u0441\u0442\u0440\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435. \u0418\u043B\u0438 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0432 \u0434\u0435\u043D\u044C \u043F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u043C<sup${_scopeId2}>6</sup></strong></p><div class="others__btns"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_Button, {
                    onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944"),
                    label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                    arrowRight: "",
                    id: "buy_troxactive"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/troxactive",
                    id: "troxactive"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "others__item" }, [
                      createVNode("h2", { class: "title-h1" }, [
                        createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 "),
                        createVNode("br"),
                        createTextVNode("\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438")
                      ]),
                      createVNode("img", {
                        src: _imports_28,
                        alt: "",
                        loading: "lazy"
                      }),
                      createVNode("p", null, [
                        createVNode("strong", { class: "others-orange" }, [
                          createTextVNode("\u041A\u0443\u0440\u0441 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u2013 \u0432\u0441\u0435\u0433\u043E 7 \u0434\u043D\u0435\u0439 \u043F\u0440\u0438 \u043E\u0441\u0442\u0440\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435. \u0418\u043B\u0438 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0432 \u0434\u0435\u043D\u044C \u043F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u043C"),
                          createVNode("sup", null, "6")
                        ])
                      ]),
                      createVNode("div", { class: "others__btns" }, [
                        createVNode(_component_Button, {
                          onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944"),
                          label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                          arrowRight: "",
                          id: "buy_troxactive"
                        }, null, 8, ["onClick"]),
                        createVNode(_component_NuxtLink, {
                          to: "/troxactive",
                          id: "troxactive"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_Button, {
                              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                              rounded: ""
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="others__item"${_scopeId2}><h2 class="title-h1"${_scopeId2}>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> <br${_scopeId2}> \u043A\u0430\u043F\u0441\u0443\u043B\u044B</h2><img${ssrRenderAttr("src", _imports_25)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}><strong class="others-violet"${_scopeId2}>\u0414\u043E\u0441\u0442\u0443\u043F\u043D\u0430\u044F \u0446\u0435\u043D\u0430<sup${_scopeId2}>3</sup>, <br${_scopeId2}> \u0435\u0432\u0440\u043E\u043F\u0435\u0439\u0441\u043A\u043E\u0435 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u043E<sup${_scopeId2}>4</sup></strong></p><div class="others__btns"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_Button, {
                    onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=33267&productIds=33264"),
                    label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                    arrowRight: ""
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/capsules",
                    id: "capsules"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "others__item" }, [
                      createVNode("h2", { class: "title-h1" }, [
                        createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(),
                        createVNode("br"),
                        createTextVNode(" \u043A\u0430\u043F\u0441\u0443\u043B\u044B")
                      ]),
                      createVNode("img", {
                        src: _imports_25,
                        alt: "",
                        loading: "lazy"
                      }),
                      createVNode("p", null, [
                        createVNode("strong", { class: "others-violet" }, [
                          createTextVNode("\u0414\u043E\u0441\u0442\u0443\u043F\u043D\u0430\u044F \u0446\u0435\u043D\u0430"),
                          createVNode("sup", null, "3"),
                          createTextVNode(", "),
                          createVNode("br"),
                          createTextVNode(" \u0435\u0432\u0440\u043E\u043F\u0435\u0439\u0441\u043A\u043E\u0435 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u043E"),
                          createVNode("sup", null, "4")
                        ])
                      ]),
                      createVNode("div", { class: "others__btns" }, [
                        createVNode(_component_Button, {
                          onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=33267&productIds=33264"),
                          label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                          arrowRight: ""
                        }, null, 8, ["onClick"]),
                        createVNode(_component_NuxtLink, {
                          to: "/capsules",
                          id: "capsules"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_Button, {
                              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                              rounded: ""
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "others__item" }, [
                    createVNode("h2", { class: "title-h1" }, [
                      createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 "),
                      createVNode("br"),
                      createTextVNode("\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438")
                    ]),
                    createVNode("img", {
                      src: _imports_28,
                      alt: "",
                      loading: "lazy"
                    }),
                    createVNode("p", null, [
                      createVNode("strong", { class: "others-orange" }, [
                        createTextVNode("\u041A\u0443\u0440\u0441 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u2013 \u0432\u0441\u0435\u0433\u043E 7 \u0434\u043D\u0435\u0439 \u043F\u0440\u0438 \u043E\u0441\u0442\u0440\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435. \u0418\u043B\u0438 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0432 \u0434\u0435\u043D\u044C \u043F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u043C"),
                        createVNode("sup", null, "6")
                      ])
                    ]),
                    createVNode("div", { class: "others__btns" }, [
                      createVNode(_component_Button, {
                        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944"),
                        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                        arrowRight: "",
                        id: "buy_troxactive"
                      }, null, 8, ["onClick"]),
                      createVNode(_component_NuxtLink, {
                        to: "/troxactive",
                        id: "troxactive"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "others__item" }, [
                    createVNode("h2", { class: "title-h1" }, [
                      createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                      createVNode("sup", null, "\xAE"),
                      createTextVNode(),
                      createVNode("br"),
                      createTextVNode(" \u043A\u0430\u043F\u0441\u0443\u043B\u044B")
                    ]),
                    createVNode("img", {
                      src: _imports_25,
                      alt: "",
                      loading: "lazy"
                    }),
                    createVNode("p", null, [
                      createVNode("strong", { class: "others-violet" }, [
                        createTextVNode("\u0414\u043E\u0441\u0442\u0443\u043F\u043D\u0430\u044F \u0446\u0435\u043D\u0430"),
                        createVNode("sup", null, "3"),
                        createTextVNode(", "),
                        createVNode("br"),
                        createTextVNode(" \u0435\u0432\u0440\u043E\u043F\u0435\u0439\u0441\u043A\u043E\u0435 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u043E"),
                        createVNode("sup", null, "4")
                      ])
                    ]),
                    createVNode("div", { class: "others__btns" }, [
                      createVNode(_component_Button, {
                        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=33267&productIds=33264"),
                        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                        arrowRight: ""
                      }, null, 8, ["onClick"]),
                      createVNode(_component_NuxtLink, {
                        to: "/capsules",
                        id: "capsules"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></section><section class="sources"><div class="sources__wrapper container"><p>* \u041F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u044F\u0445 \u0432\u0435\u043D. <br>** \u0425\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438 <br>1. \u041F\u0435\u043D\u0435\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u043E\u0435 \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u043E \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u044E. 1511 \u0440\u0435\u0441\u043F\u043E\u043D\u0434\u0435\u043D\u0442\u043E\u0432. Ipsos. \u0414\u0435\u043A\u0430\u0431\u0440\u044C 2021 <br>2. https://cr.minzdrav.gov.ru/schema/178_1 <br>3. \u041F\u043E \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E \u0441 \u043B\u0438\u0434\u0435\u0440\u0430\u043C\u0438 \u0440\u044B\u043D\u043A\u0430 \u0432\u0435\u043D\u043E\u0442\u043E\u043D\u0438\u043A\u043E\u0432 \u0434\u043B\u044F \u0441\u0438\u0441\u0442\u0435\u043C\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F. \u0421\u043E\u0433\u043B\u0430\u0441\u043D\u043E \u0434\u0430\u043D\u043D\u044B\u043C \u0431\u0430\u0437\u044B \xAB\u0410\u0419\u041A\u042C\u042E\u0412\u0418\u0410 \u0421\u043E\u043B\u044E\u0448\u043D\u0441\xBB \xAB\u0420\u043E\u0437\u043D\u0438\u0447\u043D\u044B\u0439 \u0430\u0443\u0434\u0438\u0442 \u0413\u041B\u0421 \u0438 \u0411\u0410\u0414 \u0432 \u0420\u0424\xBB, \u043F\u0440\u043E\u0434\u0430\u0436\u0438 \u0432 \u0440\u0443\u0431\u043B\u044F\u0445 \u0432 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \xAB\u041F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u044B, \u0441\u043D\u0438\u0436\u0430\u044E\u0449\u0438\u0435 \u043F\u0440\u043E\u043D\u0438\u0446\u0430\u0435\u043C\u043E\u0441\u0442\u044C \u043A\u0430\u043F\u0438\u043B\u043B\u044F\u0440\u043E\u0432\xBB \u0432 \u0432\u0438\u0434\u0435 \u0442\u0432\u0435\u0440\u0434\u044B\u0445 \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0445 \u0444\u043E\u0440\u043C; \u0441\u0440\u0435\u0434\u043D\u0438\u0435 \u0440\u043E\u0437\u043D\u0438\u0447\u043D\u044B\u0435 \u0446\u0435\u043D\u044B \u0432 \u0440\u0443\u0431\u043B\u044F\u0445 \u0432 \u043F\u0435\u0440\u0435\u0441\u0447\u0435\u0442\u0435 \u043D\u0430 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0443/\u043A\u0430\u043F\u0441\u0443\u043B\u0443 \u0432 \u0444\u0435\u0432\u0440\u0430\u043B\u0435 2025 \u0433. <br>4. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u043A\u0430\u043F\u0441\u0443\u043B\u044B \u041B\u041F-\u2116 (000083)-(\u0420\u0413-RU) <br>5. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438 \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0445 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u043E\u0432 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u041B\u041F-\u2116 (000726)-(\u0420\u0413-RU), \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u043A\u0430\u043F\u0441\u0443\u043B\u044B \u041B\u041F-\u2116(000083)-(\u0420\u0413-RU), <br>6. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u041B\u041F-\u2116 (000726)-(\u0420\u0413-RU) </p></div></section>`);
      _push(ssrRenderComponent(_component_ModalHemorrhoids, {
        visible: unref(visible),
        "onUpdate:visible": ($event) => isRef(visible) ? visible.value = $event : null
      }, null, _parent));
      _push(ssrRenderComponent(_component_ModalUteka, {
        visible: unref(visibleUteka),
        "onUpdate:visible": ($event) => isRef(visibleUteka) ? visibleUteka.value = $event : null,
        "url-products": unref(productsForUteka)
      }, null, _parent));
      _push(`</main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/case-hemorrhoids.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=case-hemorrhoids-dda18bcd.mjs.map
