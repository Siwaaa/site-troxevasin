import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("img/case/header-1.png");
const _imports_1 = "" + publicAssetsURL("img/case/header-1@2x.webp");

export { _imports_0 as _, _imports_1 as a };
//# sourceMappingURL=header-1_2x-507a714e.mjs.map
