import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_28 = "" + publicAssetsURL("img/product/other-troxactive.png");

export { _imports_28 as _ };
//# sourceMappingURL=other-troxactive-4cd7fa82.mjs.map
