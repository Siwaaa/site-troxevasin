import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_4 = "" + publicAssetsURL("img/case/h-list-2.png");
const _imports_5 = "" + publicAssetsURL("img/case/h-list-2@2x.png");
const _imports_9 = "" + publicAssetsURL("img/case/factor-4.png");
const _imports_10 = "" + publicAssetsURL("img/case/factor-5.png");
const _imports_13 = "" + publicAssetsURL("img/product/symptom-case-1.png");
const _imports_14 = "" + publicAssetsURL("img/product/symptom-case-1@2x.webp");
const _imports_19 = "" + publicAssetsURL("img/product/symptom-case-4.png");
const _imports_20 = "" + publicAssetsURL("img/product/symptom-case-4@2x.webp");
const _imports_21 = "" + publicAssetsURL("img/case/doc.png");

export { _imports_4 as _, _imports_5 as a, _imports_9 as b, _imports_10 as c, _imports_13 as d, _imports_14 as e, _imports_19 as f, _imports_20 as g, _imports_21 as h };
//# sourceMappingURL=doc-9217e06f.mjs.map
