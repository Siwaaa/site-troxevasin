import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { u as useHead, _ as __nuxt_component_0$1, a as __nuxt_component_0$2, b as __nuxt_component_3$1 } from '../server.mjs';
import { ref, withCtx, createVNode, unref, createTextVNode, isRef, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_6, a as _imports_7, b as _imports_26 } from './maternity-90bda93b.mjs';
import { _ as _imports_8$1, a as _imports_9$1 } from './symptom-3_2x-91dbf5e3.mjs';
import { _ as _imports_14$1, a as _imports_15$1, b as _imports_22$1, c as _imports_23, d as _imports_24, e as _imports_25 } from './step-4-15e3c594.mjs';
import { _ as _imports_28 } from './other-gel-neo-1056c3e4.mjs';
import { _ as _imports_28$1 } from './other-troxactive-4cd7fa82.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Navigation, EffectFade, Pagination } from 'swiper';
import 'vue-bundle-renderer/runtime';
import 'h3';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _imports_0 = "" + publicAssetsURL("img/product/test.png");
const _imports_1 = "" + publicAssetsURL("img/product/test@2x.webp");
const _imports_2 = "" + publicAssetsURL("img/product/p-gel-2.png");
const _imports_3 = "" + publicAssetsURL("img/product/p-gel-2@2x.webp");
const _imports_4 = "" + publicAssetsURL("img/product/symptoms-gel.png");
const _imports_5 = "" + publicAssetsURL("img/product/symptoms-gel@2x.webp");
const _imports_8 = "" + publicAssetsURL("img/product/symptom-2.png");
const _imports_9 = "" + publicAssetsURL("img/product/symptom-2@2x.webp");
const _imports_12 = "" + publicAssetsURL("img/product/symptom-4.png");
const _imports_13 = "" + publicAssetsURL("img/product/symptom-4@2x.webp");
const _imports_14 = "" + publicAssetsURL("img/product/symptom-5.png");
const _imports_15 = "" + publicAssetsURL("img/product/symptom-5@2x.webp");
const _imports_18 = "" + publicAssetsURL("img/product/secret-2.png");
const _imports_19 = "" + publicAssetsURL("img/product/secret-2@2x.png");
const _imports_20 = "" + publicAssetsURL("img/product/secret-3.png");
const _imports_21 = "" + publicAssetsURL("img/product/secret-3@2x.png");
const _imports_22 = "" + publicAssetsURL("img/product/economy-25.png");
const _sfc_main = {
  __name: "gel",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D \u0413\u0435\u043B\u044C"
    });
    const onSwiper = (swiper) => {
    };
    const onSwiperHeader = (swiper) => {
    };
    const pagination = ref({
      clickable: true,
      renderBullet: function(index, className) {
        let pagiText = null;
        switch (index) {
          case 0:
            pagiText = "40 \u0433";
            break;
          case 1:
            pagiText = "100 \u0433";
            break;
        }
        return '<span class="' + className + '">' + pagiText + "</span>";
      }
    });
    const visibleUteka = ref(false);
    const productsForUteka = "https://widget.uteka.ru/widgets/full/?productIds=365040&productIds=33271";
    const openUteka = () => {
      visibleUteka.value = true;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Button = __nuxt_component_0$1;
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_ModalUteka = __nuxt_component_3$1;
      _push(`<main${ssrRenderAttrs(_attrs)}><header class="header-product" id="header"><div class="header-product__wrapper container"><div class="header-product__content"><h1 class="title-h1"><strong>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> 2 % \u2014 \u0433\u0435\u043B\u044C \u21161</strong><sup>*,1</sup> \u0434\u043B\u044F \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup>**,3</sup></h1><p class="header-product__footnote"><sup>*</sup>\u043F\u043E \u043F\u0440\u043E\u0434\u0430\u0436\u0430\u043C \u0432 \u0434\u0435\u043D\u044C\u0433\u0430\u0445 (2008 \u2013 2022)<sup>1</sup></p><p>\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C<sup>2</sup> \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442 \u043F\u0440\u043E\u0442\u0438\u0432 \u0442\u044F\u0436\u0435\u0441\u0442\u0438 \u0438 \u0431\u043E\u043B\u0438 \u0432 \u043D\u043E\u0433\u0430\u0445 \u043F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435<sup>**</sup>. \u0421\u043F\u043E\u0441\u043E\u0431\u0441\u0442\u0432\u0443\u0435\u0442 \u0443\u043A\u0440\u0435\u043F\u043B\u0435\u043D\u0438\u044E \u0432\u0435\u043D \u0438 \u043F\u043E\u0432\u044B\u0448\u0435\u043D\u0438\u044E \u0438\u0445 \u0442\u043E\u043D\u0443\u0441\u0430<sup>3</sup>. </p><div class="header-product__menu">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: openUteka,
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_gel_1"
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "#faq",
        id: "gel_faq_1"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
              arrowRight: "",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
                arrowRight: "",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="header-product__swiper">`);
      _push(ssrRenderComponent(unref(Swiper), {
        initialSlide: 1,
        "slides-per-view": 1,
        "space-between": 50,
        effect: "fade",
        "fade-effect": { crossFade: true },
        speed: 1300,
        "grab-cursor": true,
        onSwiper: onSwiperHeader,
        modules: [unref(Navigation), unref(EffectFade), unref(Pagination)],
        navigation: "",
        pagination: unref(pagination)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="header-product__swiper-item"${_scopeId2}><img${ssrRenderAttr("src", _imports_0)}${ssrRenderAttr("srcset", _imports_1 + " 2x")} alt="" loading="lazy"${_scopeId2}></div>`);
                } else {
                  return [
                    createVNode("div", { class: "header-product__swiper-item" }, [
                      createVNode("img", {
                        src: _imports_0,
                        srcset: _imports_1 + " 2x",
                        alt: "",
                        loading: "lazy"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="header-product__swiper-item"${_scopeId2}><img${ssrRenderAttr("src", _imports_2)}${ssrRenderAttr("srcset", _imports_3 + " 2x")} alt="" loading="lazy"${_scopeId2}></div>`);
                } else {
                  return [
                    createVNode("div", { class: "header-product__swiper-item" }, [
                      createVNode("img", {
                        src: _imports_2,
                        srcset: _imports_3 + " 2x",
                        alt: "",
                        loading: "lazy"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "header-product__swiper-item" }, [
                    createVNode("img", {
                      src: _imports_0,
                      srcset: _imports_1 + " 2x",
                      alt: "",
                      loading: "lazy"
                    })
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "header-product__swiper-item" }, [
                    createVNode("img", {
                      src: _imports_2,
                      srcset: _imports_3 + " 2x",
                      alt: "",
                      loading: "lazy"
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="header-product__menu_mobile">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: openUteka,
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_gel_2"
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "#faq",
        id: "gel_faq_2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
              arrowRight: "",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
                arrowRight: "",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></header><section class="symptoms" id="symptoms"><div class="symptoms__wrapper container"><div class="symptoms__content"><div class="symptoms__head"><h2 class="title-h1">\u0413\u0435\u043B\u044C \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> 2% \u2014 \u043F\u043E\u043C\u043E\u0449\u044C \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u0438\u043C \u043F\u043E\u043A\u043E\u043B\u0435\u043D\u0438\u044F\u043C<sup>2</sup> \u0432 \u043B\u0435\u0447\u0435\u043D\u0438\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup>**,3</sup>:</h2></div><div class="symptoms__img"><img${ssrRenderAttr("src", _imports_4)}${ssrRenderAttr("srcset", _imports_5 + " 2x")} alt="" loading="lazy"></div><ul class="symptoms__list"><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_6)}${ssrRenderAttr("srcset", _imports_7 + " 2x")} alt="" loading="lazy"><p>\u0422\u044F\u0436\u0435\u0441\u0442\u044C <br>\u0438 \u0431\u043E\u043B\u044C \u0432 \u043D\u043E\u0433\u0430\u0445 </p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_8)}${ssrRenderAttr("srcset", _imports_9 + " 2x")} alt="" loading="lazy"><p>\u0421\u0438\u043D\u044F\u043A\u0438<br>(\u0433\u0435\u043C\u0430\u0442\u043E\u043C\u044B)</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_8$1)}${ssrRenderAttr("srcset", _imports_9$1 + " 2x")} alt="" loading="lazy"><p>\u0411\u043E\u043B\u0438 \u0438 \u043E\u0442\u0435\u043A\u0438 <br>\u0432 \u043D\u043E\u0433\u0430\u0445</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_12)}${ssrRenderAttr("srcset", _imports_13 + " 2x")} alt="" loading="lazy"><p>\u041F\u043E\u0432\u0435\u0440\u0445\u043D\u043E\u0441\u0442\u043D\u044B\u0439 \u0442\u0440\u043E\u043C\u0431\u043E\u0444\u043B\u0435\u0431\u0438\u0442</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_14)}${ssrRenderAttr("srcset", _imports_15 + " 2x")} alt="" loading="lazy"><p>\u0412\u0430\u0440\u0438\u043A\u043E\u0437\u043D\u043E\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0432\u0435\u043D</p></li></ul><div class="symptoms__menu">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: openUteka,
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_gel_3"
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "#faq",
        id: "gel_faq_3"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
              arrowRight: "",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
                arrowRight: "",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></section><section class="secret" id="secret"><div class="secret__wrapper container"><div class="secret__content"><h2 class="title-h1">\u0421\u0435\u043A\u0440\u0435\u0442 \u043F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u043E\u0441\u0442\u0438 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup><br>\u0413\u0435\u043B\u044C 2 % \u043F\u0440\u043E\u0441\u0442</h2><ul class="secret__list"><li class="secret__item"><img${ssrRenderAttr("src", _imports_14$1)}${ssrRenderAttr("srcset", _imports_15$1 + " 2x")} alt="" loading="lazy"><p>\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u0432\u0435\u0449\u0435\u0441\u0442\u0432\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u2014 \u0422\u0440\u043E\u043A\u0441\u0435\u0440\u0443\u0442\u0438\u043D<sup>3</sup></p></li><li class="secret__item"><img${ssrRenderAttr("src", _imports_18)}${ssrRenderAttr("srcset", _imports_19 + " 2x")} alt="" loading="lazy"><p>\u0422\u0440\u043E\u043A\u0441\u0435\u0440\u0443\u0442\u0438\u043D \u0443\u043C\u0435\u043D\u044C\u0448\u0430\u0435\u0442 \u0432\u043E\u0441\u043F\u0430\u043B\u0435\u043D\u0438\u0435 \u0438 \u0443\u043C\u0435\u043D\u044C\u0448\u0430\u0435\u0442 \u043B\u043E\u043C\u043A\u043E\u0441\u0442\u044C \u043A\u0430\u043F\u0438\u043B\u043B\u044F\u0440\u043E\u0432<sup>3</sup></p></li><li class="secret__item"><img${ssrRenderAttr("src", _imports_20)}${ssrRenderAttr("srcset", _imports_21 + " 2x")} alt="" loading="lazy"><p>\u041E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u043F\u0440\u043E\u0442\u0438\u0432\u043E\u043E\u0442\u0435\u0447\u043D\u043E\u0435 \u0438 \u0432\u0435\u043D\u043E\u0442\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u044E\u0449\u0435\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435<sup>3</sup></p></li></ul></div></div></section><section class="economy" id="economy"><div class="economy__wrapper container"><div class="economy__content"><div class="economy__left"><h2 class="title-h1">\u0421\u044D\u043A\u043E\u043D\u043E\u043C\u044C\u0442\u0435<sup>4</sup> \u0434\u043E 25% \u043F\u0440\u0438 \u043F\u043E\u043A\u0443\u043F\u043A\u0435 \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u0413\u0435\u043B\u044C 2% 100 \u0433. </h2>`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: openUteka,
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_gel_4"
      }, null, _parent));
      _push(`</div><div class="economy__right"><img${ssrRenderAttr("src", _imports_22)} alt="" loading="lazy">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: openUteka,
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_gel_4"
      }, null, _parent));
      _push(`</div></div></div></section><section class="tutorial" id="tutorial"><div class="tutorial__wrapper container"><div class="tutorial__content"><div class="tutorial__head"><h2 class="title-h1">\u041A\u0430\u043A \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C?<sup>3</sup></h2><p>\u041F\u043E\u043B\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u0432 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438 \u043F\u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E<sup>3</sup></p></div><ul class="steps"><li class="steps__item"><div class="steps__img"><img${ssrRenderAttr("src", _imports_22$1)} alt="" loading="lazy"></div><p>\u0423\u0442\u0440\u043E\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C</p></li><li class="steps__item"><div class="steps__img"><img${ssrRenderAttr("src", _imports_23)} alt="" loading="lazy"></div><p>\u041D\u0430\u043D\u0435\u0441\u0442\u0438 \u043F\u043E\u043B\u043E\u0441\u043A\u0443 \u0433\u0435\u043B\u044F \u0434\u043B\u0438\u043D\u043E\u0439 1-3 \u0441\u043C</p></li><li class="steps__item"><div class="steps__img"><img${ssrRenderAttr("src", _imports_24)} alt="" loading="lazy"></div><p>\u0421\u043B\u0435\u0433\u043A\u0430 \u0432\u0442\u0435\u0440\u0435\u0442\u044C \u0434\u043E \u043F\u043E\u043B\u043D\u043E\u0433\u043E \u0432\u043F\u0438\u0442\u044B\u0432\u0430\u043D\u0438\u044F</p></li><li class="steps__item"><div class="steps__img"><img${ssrRenderAttr("src", _imports_25)} alt="" loading="lazy"></div><p>\u041C\u043E\u0436\u043D\u043E \u043D\u0430\u043D\u043E\u0441\u0438\u0442\u044C \u043F\u043E\u0434 \u043E\u043A\u043A\u043B\u044E\u0437\u0438\u043E\u043D\u043D\u0443\u044E \u043F\u043E\u0432\u044F\u0437\u043A\u0443</p></li></ul></div></div></section><section class="maternity" id="maternity"><div class="maternity__wrapper container"><div class="maternity__content"><div class="maternity__text"><h2 class="title-h1">\u041A\u0430\u043A \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0442\u044C \u043F\u0440\u0438 \u0431\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u0438<sup>3</sup></h2><img${ssrRenderAttr("src", _imports_26)} alt="\u0411\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u044C" loading="lazy"><p>\u041F\u0440\u0435\u043F\u0430\u0440\u0430\u0442 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D \u0432 II \u0438 III \u0442\u0440\u0438\u043C\u0435\u0441\u0442\u0440\u0430\u0445 \u0431\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u0438, \u0435\u0441\u043B\u0438 \u043E\u0436\u0438\u0434\u0430\u0435\u043C\u0430\u044F \u043F\u043E\u043B\u044C\u0437\u0430 \u0434\u043B\u044F \u043C\u0430\u043C\u044B \u0432\u044B\u0448\u0435, \u0447\u0435\u043C \u043F\u043E\u0442\u0435\u043D\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0439 \u0440\u0438\u0441\u043A \u0434\u043B\u044F \u0440\u0435\u0431\u0435\u043D\u043A\u0430.<br><br>\u041F\u0435\u0440\u0435\u0434 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435\u043C \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0431\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u043C \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E \u043D\u0443\u0436\u043D\u043E \u043F\u0440\u043E\u043A\u043E\u043D\u0441\u0443\u043B\u044C\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u0441 \u0432\u0440\u0430\u0447\u043E\u043C.</p></div><div class="maternity__img"><img${ssrRenderAttr("src", _imports_26)} alt="\u0411\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u044C" loading="lazy"></div></div></div></section><section class="others" id="products"><div class="others__wrapper container"><div class="others__content"><h2 class="title-h1">\u0414\u0440\u0443\u0433\u0438\u0435 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u044B \u043B\u0438\u043D\u0435\u0439\u043A\u0438 <br>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup></h2><div class="others__list"><div class="others__item"><img${ssrRenderAttr("src", _imports_28)} alt="" loading="lazy"><p><strong class="others-violet">\u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u044F \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u2014</strong>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u041D\u0435\u043E \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439<sup>5</sup> \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439<sup>6</sup></p>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/neo",
        id: "neo"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="others__item"><img${ssrRenderAttr("src", _imports_28$1)} alt="" loading="lazy"><p><strong class="others-orange">\u0414\u043B\u044F \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup>**</sup> \u0438\u0437\u043D\u0443\u0442\u0440\u0438</strong> \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432<sup>7</sup></p>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/troxactive",
        id: "troxactive"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="others__swiper">`);
      _push(ssrRenderComponent(unref(Swiper), {
        "slides-per-view": 1,
        "space-between": 20,
        onSwiper,
        modules: [unref(Navigation)],
        navigation: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="others__item"${_scopeId2}><img${ssrRenderAttr("src", _imports_28)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}><strong class="others-violet"${_scopeId2}>\u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u044F \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> \u2014</strong>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> \u041D\u0435\u043E \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439<sup${_scopeId2}>5</sup> \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439<sup${_scopeId2}>6</sup></p>`);
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/neo",
                    id: "neo"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "others__item" }, [
                      createVNode("img", {
                        src: _imports_28,
                        alt: "",
                        loading: "lazy"
                      }),
                      createVNode("p", null, [
                        createVNode("strong", { class: "others-violet" }, [
                          createTextVNode("\u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u044F \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                          createVNode("sup", null, "\xAE"),
                          createTextVNode(" \u2014")
                        ]),
                        createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(" \u041D\u0435\u043E \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439"),
                        createVNode("sup", null, "5"),
                        createTextVNode(" \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439"),
                        createVNode("sup", null, "6")
                      ]),
                      createVNode(_component_NuxtLink, {
                        to: "/neo",
                        id: "neo"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="others__item"${_scopeId2}><img${ssrRenderAttr("src", _imports_28$1)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}><strong class="others-orange"${_scopeId2}>\u0414\u043B\u044F \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup${_scopeId2}>**</sup> \u0438\u0437\u043D\u0443\u0442\u0440\u0438</strong> \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432<sup${_scopeId2}>7</sup></p>`);
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/troxactive",
                    id: "troxactive"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "others__item" }, [
                      createVNode("img", {
                        src: _imports_28$1,
                        alt: "",
                        loading: "lazy"
                      }),
                      createVNode("p", null, [
                        createVNode("strong", { class: "others-orange" }, [
                          createTextVNode("\u0414\u043B\u044F \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430"),
                          createVNode("sup", null, "**"),
                          createTextVNode(" \u0438\u0437\u043D\u0443\u0442\u0440\u0438")
                        ]),
                        createTextVNode(" \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432"),
                        createVNode("sup", null, "7")
                      ]),
                      createVNode(_component_NuxtLink, {
                        to: "/troxactive",
                        id: "troxactive"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "others__item" }, [
                    createVNode("img", {
                      src: _imports_28,
                      alt: "",
                      loading: "lazy"
                    }),
                    createVNode("p", null, [
                      createVNode("strong", { class: "others-violet" }, [
                        createTextVNode("\u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u044F \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(" \u2014")
                      ]),
                      createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                      createVNode("sup", null, "\xAE"),
                      createTextVNode(" \u041D\u0435\u043E \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439"),
                      createVNode("sup", null, "5"),
                      createTextVNode(" \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439"),
                      createVNode("sup", null, "6")
                    ]),
                    createVNode(_component_NuxtLink, {
                      to: "/neo",
                      id: "neo"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "others__item" }, [
                    createVNode("img", {
                      src: _imports_28$1,
                      alt: "",
                      loading: "lazy"
                    }),
                    createVNode("p", null, [
                      createVNode("strong", { class: "others-orange" }, [
                        createTextVNode("\u0414\u043B\u044F \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430"),
                        createVNode("sup", null, "**"),
                        createTextVNode(" \u0438\u0437\u043D\u0443\u0442\u0440\u0438")
                      ]),
                      createTextVNode(" \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432"),
                      createVNode("sup", null, "7")
                    ]),
                    createVNode(_component_NuxtLink, {
                      to: "/troxactive",
                      id: "troxactive"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></section><section class="faq" id="faq"><div class="faq__wrapper container"><div class="faq__content"><h2 class="title-h1">\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u0433\u0435\u043B\u044C 2 %</h2><div class="instruction"><div class="instruction__list"><div class="instruction__item"><div class="instruction__title"><h5>\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u041F N012713/02</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0422\u043E\u0440\u0433\u043E\u0432\u043E\u0435 \u043D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u043E\u0435 \u043D\u0435\u043F\u0430\u0442\u0435\u043D\u0442\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u043D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u0422\u0440\u043E\u043A\u0441\u0435\u0440\u0443\u0442\u0438\u043D</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u0413\u0435\u043B\u044C \u0434\u043B\u044F \u043D\u0430\u0440\u0443\u0436\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0421\u043E\u0441\u0442\u0430\u0432</h5><div class="accordion-btn"></div></div><div class="instruction__desc">100 \u0433 \u0433\u0435\u043B\u044F \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442: \u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u0432\u0435\u0449\u0435\u0441\u0442\u0432\u043E: \u0442\u0440\u043E\u043A\u0441\u0435\u0440\u0443\u0442\u0438\u043D 2,0 \u0433; \u0412\u0441\u043F\u043E\u043C\u043E\u0433\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0432\u0435\u0449\u0435\u0441\u0442\u0432\u0430: \u043A\u0430\u0440\u0431\u043E\u043C\u0435\u0440 0,60 \u0433, \u0442\u0440\u043E\u043B\u0430\u043C\u0438\u043D (\u0442\u0440\u0438\u044D\u0442\u0430\u043D\u043E\u043B\u0430\u043C\u0438\u043D) 0,70 \u0433, \u0434\u0438\u043D\u0430\u0442\u0440\u0438\u044F \u044D\u0434\u0435\u0442\u0430\u0442\u0430 \u0434\u0438\u0433\u0438\u0434\u0440\u0430\u0442 0,05 \u0433, \u0431\u0435\u043D\u0437\u0430\u043B\u043A\u043E\u043D\u0438\u044F \u0445\u043B\u043E\u0440\u0438\u0434 0,10 \u0433, \u0432\u043E\u0434\u0430 \u043E\u0447\u0438\u0449\u0435\u043D\u043D\u0430\u044F 96,55 \u0433.</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u0413\u0435\u043B\u044C \u043E\u0442 \u0436\u0435\u043B\u0442\u043E\u0433\u043E \u0434\u043E \u0441\u0432\u0435\u0442\u043B\u043E-\u043A\u043E\u0440\u0438\u0447\u043D\u0435\u0432\u043E\u0433\u043E \u0446\u0432\u0435\u0442\u0430</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0424\u0430\u0440\u043C\u0430\u043A\u043E\u0442\u0435\u0440\u0430\u043F\u0435\u0432\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0433\u0440\u0443\u043F\u043F\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u0412\u0435\u043D\u043E\u0442\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u044E\u0449\u0435\u0435 \u0438 \u0432\u0435\u043D\u043E\u043F\u0440\u043E\u0442\u0435\u043A\u0442\u043E\u0440\u043D\u043E\u0435 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043E</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041A\u043E\u0434 \u0410\u0422\u0425</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u042105\u0421\u041004</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0424\u0430\u0440\u043C\u0430\u043A\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435</h5><div class="accordion-btn"></div></div><div class="instruction__desc"><strong>\u0424\u0430\u0440\u043C\u0430\u043A\u043E\u0434\u0438\u043D\u0438\u043C\u0438\u043A\u0430</strong><br>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 \u0441\u043E\u0431\u043E\u0439 \u0444\u043B\u0430\u0432\u043E\u043D\u043E\u0438\u0434 (\u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u043D\u043E\u0435 \u0440\u0443\u0442\u0438\u043D\u0430). \u041E\u0431\u043B\u0430\u0434\u0430\u0435\u0442 \u0420-\u0432\u0438\u0442\u0430\u043C\u0438\u043D\u043D\u043E\u0439 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u044C\u044E; \u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0432\u0435\u043D\u043E\u0442\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u044E\u0449\u0435\u0435, \u0432\u0435\u043D\u043E\u043F\u0440\u043E\u0442\u0435\u043A\u0442\u043E\u0440\u043D\u043E\u0435, \u043F\u0440\u043E\u0442\u0438\u0432\u043E\u043E\u0442\u0435\u0447\u043D\u043E\u0435, \u043F\u0440\u043E\u0442\u0438\u0432\u043E\u0432\u043E\u0441\u043F\u0430\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435, \u043F\u0440\u043E\u0442\u0438\u0432\u043E\u0441\u0432\u0435\u0440\u0442\u044B\u0432\u0430\u044E\u0449\u0435\u0435 \u0438 \u0430\u043D\u0442\u0438\u043E\u043A\u0441\u0438\u0434\u0430\u043D\u0442\u043D\u043E\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435.<br><br>\u0423\u043C\u0435\u043D\u044C\u0448\u0430\u0435\u0442 \u043F\u0440\u043E\u043D\u0438\u0446\u0430\u0435\u043C\u043E\u0441\u0442\u044C \u0438 \u043B\u043E\u043C\u043A\u043E\u0441\u0442\u044C \u043A\u0430\u043F\u0438\u043B\u043B\u044F\u0440\u043E\u0432, \u043F\u043E\u0432\u044B\u0448\u0430\u0435\u0442 \u0438\u0445 \u0442\u043E\u043D\u0443\u0441.<br><br>\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0432\u0430\u0435\u0442 \u043F\u043B\u043E\u0442\u043D\u043E\u0441\u0442\u044C \u0441\u043E\u0441\u0443\u0434\u0438\u0441\u0442\u043E\u0439 \u0441\u0442\u0435\u043D\u043A\u0438, \u0443\u043C\u0435\u043D\u044C\u0448\u0430\u0435\u0442 \u044D\u043A\u0441\u0441\u0443\u0434\u0430\u0446\u0438\u044E \u0436\u0438\u0434\u043A\u043E\u0439 \u0447\u0430\u0441\u0442\u0438 \u043F\u043B\u0430\u0437\u043C\u044B \u0438 \u0434\u0438\u0430\u043F\u0435\u0434\u0435\u0437 \u043A\u043B\u0435\u0442\u043E\u043A \u043A\u0440\u043E\u0432\u0438.<br><br>\u0423\u043C\u0435\u043D\u044C\u0448\u0430\u0435\u0442 \u0432\u043E\u0441\u043F\u0430\u043B\u0435\u043D\u0438\u0435 \u0432 \u0441\u043E\u0441\u0443\u0434\u0438\u0441\u0442\u043E\u0439 \u0441\u0442\u0435\u043D\u043A\u0435, \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0438\u0432\u0430\u044F \u043F\u0440\u0438\u043B\u0438\u043F\u0430\u043D\u0438\u0435 \u0442\u0440\u043E\u043C\u0431\u043E\u0446\u0438\u0442\u043E\u0432 \u043A \u0435\u0435 \u043F\u043E\u0432\u0435\u0440\u0445\u043D\u043E\u0441\u0442\u0438.<br><br><strong>\u0424\u0430\u0440\u043C\u0430\u043A\u043E\u043A\u0438\u043D\u0435\u0442\u0438\u043A\u0430</strong><br>\u041F\u0440\u0438 \u043D\u0430\u043D\u0435\u0441\u0435\u043D\u0438\u0438 \u0433\u0435\u043B\u044F \u043D\u0430 \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u043F\u043E\u0440\u0430\u0436\u0435\u043D\u0438\u044F, \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u0432\u0435\u0449\u0435\u0441\u0442\u0432\u043E \u0431\u044B\u0441\u0442\u0440\u043E \u043F\u0440\u043E\u043D\u0438\u043A\u0430\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 \u044D\u043F\u0438\u0434\u0435\u0440\u043C\u0438\u0441, \u0447\u0435\u0440\u0435\u0437 30 \u043C\u0438\u043D\u0443\u0442 \u043E\u0431\u043D\u0430\u0440\u0443\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F \u0432 \u0434\u0435\u0440\u043C\u0435, \u0430 \u0447\u0435\u0440\u0435\u0437 2-5 \u0447\u0430\u0441\u043E\u0432 \u0432 \u043F\u043E\u0434\u043A\u043E\u0436\u043D\u043E\u0439 \u0436\u0438\u0440\u043E\u0432\u043E\u0439 \u043A\u043B\u0435\u0442\u0447\u0430\u0442\u043A\u0435.</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u043E\u043A\u0430\u0437\u0430\u043D\u0438\u044F \u043A \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E</h5><div class="accordion-btn"></div></div><div class="instruction__desc"><ul><li>\u0412\u0430\u0440\u0438\u043A\u043E\u0437\u043D\u043E\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0432\u0435\u043D \u043D\u043E\u0433;</li><li>\u0425\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0432\u0435\u043D\u043E\u0437\u043D\u0430\u044F \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0441 \u0442\u0430\u043A\u0438\u043C\u0438 \u043F\u0440\u043E\u044F\u0432\u043B\u0435\u043D\u0438\u044F\u043C\u0438, \u043A\u0430\u043A: \u043E\u0442\u0435\u043A\u0438, \u0431\u043E\u043B\u044C, \u043E\u0449\u0443\u0449\u0435\u043D\u0438\u0435 \u0442\u044F\u0436\u0435\u0441\u0442\u0438 \u0432 \u043D\u043E\u0433\u0430\u0445;</li><li>\u041F\u043E\u0432\u0435\u0440\u0445\u043D\u043E\u0441\u0442\u043D\u044B\u0439 \u0442\u0440\u043E\u043C\u0431\u043E\u0444\u043B\u0435\u0431\u0438\u0442, \u043F\u0435\u0440\u0438\u0444\u043B\u0435\u0431\u0438\u0442, \u0444\u043B\u0435\u0431\u043E\u0442\u0440\u043E\u043C\u0431\u043E\u0437;</li><li>\u041F\u043E\u0441\u0442\u0442\u0440\u043E\u043C\u0431\u043E\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0441\u0438\u043D\u0434\u0440\u043E\u043C;</li><li>\u041F\u043E\u0441\u0442\u0442\u0440\u043E\u043C\u0431\u043E\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043E\u0442\u0435\u043A, \u0433\u0435\u043C\u0430\u0442\u043E\u043C\u044B;</li><li>\u041F\u0440\u043E\u0444\u0438\u043B\u0430\u043A\u0442\u0438\u043A\u0430 \u043E\u0441\u043B\u043E\u0436\u043D\u0435\u043D\u0438\u0439 \u043F\u043E\u0441\u043B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043D\u0430 \u0432\u0435\u043D\u0430\u0445.</li></ul></div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u0440\u043E\u0442\u0438\u0432\u043E\u043F\u043E\u043A\u0430\u0437\u0430\u043D\u0438\u044F</h5><div class="accordion-btn"></div></div><div class="instruction__desc"><ul><li>\u041F\u043E\u0432\u044B\u0448\u0435\u043D\u043D\u0430\u044F \u0447\u0443\u0432\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u043A \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0443;</li><li>\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u0438\u0435 \u0446\u0435\u043B\u043E\u0441\u0442\u043D\u043E\u0441\u0442\u0438 \u043A\u043E\u0436\u043D\u044B\u0445 \u043F\u043E\u043A\u0440\u043E\u0432\u043E\u0432;</li><li>\u0414\u0435\u0442\u0441\u043A\u0438\u0439 \u0432\u043E\u0437\u0440\u0430\u0441\u0442 \u0434\u043E 18 \u043B\u0435\u0442 (\u043E\u043F\u044B\u0442 \u043A\u043B\u0438\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u0435\u043D).</li></ul></div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0421 \u043E\u0441\u0442\u043E\u0440\u043E\u0436\u043D\u043E\u0441\u0442\u044C\u044E</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0425\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043F\u043E\u0447\u0435\u0447\u043D\u0430\u044F \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C (\u043F\u0440\u0438 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u043C \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0438).<br><br> \u0415\u0441\u043B\u0438 \u0443 \u0412\u0430\u0441 \u0435\u0441\u0442\u044C \u043E\u0434\u043D\u043E \u0438\u0437 \u043F\u0435\u0440\u0435\u0447\u0438\u0441\u043B\u0435\u043D\u043D\u044B\u0445 \u0432\u044B\u0448\u0435 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0439, \u043F\u0435\u0440\u0435\u0434 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435\u043C \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043F\u0440\u043E\u043A\u043E\u043D\u0441\u0443\u043B\u044C\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u0441 \u0432\u0440\u0430\u0447\u043E\u043C. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043F\u0440\u0438 \u0431\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u0438 \u0432 \u043F\u0435\u0440\u0438\u043E\u0434 \u0433\u0440\u0443\u0434\u043D\u043E\u0433\u043E \u0432\u0441\u043A\u0430\u0440\u043C\u043B\u0438\u0432\u0430\u043D\u0438\u044F</h5><div class="accordion-btn"></div></div><div class="instruction__desc"><strong>\u0411\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u044C</strong><br> \u0412 I \u0442\u0440\u0438\u043C\u0435\u0441\u0442\u0440\u0435 \u0431\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u043F\u0440\u043E\u0442\u0438\u0432\u043E\u043F\u043E\u043A\u0430\u0437\u0430\u043D\u043E \u0432 \u0441\u0432\u044F\u0437\u0438 \u0441 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u0435\u043C \u043E\u043F\u044B\u0442\u0430 \u043A\u043B\u0438\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F. \u0412\u043E II \u0438 III \u0442\u0440\u0438\u043C\u0435\u0441\u0442\u0440\u0430\u0445 \u0431\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E \u0432 \u0441\u043B\u0443\u0447\u0430\u0435, \u0435\u0441\u043B\u0438 \u043E\u0436\u0438\u0434\u0430\u0435\u043C\u0430\u044F \u043F\u043E\u043B\u044C\u0437\u0430 \u0434\u043B\u044F \u043C\u0430\u0442\u0435\u0440\u0438 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043F\u043E\u0442\u0435\u043D\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0439 \u0440\u0438\u0441\u043A \u0434\u043B\u044F \u043F\u043B\u043E\u0434\u0430. \u041F\u0435\u0440\u0435\u0434 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435\u043C \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0432\u043E II \u0438 III \u0442\u0440\u0438\u043C\u0435\u0441\u0442\u0440\u0430\u0445 \u0431\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043F\u0440\u043E\u043A\u043E\u043D\u0441\u0443\u043B\u044C\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u0441 \u0432\u0440\u0430\u0447\u043E\u043C.<br><br><strong>\u041F\u0435\u0440\u0438\u043E\u0434 \u0433\u0440\u0443\u0434\u043D\u043E\u0433\u043E \u0432\u0441\u043A\u0430\u0440\u043C\u043B\u0438\u0432\u0430\u043D\u0438\u044F</strong><br> \u0414\u0430\u043D\u043D\u044B\u0435 \u043E \u043F\u0440\u043E\u043D\u0438\u043A\u043D\u043E\u0432\u0435\u043D\u0438\u0438 \u0442\u0440\u043E\u043A\u0441\u0435\u0440\u0443\u0442\u0438\u043D\u0430 \u0432 \u0433\u0440\u0443\u0434\u043D\u043E\u0435 \u043C\u043E\u043B\u043E\u043A\u043E \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u044E\u0442. \u041F\u0440\u0435\u043F\u0430\u0440\u0430\u0442 \u043D\u0435 \u0441\u043B\u0435\u0434\u0443\u0435\u0442 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0442\u044C \u0432 \u043F\u0435\u0440\u0438\u043E\u0434 \u0433\u0440\u0443\u0434\u043D\u043E\u0433\u043E \u0432\u0441\u043A\u0430\u0440\u043C\u043B\u0438\u0432\u0430\u043D\u0438\u044F. </div></div></div><div class="instruction__list"><div class="instruction__item"><div class="instruction__title"><h5>\u0421\u043F\u043E\u0441\u043E\u0431 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0438 \u0434\u043E\u0437\u044B</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u041D\u0430\u0440\u0443\u0436\u043D\u043E!<br><br> \u0415\u0441\u043B\u0438 \u0432\u0440\u0430\u0447\u043E\u043C \u043D\u0435 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u043E\u0432\u0430\u043D\u043E \u0438\u043D\u0430\u0447\u0435, \u0442\u043E \u043F\u043E\u043B\u043E\u0441\u043A\u0443 \u0433\u0435\u043B\u044F \u0434\u043B\u0438\u043D\u043E\u0439 1-3 \u0441\u043C (\u0432 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0438 \u043E\u0442 \u043F\u043B\u043E\u0449\u0430\u0434\u0438 \u043F\u043E\u0440\u0430\u0436\u0435\u043D\u043D\u043E\u0439 \u043F\u043E\u0432\u0435\u0440\u0445\u043D\u043E\u0441\u0442\u0438) \u043D\u0430\u043D\u043E\u0441\u044F\u0442 \u0442\u043E\u043D\u043A\u0438\u043C \u0441\u043B\u043E\u0435\u043C \u043D\u0430 \u043A\u043E\u0436\u0443 \u043D\u0430 \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u043F\u043E\u0440\u0430\u0436\u0435\u043D\u0438\u044F 2 \u0440\u0430\u0437\u0430 \u0432 \u0441\u0443\u0442\u043A\u0438 \u0443\u0442\u0440\u043E\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C, \u043C\u044F\u0433\u043A\u043E \u0432\u0442\u0438\u0440\u0430\u044F \u0434\u043E \u043F\u043E\u043B\u043D\u043E\u0433\u043E \u0432\u043F\u0438\u0442\u044B\u0432\u0430\u043D\u0438\u044F. \u041F\u0440\u0438 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u0438 \u0433\u0435\u043B\u044C \u043C\u043E\u0436\u043D\u043E \u043D\u0430\u043D\u043E\u0441\u0438\u0442\u044C \u043F\u043E\u0434 \u043E\u043A\u043A\u043B\u044E\u0437\u0438\u043E\u043D\u043D\u0443\u044E \u043F\u043E\u0432\u044F\u0437\u043A\u0443.<br><br> \u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u0442\u0441\u044F \u0441\u043E\u0447\u0435\u0442\u0430\u0442\u044C \u0441 \u043F\u0440\u0438\u0435\u043C\u043E\u043C \u043A\u0430\u043F\u0441\u0443\u043B \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0434\u043B\u044F \u0443\u0441\u0438\u043B\u0435\u043D\u0438\u044F \u0432\u043E\u0437\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F.<br><br> \u0415\u0441\u043B\u0438 \u0447\u0435\u0440\u0435\u0437 6-7 \u0434\u043D\u0435\u0439 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0443\u043B\u0443\u0447\u0448\u0435\u043D\u0438\u044F \u043D\u0435 \u043D\u0430\u0441\u0442\u0443\u043F\u0430\u0435\u0442 \u0438\u043B\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u044B \u0443\u0441\u0443\u0433\u0443\u0431\u043B\u044F\u044E\u0442\u0441\u044F, \u0438\u043B\u0438 \u043F\u043E\u044F\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u043D\u043E\u0432\u044B\u0435 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u044B, \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043F\u0440\u043E\u043A\u043E\u043D\u0441\u0443\u043B\u044C\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u0441 \u0432\u0440\u0430\u0447\u043E\u043C.<br><br> \u041F\u0440\u0438\u043C\u0435\u043D\u044F\u0439\u0442\u0435 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u043E \u0442\u0435\u043C \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u0438\u044F\u043C, \u0442\u043E\u043C\u0443 \u0441\u043F\u043E\u0441\u043E\u0431\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0438 \u0432 \u0442\u0435\u0445 \u0434\u043E\u0437\u0430\u0445, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u044B \u0432 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u043E\u0431\u043E\u0447\u043D\u043E\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u041D\u0430\u0440\u0443\u0448\u0435\u043D\u0438\u044F \u0441\u043E \u0441\u0442\u043E\u0440\u043E\u043D\u044B \u0438\u043C\u043C\u0443\u043D\u043D\u043E\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u044B: \u0440\u0435\u0434\u043A\u043E \u2014 \u043A\u0440\u0430\u043F\u0438\u0432\u043D\u0438\u0446\u0430, \u044D\u043A\u0437\u0435\u043C\u0430, \u0434\u0435\u0440\u043C\u0430\u0442\u0438\u0442.<br><br> \u0415\u0441\u043B\u0438 \u0443 \u0412\u0430\u0441 \u043E\u0442\u043C\u0435\u0447\u0430\u044E\u0442\u0441\u044F \u043F\u043E\u0431\u043E\u0447\u043D\u044B\u0435 \u044D\u0444\u0444\u0435\u043A\u0442\u044B, \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u044B\u0435 \u0432 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438, \u0438\u043B\u0438 \u043E\u043D\u0438 \u0443\u0441\u0443\u0433\u0443\u0431\u043B\u044F\u044E\u0442\u0441\u044F, \u0438\u043B\u0438 \u0412\u044B \u0437\u0430\u043C\u0435\u0442\u0438\u043B\u0438 \u043B\u044E\u0431\u044B\u0435 \u0434\u0440\u0443\u0433\u0438\u0435 \u043F\u043E\u0431\u043E\u0447\u043D\u044B\u0435 \u044D\u0444\u0444\u0435\u043A\u0442\u044B, \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u044B\u0435 \u0432 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438, \u0441\u043E\u043E\u0431\u0449\u0438\u0442\u0435 \u043E\u0431 \u044D\u0442\u043E\u043C \u0432\u0440\u0430\u0447\u0443. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u0435\u0440\u0435\u0434\u043E\u0437\u0438\u0440\u043E\u0432\u043A\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0421\u043B\u0443\u0447\u0430\u0438 \u043F\u0435\u0440\u0435\u0434\u043E\u0437\u0438\u0440\u043E\u0432\u043A\u0438 \u043F\u0440\u0438 \u043C\u0435\u0441\u0442\u043D\u043E\u043C \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0438 \u0442\u0440\u043E\u043A\u0441\u0435\u0440\u0443\u0442\u0438\u043D\u0430 \u043D\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u044B. \u041F\u0440\u0438 \u0441\u043B\u0443\u0447\u0430\u0439\u043D\u043E\u043C \u043F\u0440\u043E\u0433\u043B\u0430\u0442\u044B\u0432\u0430\u043D\u0438\u0438 \u0431\u043E\u043B\u044C\u0448\u043E\u0433\u043E \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u0430 \u0433\u0435\u043B\u044F \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043F\u0440\u043E\u0432\u0435\u0441\u0442\u0438 \u043E\u0431\u0449\u0438\u0435 \u043C\u0435\u0440\u044B \u0432\u044B\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 <br>\u0438\u0437 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u043C\u0430 (\u0440\u0432\u043E\u0442\u043D\u044B\u0435 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430) \u0438 \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u044C\u0441\u044F \u043A \u0432\u0440\u0430\u0447\u0443. <br><br>\u041F\u0440\u0438 \u043D\u0430\u043B\u0438\u0447\u0438\u0438 \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u0438\u0439 \u043F\u0440\u043E\u0432\u043E\u0434\u0438\u0442\u0441\u044F \u043F\u0435\u0440\u0438\u0442\u043E\u043D\u0435\u0430\u043B\u044C\u043D\u044B\u0439 \u0434\u0438\u0430\u043B\u0438\u0437.<br> \u041F\u0440\u0438 \u043F\u0435\u0440\u0435\u0434\u043E\u0437\u0438\u0440\u043E\u0432\u043A\u0435 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u044C\u0441\u044F \u043A \u0432\u0440\u0430\u0447\u0443. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0412\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0441 \u0434\u0440\u0443\u0433\u0438\u043C\u0438 \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u043C\u0438 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0414\u0430\u043D\u043D\u044B\u0445 \u043F\u043E \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044E \u0442\u0440\u043E\u043A\u0441\u0435\u0440\u0443\u0442\u0438\u043D\u0430 \u0441 \u0434\u0440\u0443\u0433\u0438\u043C\u0438 \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u043C\u0438 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438 \u043D\u0435\u0442. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041E\u0441\u043E\u0431\u044B\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0438\u044F</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0413\u0435\u043B\u044C \u043D\u0430\u043D\u043E\u0441\u044F\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 \u043D\u0435\u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0435\u043D\u043D\u0443\u044E \u043F\u043E\u0432\u0435\u0440\u0445\u043D\u043E\u0441\u0442\u044C.<br><br> \u0418\u0437\u0431\u0435\u0433\u0430\u0442\u044C \u043F\u043E\u043F\u0430\u0434\u0430\u043D\u0438\u044F \u043D\u0430 \u043E\u0442\u043A\u0440\u044B\u0442\u044B\u0435 \u0440\u0430\u043D\u044B, \u0433\u043B\u0430\u0437\u0430 \u0438 \u0441\u043B\u0438\u0437\u0438\u0441\u0442\u044B\u0435 \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u0438! \u041F\u0440\u0438 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F\u0445, \u0445\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0437\u0443\u044E\u0449\u0438\u0445\u0441\u044F \u043F\u043E\u0432\u044B\u0448\u0435\u043D\u043D\u043E\u0439 \u043F\u0440\u043E\u043D\u0438\u0446\u0430\u0435\u043C\u043E\u0441\u0442\u044C\u044E \u0441\u043E\u0441\u0443\u0434\u043E\u0432 (\u0432 \u0442.\u0447. \u043F\u0440\u0438 \u0441\u043A\u0430\u0440\u043B\u0430\u0442\u0438\u043D\u0435, \u0433\u0440\u0438\u043F\u043F\u0435, \u043A\u043E\u0440\u0438, \u0430\u043B\u043B\u0435\u0440\u0433\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0440\u0435\u0430\u043A\u0446\u0438\u044F\u0445), \u0433\u0435\u043B\u044C \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u044E\u0442 \u0432 \u0441\u043E\u0447\u0435\u0442\u0430\u043D\u0438\u0438 \u0441 \u0430\u0441\u043A\u043E\u0440\u0431\u0438\u043D\u043E\u0432\u043E\u0439 \u043A\u0438\u0441\u043B\u043E\u0442\u043E\u0439 \u0434\u043B\u044F \u0443\u0441\u0438\u043B\u0435\u043D\u0438\u044F \u0435\u0435 \u044D\u0444\u0444\u0435\u043A\u0442\u0430.<br><br> \u041D\u0435\u043B\u044C\u0437\u044F \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0442\u044C \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u044B\u0435 \u0441\u0440\u043E\u043A\u0438 \u0438 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u0437\u044B \u043F\u0440\u0438 \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u043E\u043C \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0438 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430.<br><br> \u0412 \u0441\u043B\u0443\u0447\u0430\u0435 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u044F \u0443\u043C\u0435\u043D\u044C\u0448\u0435\u043D\u0438\u044F \u0438\u043B\u0438 \u043F\u0440\u0438 \u0443\u0442\u044F\u0436\u0435\u043B\u0435\u043D\u0438\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u044F \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u044C\u0441\u044F \u043A \u0432\u0440\u0430\u0447\u0443.<br><br> \u0412\u043B\u0438\u044F\u043D\u0438\u0435 \u043D\u0430 \u0441\u043F\u043E\u0441\u043E\u0431\u043D\u043E\u0441\u0442\u044C \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u043D\u044B\u043C\u0438 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438, \u043C\u0435\u0445\u0430\u043D\u0438\u0437\u043C\u0430\u043C\u0438 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0433\u0435\u043B\u044C \u043D\u0435 \u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0432\u043B\u0438\u044F\u043D\u0438\u044F \u043D\u0430 \u0441\u043F\u043E\u0441\u043E\u0431\u043D\u043E\u0441\u0442\u044C \u0443\u043F\u0440\u0430\u0432\u043B\u044F\u0442\u044C \u0430\u0432\u0442\u043E\u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u043D\u044B\u043C \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043E\u043C \u0438 \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0441 \u0434\u0432\u0438\u0436\u0443\u0449\u0438\u043C\u0438\u0441\u044F. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0412\u043B\u0438\u044F\u043D\u0438\u0435 \u043D\u0430 \u0441\u043F\u043E\u0441\u043E\u0431\u043D\u043E\u0441\u0442\u044C \u043A \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044E \u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u043D\u044B\u043C\u0438 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438 \u0438 \u043C\u0435\u0445\u0430\u043D\u0438\u0437\u043C\u0430\u043C\u0438</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0433\u0435\u043B\u044C \u043D\u0435 \u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0432\u043B\u0438\u044F\u043D\u0438\u044F \u043D\u0430 \u0441\u043F\u043E\u0441\u043E\u0431\u043D\u043E\u0441\u0442\u044C \u0443\u043F\u0440\u0430\u0432\u043B\u044F\u0442\u044C \u0430\u0432\u0442\u043E\u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u043D\u044B\u043C \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043E\u043C \u0438 \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0441 \u0434\u0432\u0438\u0436\u0443\u0449\u0438\u043C\u0438\u0441\u044F \u043C\u0435\u0445\u0430\u043D\u0438\u0437\u043C\u0430\u043C\u0438. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0424\u043E\u0440\u043C\u0430 \u0432\u044B\u043F\u0443\u0441\u043A\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0413\u0435\u043B\u044C \u0434\u043B\u044F \u043D\u0430\u0440\u0443\u0436\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F 2%. \u041F\u043E 40 \u0433 \u0432 \u0430\u043B\u044E\u043C\u0438\u043D\u0438\u0435\u0432\u0443\u044E \u0442\u0443\u0431\u0443 \u0441 \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u043C \u043B\u0430\u043A\u043E\u0432\u044B\u043C \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u0435\u043C \u0441 \u0430\u043B\u044E\u043C\u0438\u043D\u0438\u0435\u0432\u043E\u0439 \u043C\u0435\u043C\u0431\u0440\u0430\u043D\u043E\u0439 \u0438\u043B\u0438 \u043F\u043E 20 \u0433, 40 \u0433 \u0438\u043B\u0438 100 \u0433 \u0432 \u043B\u0430\u043C\u0438\u043D\u0430\u0442\u043D\u0443\u044E (\u043F\u043B\u0430\u0441\u0442\u0438\u043A\u043E\u0432\u0443\u044E) \u0442\u0443\u0431\u0443 \u0441 \u0430\u043B\u044E\u043C\u0438\u043D\u0438\u0435\u0432\u043E\u0439 \u043C\u0435\u043C\u0431\u0440\u0430\u043D\u043E\u0439. \u041A\u0430\u0436\u0434\u0443\u044E \u0442\u0443\u0431\u0443 \u0432\u043C\u0435\u0441\u0442\u0435 \u0441 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0435\u0439 \u043F\u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043F\u043E\u043C\u0435\u0449\u0430\u044E\u0442 \u0432 \u043A\u0430\u0440\u0442\u043E\u043D\u043D\u0443\u044E \u043F\u0430\u0447\u043A\u0443, \u043D\u0430 \u043A\u043E\u0442\u043E\u0440\u0443\u044E \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043C\u043E\u0433\u0443\u0442 \u0431\u044B\u0442\u044C \u043D\u0430\u043D\u0435\u0441\u0435\u043D\u044B \u0437\u0430\u0449\u0438\u0442\u043D\u044B\u0435 \u043D\u0430\u043A\u043B\u0435\u0439\u043A\u0438. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0425\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u0440\u0438 \u0442\u0435\u043C\u043F\u0435\u0440\u0430\u0442\u0443\u0440\u0435 \u043D\u0435 \u0432\u044B\u0448\u0435 25 \xB0\u0421. \u041D\u0435 \u0437\u0430\u043C\u043E\u0440\u0430\u0436\u0438\u0432\u0430\u0442\u044C! <br>\u0425\u0440\u0430\u043D\u0438\u0442\u044C \u0432 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E\u043C \u0434\u043B\u044F \u0434\u0435\u0442\u0435\u0439 \u043C\u0435\u0441\u0442\u0435! </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0421\u0440\u043E\u043A \u0433\u043E\u0434\u043D\u043E\u0441\u0442\u0438</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0414\u043B\u044F \u0430\u043B\u044E\u043C\u0438\u043D\u0438\u0435\u0432\u043E\u0439 \u0442\u0443\u0431\u044B \u2014 5 \u043B\u0435\u0442.<br> \u0414\u043B\u044F \u043B\u0430\u043C\u0438\u043D\u0430\u0442\u043D\u043E\u0439 (\u043F\u043B\u0430\u0441\u0442\u0438\u043A\u043E\u0432\u043E\u0439) \u0442\u0443\u0431\u044B \u2014 5 \u043B\u0435\u0442. <br>\u041D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0442\u044C \u043F\u043E \u0438\u0441\u0442\u0435\u0447\u0435\u043D\u0438\u0438 \u0441\u0440\u043E\u043A\u0430 \u0433\u043E\u0434\u043D\u043E\u0441\u0442\u0438. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u043E\u0442\u043F\u0443\u0441\u043A\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u041E\u0442\u043F\u0443\u0441\u043A\u0430\u044E\u0442 \u0431\u0435\u0437 \u0440\u0435\u0446\u0435\u043F\u0442\u0430 </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F, \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u044E\u0449\u0430\u044F \u043F\u0440\u0435\u0442\u0435\u043D\u0437\u0438\u0438 \u043F\u043E\u0442\u0440\u0435\u0431\u0438\u0442\u0435\u043B\u0435\u0439</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u041E\u041E\u041E \xAB\u0422\u0435\u0432\u0430\xBB, 115054, \u041C\u043E\u0441\u043A\u0432\u0430, \u0443\u043B. \u0412\u0430\u043B\u043E\u0432\u0430\u044F, 35, <br>\u0442\u0435\u043B.: +7 (495) 644 22 34, \u0444\u0430\u043A\u0441: +7 (495) 644 22 35 <br>\u0410\u0434\u0440\u0435\u0441 \u0432 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442\u0435: www.teva.ru </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0411\u0430\u043B\u043A\u0430\u043D\u0444\u0430\u0440\u043C\u0430-\u0422\u0440\u043E\u044F\u043D \u0410\u0414, <br>\u0411\u043E\u043B\u0433\u0430\u0440\u0438\u044F, \u0433. \u0422\u0440\u043E\u044F\u043D, 5600, \u0443\u043B. \u041A\u0440\u0430\u0439\u0440\u0435\u0447\u043D\u0430 1. </div></div></div></div><div class="faq__download"><a href="/pdf/instruction_gel.pdf" download>`);
      _push(ssrRenderComponent(_component_Button, {
        label: "\u0421\u043A\u0430\u0447\u0430\u0442\u044C PDF",
        rounded: ""
      }, null, _parent));
      _push(`</a></div></div></div></section><section class="sources"><div class="sources__wrapper container"><p>**\u041F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438 <br>1. \u0412 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u043D\u0430\u0440\u0443\u0436\u043D\u044B\u0445 \u0432\u0435\u043D\u043E\u0442\u043E\u043D\u0438\u043A\u043E\u0432, \u043F\u043E \u043F\u0440\u043E\u0434\u0430\u0436\u0430\u043C \u0432 \u0434\u0435\u043D\u044C\u0433\u0430\u0445 2018-2022, IQVIA <br>2. \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0432 \u0420\u043E\u0441\u0441\u0438\u0438 \u0441 1981 \u0433. \u0420\u0423 \u0411-8-242 \u21162654 <br>3. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u041F N012713/02 <br>4. \u041F\u043E \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E \u0441 \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u043E\u0439 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D \u0433\u0435\u043B\u044C 2% 40 \u0433. \u041F\u0440\u043E\u0446\u0435\u043D\u0442 \u044D\u043A\u043E\u043D\u043E\u043C\u0438\u0438 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D \u043F\u043E \u043E\u0442\u043F\u0443\u0441\u043A\u043D\u044B\u043C \u0446\u0435\u043D\u0430\u043C \u041E\u041E\u041E \xAB\u0422\u0435\u0432\u0430\xBB \u0434\u043B\u044F \u0443\u043F\u0430\u043A\u043E\u0432\u043E\u043A 40\u0433 \u0438 100\u0433 \u043F\u0440\u0438 \u0440\u0430\u0441\u0447\u0435\u0442\u0435 \u043D\u0430 1\u0433 (\u041C\u0430\u0440\u0442 2023) <br>5. \u041F\u043E \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E \u0441 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0433\u0435\u043B\u0435\u043C 2% <br>6. \u041B\u0438\u0441\u0442\u043E\u043A-\u0432\u043A\u043B\u0430\u0434\u044B\u0448 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u041D\u0435\u043E \u041B\u041F-\u2116(001509)-(\u0420\u0413-RU) https://portal.eaeunion.org/sites/commonprocesses/ru-ru/Pages/CardView.aspx?documentId=6206058bfb44f12d3bb0566b&amp;codeId=P.MM.01. \u0414\u0430\u0442\u0430 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F: 28.02.2023. <br>7. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u041B\u041F-\u2116 (000726)-(\u0420\u0413-RU) </p></div></section>`);
      _push(ssrRenderComponent(_component_ModalUteka, {
        visible: unref(visibleUteka),
        "onUpdate:visible": ($event) => isRef(visibleUteka) ? visibleUteka.value = $event : null,
        "url-products": productsForUteka
      }, null, _parent));
      _push(`</main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/gel.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=gel-1540b3d9.mjs.map
