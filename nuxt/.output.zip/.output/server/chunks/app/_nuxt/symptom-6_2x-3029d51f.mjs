import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_10 = "" + publicAssetsURL("img/product/symptom-6.png");
const _imports_11 = "" + publicAssetsURL("img/product/symptom-6@2x.webp");

export { _imports_10 as _, _imports_11 as a };
//# sourceMappingURL=symptom-6_2x-3029d51f.mjs.map
