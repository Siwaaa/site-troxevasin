import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_29 = "" + publicAssetsURL("img/product/other-gel.png");

export { _imports_29 as _ };
//# sourceMappingURL=other-gel-087b2220.mjs.map
