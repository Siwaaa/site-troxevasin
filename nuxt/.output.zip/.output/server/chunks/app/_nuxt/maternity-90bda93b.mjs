import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_6 = "" + publicAssetsURL("img/product/symptom.png");
const _imports_7 = "" + publicAssetsURL("img/product/symptom@2x.webp");
const _imports_26 = "" + publicAssetsURL("img/product/maternity.png");

export { _imports_6 as _, _imports_7 as a, _imports_26 as b };
//# sourceMappingURL=maternity-90bda93b.mjs.map
