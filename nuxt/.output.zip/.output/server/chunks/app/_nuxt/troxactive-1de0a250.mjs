import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { u as useHead, _ as __nuxt_component_0$1, a as __nuxt_component_0$2, b as __nuxt_component_3$1, d as _export_sfc } from '../server.mjs';
import { ref, withCtx, createVNode, unref, createTextVNode, isRef, useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _imports_8, a as _imports_9 } from './symptom-3_2x-91dbf5e3.mjs';
import { _ as _imports_10, a as _imports_11 } from './symptom-6_2x-3029d51f.mjs';
import { _ as _imports_12, a as _imports_13 } from './symptom-8_2x-46da890a.mjs';
import { _ as _imports_28 } from './other-gel-neo-1056c3e4.mjs';
import { _ as _imports_29 } from './other-gel-087b2220.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Navigation, EffectFade, Pagination } from 'swiper';
import 'vue-bundle-renderer/runtime';
import 'h3';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _imports_0$1 = "" + publicAssetsURL("img/modal/table.svg");
const _imports_1$1 = "" + publicAssetsURL("img/modal/table-mob.svg");
const _sfc_main$1 = {
  emits: ["update:visible"],
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      mask: null
    };
  },
  methods: {
    closeModal() {
      this.$emit("update:visible", false);
    },
    maskRef(el) {
      this.mask = el;
    },
    onMaskClick(event) {
      if (this.mask === event.target) {
        this.closeModal();
      }
    },
    onEnter() {
      document.body.style.overflow = "hidden";
    },
    onAfterLeave() {
      document.body.style.overflow = "auto";
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  if ($props.visible) {
    _push(`<div${ssrRenderAttrs(mergeProps({
      ref: $options.maskRef,
      class: "modal-mask"
    }, _attrs))}><div class="modal"><div class="modal__content"><div class="modal__header"><h3 class="title-h1">\u0420\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u041C\u041E\u0424\u0424 \u043F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435<sup>*,1</sup></h3></div><div class="modal__main"><div class="moff"><img${ssrRenderAttr("src", _imports_0$1)}${ssrRenderAttr("srcset", _imports_0$1 + " 1x, " + _imports_1$1 + " 640w")} alt=""></div></div><div class="modal__footer"><p>https://cr.minzdrav.gov.ru/schema/178_1. \u0414\u0430\u0442\u0430 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F:\u0438 28.02.2023</p></div></div><button class="modal__close" type="button" aria-label="close"><div class="modal__close-right"></div><div class="modal__close-left"></div></button></div></div>`);
  } else {
    _push(`<!---->`);
  }
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/modal/Moff.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _imports_0 = "" + publicAssetsURL("img/product/p-trox-1.png");
const _imports_1 = "" + publicAssetsURL("img/product/p-trox-1@2x.webp");
const _imports_2 = "" + publicAssetsURL("img/product/p-trox-2.png");
const _imports_3 = "" + publicAssetsURL("img/product/p-trox-2@2x.webp");
const _imports_4 = "" + publicAssetsURL("img/product/p-trox-3.png");
const _imports_5 = "" + publicAssetsURL("img/product/p-trox-3@2x.webp");
const _imports_6 = "" + publicAssetsURL("img/product/symptoms-trox.png");
const _imports_7 = "" + publicAssetsURL("img/product/symptoms-trox@2x.webp");
const _imports_14 = "" + publicAssetsURL("img/product/symptom-11.png");
const _imports_15 = "" + publicAssetsURL("img/product/symptom-11@2x.webp");
const _imports_16 = "" + publicAssetsURL("img/product/chronic-1.png");
const _imports_17 = "" + publicAssetsURL("img/product/chronic-1@2x.webp");
const _imports_18 = "" + publicAssetsURL("img/product/chronic-2.png");
const _imports_19 = "" + publicAssetsURL("img/product/chronic-2@2x.webp");
const _imports_20 = "" + publicAssetsURL("img/product/chronic-3.png");
const _imports_21 = "" + publicAssetsURL("img/product/chronic-3@2x.webp");
const _imports_22 = "" + publicAssetsURL("img/product/economy-two-1.webp");
const _imports_23 = "" + publicAssetsURL("img/product/economy-two-2.webp");
const _imports_24 = "" + publicAssetsURL("img/product/guide-4.svg");
const _imports_25 = "" + publicAssetsURL("img/product/guide-5.svg");
const _imports_26 = "" + publicAssetsURL("img/product/guide-6.svg");
const _imports_27 = "" + publicAssetsURL("img/product/guide-7.svg");
const _sfc_main = {
  __name: "troxactive",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432"
    });
    const onSwiper = (swiper) => {
    };
    const onSwiperEconomy = (swiper) => {
    };
    const onSwiperGuide = (swiper) => {
    };
    const onSwiperHeader = (swiper) => {
    };
    const pagination = ref({
      clickable: true,
      renderBullet: function(index, className) {
        let pagiText = null;
        switch (index) {
          case 0:
            pagiText = "30 \u0442";
            break;
          case 1:
            pagiText = "60 \u0442";
            break;
          case 2:
            pagiText = "90 \u0442";
            break;
        }
        return '<span class="' + className + '">' + pagiText + "</span>";
      }
    });
    ref(null);
    const visible = ref(false);
    const visibleUteka = ref(false);
    let productsForUteka = null;
    const openUteka = (i) => {
      i && typeof i === "string" ? productsForUteka = i : productsForUteka = "https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944";
      visibleUteka.value = true;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Button = __nuxt_component_0$1;
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_ModalMoff = __nuxt_component_2;
      const _component_ModalUteka = __nuxt_component_3$1;
      _push(`<main${ssrRenderAttrs(_attrs)}><header class="header-product" id="header"><div class="header-product__wrapper container"><div class="header-product__content"><h1 class="title-h1"><strong>\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438 </strong>\u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0442 \u043D\u0430 \u0432\u0435\u043D\u044B \u0438\u0437\u043D\u0443\u0442\u0440\u0438 \u043F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435<sup>*,1</sup></h1><p>\u0421\u0430\u043C\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0430\u0435\u043C\u043E\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u0432\u0435\u0449\u0435\u0441\u0442\u0432\u043E (\u041C\u041D\u041D) \u0434\u043B\u044F \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0439 \u0432\u0435\u043D<sup>2</sup></p><div class="header-product__menu">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: openUteka,
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_troxactive_1"
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "#faq",
        id: "troxactive_faq_1"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
              arrowRight: "",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
                arrowRight: "",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="header-product__swiper">`);
      _push(ssrRenderComponent(unref(Swiper), {
        initialSlide: 2,
        "slides-per-view": 1,
        "space-between": 50,
        effect: "fade",
        "fade-effect": { crossFade: true },
        speed: 1300,
        "grab-cursor": true,
        onSwiper: onSwiperHeader,
        modules: [unref(Navigation), unref(EffectFade), unref(Pagination)],
        navigation: "",
        pagination: unref(pagination)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="header-product__swiper-item"${_scopeId2}><img${ssrRenderAttr("src", _imports_0)}${ssrRenderAttr("srcset", _imports_1 + " 2x")} alt="" loading="lazy"${_scopeId2}></div>`);
                } else {
                  return [
                    createVNode("div", { class: "header-product__swiper-item" }, [
                      createVNode("img", {
                        src: _imports_0,
                        srcset: _imports_1 + " 2x",
                        alt: "",
                        loading: "lazy"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="header-product__swiper-item"${_scopeId2}><img${ssrRenderAttr("src", _imports_2)}${ssrRenderAttr("srcset", _imports_3 + " 2x")} alt="" loading="lazy"${_scopeId2}></div>`);
                } else {
                  return [
                    createVNode("div", { class: "header-product__swiper-item" }, [
                      createVNode("img", {
                        src: _imports_2,
                        srcset: _imports_3 + " 2x",
                        alt: "",
                        loading: "lazy"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="header-product__swiper-item"${_scopeId2}><img${ssrRenderAttr("src", _imports_4)}${ssrRenderAttr("srcset", _imports_5 + " 2x")} alt="" loading="lazy"${_scopeId2}></div>`);
                } else {
                  return [
                    createVNode("div", { class: "header-product__swiper-item" }, [
                      createVNode("img", {
                        src: _imports_4,
                        srcset: _imports_5 + " 2x",
                        alt: "",
                        loading: "lazy"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "header-product__swiper-item" }, [
                    createVNode("img", {
                      src: _imports_0,
                      srcset: _imports_1 + " 2x",
                      alt: "",
                      loading: "lazy"
                    })
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "header-product__swiper-item" }, [
                    createVNode("img", {
                      src: _imports_2,
                      srcset: _imports_3 + " 2x",
                      alt: "",
                      loading: "lazy"
                    })
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "header-product__swiper-item" }, [
                    createVNode("img", {
                      src: _imports_4,
                      srcset: _imports_5 + " 2x",
                      alt: "",
                      loading: "lazy"
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="header-product__menu_mobile">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: openUteka,
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_troxactive_2"
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "#faq",
        id: "troxactive_faq_2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
              arrowRight: "",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
                arrowRight: "",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></header><section class="symptoms" id="symptoms"><div class="symptoms__wrapper container"><div class="symptoms__content"><div class="symptoms__head head"><h2 class="title-h1">\u041F\u043E\u043C\u043E\u0433\u0430\u0435\u0442 \u0431\u043E\u0440\u043E\u0442\u044C\u0441\u044F \u043F\u0440\u043E\u0442\u0438\u0432 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup>*</sup> \u0438 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u044F<sup>1</sup></h2></div><div class="symptoms__img"><img${ssrRenderAttr("src", _imports_6)}${ssrRenderAttr("srcset", _imports_7 + " 2x")} alt="" loading="lazy"></div><ul class="symptoms__list"><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_8)}${ssrRenderAttr("srcset", _imports_9 + " 2x")} alt="" loading="lazy"><p>\u0423\u0441\u0442\u0430\u043B\u043E\u0441\u0442\u044C <br> \u0438 \u0431\u043E\u043B\u044C <br> \u0432 \u043D\u043E\u0433\u0430\u0445</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_10)}${ssrRenderAttr("srcset", _imports_11 + " 2x")} alt="" loading="lazy"><p>\u041E\u0442\u0435\u043A\u0438 <br>\u0438 \u0441\u0443\u0434\u043E\u0440\u043E\u0433\u0438 \u0432 \u043D\u043E\u0433\u0430\u0445</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_12)}${ssrRenderAttr("srcset", _imports_13 + " 2x")} alt="" loading="lazy"><p>\u0412\u0435\u043D\u043E\u0437\u043D\u044B\u0435 \u0442\u0440\u043E\u0444\u0438\u0447\u0435\u0441\u043A\u0438\u0435 <br>\u044F\u0437\u0432\u044B</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_14)}${ssrRenderAttr("srcset", _imports_15 + " 2x")} alt="" loading="lazy"><p>\u041E\u0441\u0442\u0440\u044B\u0439 \u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0439 </p></li></ul><div class="symptoms__menu">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: openUteka,
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_troxactive_3"
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "#faq",
        id: "troxactive_faq_3"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
              arrowRight: "",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
                arrowRight: "",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></section><section class="chronic" id="chronic"><div class="chronic__wrapper container"><div class="chronic__content"><div class="chronic__head head"><h2 class="title-h1"><i>\u041A\u0443\u0440\u0441 \u043B\u0435\u0447\u0435\u043D\u0438\u044F</i> \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0439 \u0432\u0435\u043D \u043C\u043E\u0436\u0435\u0442 \u0434\u043B\u0438\u0442\u044C\u0441\u044F <i>\u043E\u0442 2 \u0434\u043E 12 \u043C\u0435\u0441\u044F\u0446\u0435\u0432</i><sup>9</sup></h2><p>\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u043C\u043E\u0436\u043D\u043E \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C \u0434\u043E 12 \u043C\u0435\u0441\u044F\u0446\u0435\u0432<sup>1</sup></p></div><ul class="chronic__list"><li class="chronic__item"><img${ssrRenderAttr("src", _imports_16)}${ssrRenderAttr("srcset", _imports_17 + " 2x")} alt="" loading="lazy"><p>\u041E\u0434\u043D\u0430 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0432 \u0434\u0435\u043D\u044C<sup>**</sup></p></li><li class="chronic__item"><img${ssrRenderAttr("src", _imports_18)}${ssrRenderAttr("srcset", _imports_19 + " 2x")} alt="" loading="lazy"><p>\u0414\u043E\u0441\u0442\u0443\u043F\u043D\u0430\u044F \u0446\u0435\u043D\u0430<sup>10</sup></p></li><li class="chronic__item"><img${ssrRenderAttr("src", _imports_20)}${ssrRenderAttr("srcset", _imports_21 + " 2x")} alt="" loading="lazy"><p>\u0415\u0432\u0440\u043E\u043F\u0435\u0439\u0441\u043A\u043E\u0435 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u043E<sup>1</sup></p></li></ul></div></div></section><section class="secret" id="secret"><div class="secret__wrapper container"><div class="secret__content secret-aorta"><div class="secret__head head"><h2 class="title-h1">\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u2013 \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0442\u0430\u0431\u043B\u0435\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u041C\u041E\u0424\u0424<sup>3</sup> \u0435\u0432\u0440\u043E\u043F\u0435\u0439\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0430<sup>1</sup></h2><p>\u041C\u041E\u0424\u0424 \u2013 \u044D\u0442\u043E \u043C\u0438\u043A\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u043E\u0447\u0438\u0449\u0435\u043D\u043D\u0430\u044F \u0444\u043B\u0430\u0432\u043E\u043D\u043E\u0438\u0434\u043D\u0430\u044F \u0444\u0440\u0430\u043A\u0446\u0438\u044F \u0413\u0435\u0441\u043F\u0435\u0440\u0438\u0434\u0438\u043D-\u0414\u0438\u043E\u0441\u043C\u0438\u043D. \u041F\u0440\u0438 \u043C\u0438\u043A\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u043F\u0440\u043E\u0438\u0441\u0445\u043E\u0434\u0438\u0442 \u0443\u043C\u0435\u043D\u044C\u0448\u0435\u043D\u0438\u0435 \u0447\u0430\u0441\u0442\u0438\u0446 \u0434\u043B\u044F \u0443\u043B\u0443\u0447\u0448\u0435\u043D\u0438\u044F \u0432\u0441\u0430\u0441\u044B\u0432\u0430\u0435\u043C\u043E\u0441\u0442\u0438<sup>4</sup></p></div></div></div></section><section class="economy" id="economy"><div class="economy__wrapper container"><div class="economy__head head"><h2 class="title-h1 text-al-center">\u042D\u043A\u043E\u043D\u043E\u043C\u044C\u0442\u0435 \u043F\u0440\u0438 \u043F\u043E\u043A\u0443\u043F\u043A\u0435 <br> \u0431\u043E\u043B\u044C\u0448\u0438\u0445 \u0443\u043F\u0430\u043A\u043E\u0432\u043E\u043A 25%<sup>5</sup></h2></div><div class="economy-two"><div class="economy-two__item"><img${ssrRenderAttr("src", _imports_22)} alt="" loading="lazy"><p><span class="color-orange">\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 90 \u0448\u0442.</span> <br>3 \u043C\u0435\u0441\u044F\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430<sup>**,1</sup></p>`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productId=376941"),
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_troxactive_4"
      }, null, _parent));
      _push(`</div><div class="economy-two__item"><img${ssrRenderAttr("src", _imports_23)} alt="" loading="lazy"><p><span class="color-orange">\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 60 \u0448\u0442.</span> <br>2 \u043C\u0435\u0441\u044F\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430<sup>**,1</sup></p>`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productId=376944"),
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_troxactive_5"
      }, null, _parent));
      _push(`</div></div><div class="economy__swiper">`);
      _push(ssrRenderComponent(unref(Swiper), {
        "slides-per-view": 1,
        "space-between": 20,
        onSwiper: onSwiperEconomy,
        modules: [unref(Navigation)],
        navigation: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="economy-two__item"${_scopeId2}><img${ssrRenderAttr("src", _imports_22)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}><span class="color-orange"${_scopeId2}>\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 90 \u0448\u0442.</span> <br${_scopeId2}>3 \u043C\u0435\u0441\u044F\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430</p>`);
                  _push3(ssrRenderComponent(_component_Button, {
                    onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productId=376941"),
                    label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                    arrowRight: "",
                    id: "buy_troxactive_4"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "economy-two__item" }, [
                      createVNode("img", {
                        src: _imports_22,
                        alt: "",
                        loading: "lazy"
                      }),
                      createVNode("p", null, [
                        createVNode("span", { class: "color-orange" }, "\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 90 \u0448\u0442."),
                        createTextVNode(),
                        createVNode("br"),
                        createTextVNode("3 \u043C\u0435\u0441\u044F\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430")
                      ]),
                      createVNode(_component_Button, {
                        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productId=376941"),
                        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                        arrowRight: "",
                        id: "buy_troxactive_4"
                      }, null, 8, ["onClick"])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="economy-two__item"${_scopeId2}><img${ssrRenderAttr("src", _imports_23)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}><span class="color-orange"${_scopeId2}>\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 60 \u0448\u0442.</span> <br${_scopeId2}>3 \u043C\u0435\u0441\u044F\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430</p>`);
                  _push3(ssrRenderComponent(_component_Button, {
                    onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productId=376944"),
                    label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                    arrowRight: "",
                    id: "buy_troxactive_5"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "economy-two__item" }, [
                      createVNode("img", {
                        src: _imports_23,
                        alt: "",
                        loading: "lazy"
                      }),
                      createVNode("p", null, [
                        createVNode("span", { class: "color-orange" }, "\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 60 \u0448\u0442."),
                        createTextVNode(),
                        createVNode("br"),
                        createTextVNode("3 \u043C\u0435\u0441\u044F\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430")
                      ]),
                      createVNode(_component_Button, {
                        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productId=376944"),
                        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                        arrowRight: "",
                        id: "buy_troxactive_5"
                      }, null, 8, ["onClick"])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "economy-two__item" }, [
                    createVNode("img", {
                      src: _imports_22,
                      alt: "",
                      loading: "lazy"
                    }),
                    createVNode("p", null, [
                      createVNode("span", { class: "color-orange" }, "\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 90 \u0448\u0442."),
                      createTextVNode(),
                      createVNode("br"),
                      createTextVNode("3 \u043C\u0435\u0441\u044F\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430")
                    ]),
                    createVNode(_component_Button, {
                      onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productId=376941"),
                      label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                      arrowRight: "",
                      id: "buy_troxactive_4"
                    }, null, 8, ["onClick"])
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "economy-two__item" }, [
                    createVNode("img", {
                      src: _imports_23,
                      alt: "",
                      loading: "lazy"
                    }),
                    createVNode("p", null, [
                      createVNode("span", { class: "color-orange" }, "\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 60 \u0448\u0442."),
                      createTextVNode(),
                      createVNode("br"),
                      createTextVNode("3 \u043C\u0435\u0441\u044F\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430")
                    ]),
                    createVNode(_component_Button, {
                      onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productId=376944"),
                      label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                      arrowRight: "",
                      id: "buy_troxactive_5"
                    }, null, 8, ["onClick"])
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></section><section class="tutorial" id="tutorial"><div class="tutorial__wrapper container"><div class="tutorial__content"><div class="tutorial__head"><h2 class="title-h1 text-al-center">\u041A\u0430\u043A \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C?<sup>1</sup></h2></div><div class="guide guide-nowrap"><div class="guide__block"><h4 class="guide__title">\u041F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435<sup>*</sup></h4><div class="guide__wrap"><div class="guide__item"><img${ssrRenderAttr("src", _imports_24)} alt="" loading="lazy"><p>\u041E\u0434\u043D\u0430 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0443\u0442\u0440\u043E\u043C \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0435\u0434\u044B</p></div></div></div><div class="guide__block"><h4 class="guide__title">\u041F\u0440\u0438 \u043E\u0441\u0442\u0440\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0435\u0434\u0435\u043B\u0438</h4><div class="guide__wrap"><div class="guide__item"><img${ssrRenderAttr("src", _imports_25)} alt="" loading="lazy"><p>\u043F\u043E 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u0443\u0442\u0440\u043E\u043C, \u0434\u043D\u0435\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C</p></div><div class="guide__item"><img${ssrRenderAttr("src", _imports_26)} alt="" loading="lazy"><p>\u043F\u043E 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u0443\u0442\u0440\u043E\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C</p></div></div></div><div class="guide__block"><h4 class="guide__title">\u041F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435</h4><div class="guide__wrap"><div class="guide__item"><img${ssrRenderAttr("src", _imports_27)} alt="" loading="lazy"><p>1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0432 \u0434\u0435\u043D\u044C \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0435\u0434\u044B</p></div></div></div></div><div class="guide__swiper">`);
      _push(ssrRenderComponent(unref(Swiper), {
        "slides-per-view": 1,
        "space-between": 20,
        onSwiper: onSwiperGuide,
        modules: [unref(Navigation)],
        navigation: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="guide__block"${_scopeId2}><h4 class="guide__title"${_scopeId2}>\u041F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435<sup${_scopeId2}>*</sup></h4><div class="guide__wrap"${_scopeId2}><div class="guide__item"${_scopeId2}><img${ssrRenderAttr("src", _imports_24)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}>\u041E\u0434\u043D\u0430 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0443\u0442\u0440\u043E\u043C \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0435\u0434\u044B</p></div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "guide__block" }, [
                      createVNode("h4", { class: "guide__title" }, [
                        createTextVNode("\u041F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435"),
                        createVNode("sup", null, "*")
                      ]),
                      createVNode("div", { class: "guide__wrap" }, [
                        createVNode("div", { class: "guide__item" }, [
                          createVNode("img", {
                            src: _imports_24,
                            alt: "",
                            loading: "lazy"
                          }),
                          createVNode("p", null, "\u041E\u0434\u043D\u0430 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0443\u0442\u0440\u043E\u043C \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0435\u0434\u044B")
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="guide__block"${_scopeId2}><h4 class="guide__title"${_scopeId2}>\u041F\u0440\u0438 \u043E\u0441\u0442\u0440\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0435\u0434\u0435\u043B\u0438</h4><div class="guide__wrap"${_scopeId2}><div class="guide__item"${_scopeId2}><img${ssrRenderAttr("src", _imports_25)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}>\u043F\u043E 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u0443\u0442\u0440\u043E\u043C, \u0434\u043D\u0435\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C</p></div><div class="guide__item"${_scopeId2}><img${ssrRenderAttr("src", _imports_26)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}>\u043F\u043E 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u0443\u0442\u0440\u043E\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C</p></div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "guide__block" }, [
                      createVNode("h4", { class: "guide__title" }, "\u041F\u0440\u0438 \u043E\u0441\u0442\u0440\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0435\u0434\u0435\u043B\u0438"),
                      createVNode("div", { class: "guide__wrap" }, [
                        createVNode("div", { class: "guide__item" }, [
                          createVNode("img", {
                            src: _imports_25,
                            alt: "",
                            loading: "lazy"
                          }),
                          createVNode("p", null, "\u043F\u043E 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u0443\u0442\u0440\u043E\u043C, \u0434\u043D\u0435\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C")
                        ]),
                        createVNode("div", { class: "guide__item" }, [
                          createVNode("img", {
                            src: _imports_26,
                            alt: "",
                            loading: "lazy"
                          }),
                          createVNode("p", null, "\u043F\u043E 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u0443\u0442\u0440\u043E\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C")
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="guide__block"${_scopeId2}><h4 class="guide__title"${_scopeId2}>\u041F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435</h4><div class="guide__wrap"${_scopeId2}><div class="guide__item"${_scopeId2}><img${ssrRenderAttr("src", _imports_27)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}>1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0432 \u0434\u0435\u043D\u044C \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0435\u0434\u044B</p></div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "guide__block" }, [
                      createVNode("h4", { class: "guide__title" }, "\u041F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435"),
                      createVNode("div", { class: "guide__wrap" }, [
                        createVNode("div", { class: "guide__item" }, [
                          createVNode("img", {
                            src: _imports_27,
                            alt: "",
                            loading: "lazy"
                          }),
                          createVNode("p", null, "1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0432 \u0434\u0435\u043D\u044C \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0435\u0434\u044B")
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "guide__block" }, [
                    createVNode("h4", { class: "guide__title" }, [
                      createTextVNode("\u041F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435"),
                      createVNode("sup", null, "*")
                    ]),
                    createVNode("div", { class: "guide__wrap" }, [
                      createVNode("div", { class: "guide__item" }, [
                        createVNode("img", {
                          src: _imports_24,
                          alt: "",
                          loading: "lazy"
                        }),
                        createVNode("p", null, "\u041E\u0434\u043D\u0430 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0443\u0442\u0440\u043E\u043C \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0435\u0434\u044B")
                      ])
                    ])
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "guide__block" }, [
                    createVNode("h4", { class: "guide__title" }, "\u041F\u0440\u0438 \u043E\u0441\u0442\u0440\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0435\u0434\u0435\u043B\u0438"),
                    createVNode("div", { class: "guide__wrap" }, [
                      createVNode("div", { class: "guide__item" }, [
                        createVNode("img", {
                          src: _imports_25,
                          alt: "",
                          loading: "lazy"
                        }),
                        createVNode("p", null, "\u043F\u043E 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u0443\u0442\u0440\u043E\u043C, \u0434\u043D\u0435\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C")
                      ]),
                      createVNode("div", { class: "guide__item" }, [
                        createVNode("img", {
                          src: _imports_26,
                          alt: "",
                          loading: "lazy"
                        }),
                        createVNode("p", null, "\u043F\u043E 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u0443\u0442\u0440\u043E\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C")
                      ])
                    ])
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "guide__block" }, [
                    createVNode("h4", { class: "guide__title" }, "\u041F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435"),
                    createVNode("div", { class: "guide__wrap" }, [
                      createVNode("div", { class: "guide__item" }, [
                        createVNode("img", {
                          src: _imports_27,
                          alt: "",
                          loading: "lazy"
                        }),
                        createVNode("p", null, "1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0432 \u0434\u0435\u043D\u044C \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0435\u0434\u044B")
                      ])
                    ])
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></section><section class="others" id="products"><div class="others__wrapper container"><div class="others__content"><h2 class="title-h1" style="${ssrRenderStyle({ "max-width": "928px" })}">\u041B\u0438\u043D\u0435\u0439\u043A\u0430 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u2013 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0441\u043D\u044B\u0439 \u043F\u043E\u0434\u0445\u043E\u0434 \u0434\u043B\u044F \u0432\u043E\u0437\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043D\u0430 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u044B \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup>*</sup> \u043D\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0438\u0437\u043D\u0443\u0442\u0440\u0438, \u043D\u043E \u0438 \u0441\u043D\u0430\u0440\u0443\u0436\u0438</h2><div class="others__list"><div class="others__item swiper-gel-1"><img${ssrRenderAttr("src", _imports_28)} alt="" loading="lazy"><p><strong class="others-violet">\u0423\u0437\u043D\u0430\u0439\u0442\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 <br> \u043E \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u041D\u0435\u043E \u2014</strong><br> \u0433\u0435\u043B\u044C \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439<sup>***</sup> \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439<sup>6</sup></p>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/neo",
        id: "neo"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="others__item swiper-gel-1"><img${ssrRenderAttr("src", _imports_29)} alt="" loading="lazy"><p><strong class="others-violet">\u0423\u0437\u043D\u0430\u0439\u0442\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 <br> \u043E \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u0413\u0435\u043B\u044C 2 % \u2014</strong><br>\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430\u044F \u0446\u0435\u043D\u0430<sup>7</sup>, \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0433\u0435\u043B\u044C<sup>8</sup></p>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/gel",
        id: "gel"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="others__swiper">`);
      _push(ssrRenderComponent(unref(Swiper), {
        "slides-per-view": 1,
        "space-between": 20,
        onSwiper,
        modules: [unref(Navigation)],
        navigation: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="others__item"${_scopeId2}><img${ssrRenderAttr("src", _imports_28)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}><strong class="others-violet"${_scopeId2}>\u0423\u0437\u043D\u0430\u0439\u0442\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 <br${_scopeId2}> \u043E \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> \u041D\u0435\u043E \u2014</strong><br${_scopeId2}> \u0433\u0435\u043B\u044C \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439<sup${_scopeId2}>***</sup> \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439<sup${_scopeId2}>6</sup></p>`);
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/neo",
                    id: "neo"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "others__item" }, [
                      createVNode("img", {
                        src: _imports_28,
                        alt: "",
                        loading: "lazy"
                      }),
                      createVNode("p", null, [
                        createVNode("strong", { class: "others-violet" }, [
                          createTextVNode("\u0423\u0437\u043D\u0430\u0439\u0442\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 "),
                          createVNode("br"),
                          createTextVNode(" \u043E \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                          createVNode("sup", null, "\xAE"),
                          createTextVNode(" \u041D\u0435\u043E \u2014")
                        ]),
                        createVNode("br"),
                        createTextVNode(" \u0433\u0435\u043B\u044C \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439"),
                        createVNode("sup", null, "***"),
                        createTextVNode(" \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439"),
                        createVNode("sup", null, "6")
                      ]),
                      createVNode(_component_NuxtLink, {
                        to: "/neo",
                        id: "neo"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="others__item"${_scopeId2}><img${ssrRenderAttr("src", _imports_29)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}><strong class="others-violet"${_scopeId2}>\u0423\u0437\u043D\u0430\u0439\u0442\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 <br${_scopeId2}> \u043E \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> \u0413\u0435\u043B\u044C 2 % \u2014</strong><br${_scopeId2}>\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430\u044F \u0446\u0435\u043D\u0430<sup${_scopeId2}>7</sup>, \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0433\u0435\u043B\u044C<sup${_scopeId2}>8</sup></p>`);
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/gel",
                    id: "gel"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "others__item" }, [
                      createVNode("img", {
                        src: _imports_29,
                        alt: "",
                        loading: "lazy"
                      }),
                      createVNode("p", null, [
                        createVNode("strong", { class: "others-violet" }, [
                          createTextVNode("\u0423\u0437\u043D\u0430\u0439\u0442\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 "),
                          createVNode("br"),
                          createTextVNode(" \u043E \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                          createVNode("sup", null, "\xAE"),
                          createTextVNode(" \u0413\u0435\u043B\u044C 2 % \u2014")
                        ]),
                        createVNode("br"),
                        createTextVNode("\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430\u044F \u0446\u0435\u043D\u0430"),
                        createVNode("sup", null, "7"),
                        createTextVNode(", \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0433\u0435\u043B\u044C"),
                        createVNode("sup", null, "8")
                      ]),
                      createVNode(_component_NuxtLink, {
                        to: "/gel",
                        id: "gel"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "others__item" }, [
                    createVNode("img", {
                      src: _imports_28,
                      alt: "",
                      loading: "lazy"
                    }),
                    createVNode("p", null, [
                      createVNode("strong", { class: "others-violet" }, [
                        createTextVNode("\u0423\u0437\u043D\u0430\u0439\u0442\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 "),
                        createVNode("br"),
                        createTextVNode(" \u043E \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(" \u041D\u0435\u043E \u2014")
                      ]),
                      createVNode("br"),
                      createTextVNode(" \u0433\u0435\u043B\u044C \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439"),
                      createVNode("sup", null, "***"),
                      createTextVNode(" \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439"),
                      createVNode("sup", null, "6")
                    ]),
                    createVNode(_component_NuxtLink, {
                      to: "/neo",
                      id: "neo"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "others__item" }, [
                    createVNode("img", {
                      src: _imports_29,
                      alt: "",
                      loading: "lazy"
                    }),
                    createVNode("p", null, [
                      createVNode("strong", { class: "others-violet" }, [
                        createTextVNode("\u0423\u0437\u043D\u0430\u0439\u0442\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 "),
                        createVNode("br"),
                        createTextVNode(" \u043E \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(" \u0413\u0435\u043B\u044C 2 % \u2014")
                      ]),
                      createVNode("br"),
                      createTextVNode("\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430\u044F \u0446\u0435\u043D\u0430"),
                      createVNode("sup", null, "7"),
                      createTextVNode(", \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0433\u0435\u043B\u044C"),
                      createVNode("sup", null, "8")
                    ]),
                    createVNode(_component_NuxtLink, {
                      to: "/gel",
                      id: "gel"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></section><section class="faq" id="faq"><div class="faq__wrapper container"><div class="faq__content"><h2 class="title-h1">\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438</h2><div class="instruction"><div class="instruction__list"><div class="instruction__item"><div class="instruction__title"><h5>\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u041B\u041F-000726</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0422\u043E\u0440\u0433\u043E\u0432\u043E\u0435 \u043D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u043F\u043E\u043A\u0440\u044B\u0442\u044B\u0435 \u043F\u043B\u0435\u043D\u043E\u0447\u043D\u043E\u0439 \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u043E\u0439</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0421\u043E\u0441\u0442\u0430\u0432</h5><div class="accordion-btn"></div></div><div class="instruction__desc">1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430, \u043F\u043E\u043A\u0440\u044B\u0442\u0430\u044F \u043F\u043B\u0435\u043D\u043E\u0447\u043D\u043E\u0439 \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u043E\u0439, \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442: \u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u0432\u0435\u0449\u0435\u0441\u0442\u0432\u043E: \u0413\u0435\u0441\u043F\u0435\u0440\u0438\u0434\u0438\u043D + \u0414\u0438\u043E\u0441\u043C\u0438\u043D (\u041E\u0447\u0438\u0449\u0435\u043D\u043D\u0430\u044F \u043C\u0438\u043A\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0444\u043B\u0430\u0432\u043E\u043D\u043E\u0438\u0434\u043D\u0430\u044F \u0444\u0440\u0430\u043A\u0446\u0438\u044F [90 % \u0434\u0438\u043E\u0441\u043C\u0438\u043D (900 \u043C\u0433), 10 % \u0444\u043B\u0430\u0432\u043E\u043D\u043E\u0438\u0434\u044B \u0432 \u043F\u0435\u0440\u0435\u0441\u0447\u0435\u0442\u0435 \u043D\u0430 \u0433\u0435\u0441\u043F\u0435\u0440\u0438\u0434\u0438\u043D (100 \u043C\u0433)]) 1000,0 \u043C\u0433. \u0412\u0441\u043F\u043E\u043C\u043E\u0433\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0432\u0435\u0449\u0435\u0441\u0442\u0432\u0430: \u0446\u0435\u043B\u043B\u044E\u043B\u043E\u0437\u0430 \u043C\u0438\u043A\u0440\u043E\u043A\u0440\u0438\u0441\u0442\u0430\u043B\u043B\u0438\u0447\u0435\u0441\u043A\u0430\u044F (Vivapur 101) 157,0 \u043C\u0433, \u043F\u043E\u0432\u0438\u0434\u043E\u043D (\u041F\u043B\u0430\u0441\u0434\u043E\u043D \u041A-25) 62,0 \u043C\u0433, \u043A\u0430\u0440\u0431\u043E\u043A\u0441\u0438\u043C\u0435\u0442\u0438\u043B\u043A\u0440\u0430\u0445\u043C\u0430\u043B \u043D\u0430\u0442\u0440\u0438\u044F \u0442\u0438\u043F \u0410 (Explotab) 26,8 \u043C\u0433, \u043A\u0440\u0435\u043C\u043D\u0438\u044F \u0434\u0438\u043E\u043A\u0441\u0438\u0434 \u043A\u043E\u043B\u043B\u043E\u0438\u0434\u043D\u044B\u0439 (\u043A\u0440\u0435\u043C\u043D\u0438\u044F \u0434\u0438\u043E\u043A\u0441\u0438\u0434 \u043A\u043E\u043B\u043B\u043E\u0438\u0434\u043D\u044B\u0439 \u0431\u0435\u0437\u0432\u043E\u0434\u043D\u044B\u0439) (Aerosil 200 Pharma) 6,2 \u043C\u0433, \u043C\u0430\u0433\u043D\u0438\u044F \u0441\u0442\u0435\u0430\u0440\u0430\u0442 (Ligamed MF-2-V) 8,0 \u043C\u0433. \u041F\u043B\u0435\u043D\u043E\u0447\u043D\u0430\u044F \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u0430 \u041E\u043F\u0430\u0434\u0440\u0430\u0439 II 85F240141 \u0440\u043E\u0437\u043E\u0432\u044B\u0439: \u043F\u043E\u043B\u0438\u0432\u0438\u043D\u0438\u043B\u043E\u0432\u044B\u0439 \u0441\u043F\u0438\u0440\u0442 \u2014\u0447\u0430\u0441\u0442\u0438\u0447\u043D\u043E \u0433\u0438\u0434\u0440\u043E\u043B\u0438\u0437\u043E\u0432\u0430\u043D\u043D\u044B\u0439 (\u04151203) 15,12 \u043C\u0433, \u043C\u0430\u043A\u0440\u043E\u0433\u043E\u043B-3350 (\u041C\u0430\u043A\u0440\u043E\u0433\u043E\u043B/\u041F\u042D\u0413 3350 (\u04151521)) 7,64 \u043C\u0433, 2 \u0442\u0438\u0442\u0430\u043D\u0430 \u0434\u0438\u043E\u043A\u0441\u0438\u0434 (\u0415171) 8,61 \u043C\u0433, \u0442\u0430\u043B\u044C\u043A (\u0415553B) 5,59 \u043C\u0433, \u043A\u0440\u0430\u0441\u0438\u0442\u0435\u043B\u044C \u0436\u0435\u043B\u0435\u0437\u0430 \u043E\u043A\u0441\u0438\u0434 \u0436\u0435\u043B\u0442\u044B\u0439 (\u0415172) 0,48 \u043C\u0433, \u043A\u0440\u0430\u0441\u0438\u0442\u0435\u043B\u044C \u0436\u0435\u043B\u0435\u0437\u0430 \u043E\u043A\u0441\u0438\u0434 \u043A\u0440\u0430\u0441\u043D\u044B\u0439 (\u0415172) 0,36 \u043C\u0433</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u0414\u043E\u0437\u0438\u0440\u043E\u0432\u043A\u0430 1000 \u043C\u0433 <br><br>\u041F\u0440\u043E\u0434\u043E\u043B\u0433\u043E\u0432\u0430\u0442\u044B\u0435 \u0434\u0432\u043E\u044F\u043A\u043E\u0432\u044B\u043F\u0443\u043A\u043B\u044B\u0435 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438, \u043F\u043E\u043A\u0440\u044B\u0442\u044B\u0435 \u043F\u043B\u0435\u043D\u043E\u0447\u043D\u043E\u0439 \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u043E\u0439 \u0441\u0432\u0435\u0442\u043B\u043E\u0440\u043E\u0437\u043E\u0432\u043E\u0433\u043E \u0446\u0432\u0435\u0442\u0430, \u0441 \u0440\u0438\u0441\u043A\u043E\u0439 \u0441 \u043E\u0431\u0435\u0438\u0445 \u0441\u0442\u043E\u0440\u043E\u043D.<br><br>\u041D\u0430 \u043F\u043E\u043F\u0435\u0440\u0435\u0447\u043D\u043E\u043C \u0440\u0430\u0437\u0440\u0435\u0437\u0435 \u044F\u0434\u0440\u043E \u043E\u0442 \u0441\u0432\u0435\u0442\u043B\u043E-\u0436\u0435\u043B\u0442\u043E\u0433\u043E \u0434\u043E \u0436\u0435\u043B\u0442\u043E\u0433\u043E \u0446\u0432\u0435\u0442\u0430 \u043D\u0435\u043E\u0434\u043D\u043E\u0440\u043E\u0434\u043D\u043E\u0439 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u044B. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0424\u0430\u0440\u043C\u0430\u043A\u043E\u0442\u0435\u0440\u0430\u043F\u0435\u0432\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0433\u0440\u0443\u043F\u043F\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc">\u0412\u0435\u043D\u043E\u0442\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u044E\u0449\u0435\u0435 \u0438 \u0432\u0435\u043D\u043E\u043F\u0440\u043E\u0442\u0435\u043A\u0442\u043E\u0440\u043D\u043E\u0435 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043E</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0424\u0430\u0440\u043C\u0430\u043A\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435</h5><div class="accordion-btn"></div></div><div class="instruction__desc"><strong>\u0424\u0430\u0440\u043C\u0430\u043A\u043E\u0434\u0438\u043D\u0430\u043C\u0438\u043A\u0430</strong><br><br>\u041F\u0440\u0435\u043F\u0430\u0440\u0430\u0442 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 \u0441\u043E\u0431\u043E\u0439 \u043E\u0447\u0438\u0449\u0435\u043D\u043D\u0443\u044E \u043C\u0438\u043A\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0443\u044E \u0444\u043B\u0430\u0432\u043E\u043D\u043E\u0438\u0434\u043D\u0443\u044E \u0444\u0440\u0430\u043A\u0446\u0438\u044E, \u0441\u043E\u0441\u0442\u043E\u044F\u0449\u0443\u044E \u0438\u0437 \u0434\u0438\u043E\u0441\u043C\u0438\u043D\u0430 \u0438 \u0434\u0440\u0443\u0433\u0438\u0445 \u0444\u043B\u0430\u0432\u043E\u043D\u043E\u0438\u0434\u043E\u0432 \u0432 \u043F\u0435\u0440\u0435\u0441\u0447\u0435\u0442\u0435 \u043D\u0430 \u0433\u0435\u0441\u043F\u0435\u0440\u0438\u0434\u0438\u043D. \u0414\u0430\u043D\u043D\u0430\u044F \u043A\u043E\u043C\u0431\u0438\u043D\u0430\u0446\u0438\u044F \u043E\u0431\u043B\u0430\u0434\u0430\u0435\u0442 \u0432\u0435\u043D\u043E\u0442\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u044E\u0449\u0438\u043C \u0438 \u0430\u043D\u0433\u0438\u043E\u043F\u0440\u043E\u0442\u0435\u043A\u0442\u0438\u0432\u043D\u044B\u043C \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u0430\u043C\u0438.</div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u043E\u043A\u0430\u0437\u0430\u043D\u0438\u044F \u043A \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u043F\u043E\u043A\u0430\u0437\u0430\u043D \u0434\u043B\u044F \u0442\u0435\u0440\u0430\u043F\u0438\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0439 \u0432\u0435\u043D (\u0443\u0441\u0442\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0438 \u043E\u0431\u043B\u0435\u0433\u0447\u0435\u043D\u0438\u044F \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432). </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0432 \u043F\u0435\u0440\u0438\u043E\u0434 \u0431\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u0438 \u0433\u0440\u0443\u0434\u043D\u043E\u0433\u043E \u0432\u0441\u043A\u0430\u0440\u043C\u043B\u0438\u0432\u0430\u043D\u0438\u044F</h5><div class="accordion-btn"></div></div><div class="instruction__desc"><strong>\u0411\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u044C</strong><br><br>\u0414\u0430\u043D\u043D\u044B\u0435 \u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0438 \u043E\u0447\u0438\u0449\u0435\u043D\u043D\u043E\u0439 \u043C\u0438\u043A\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0444\u043B\u0430\u0432\u043E\u043D\u043E\u0438\u0434\u043D\u043E\u0439 \u0444\u0440\u0430\u043A\u0446\u0438\u0438 \u0443 \u0431\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0445 \u0436\u0435\u043D\u0449\u0438\u043D \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u044E\u0442 \u0438\u043B\u0438 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u044B.<br><br>\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F \u043D\u0430 \u0436\u0438\u0432\u043E\u0442\u043D\u044B\u0445 \u043D\u0435 \u0432\u044B\u044F\u0432\u0438\u043B\u0438 \u0440\u0435\u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0438\u0432\u043D\u043E\u0439 \u0442\u043E\u043A\u0441\u0438\u0447\u043D\u043E\u0441\u0442\u0438.<br><br>\u0412 \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u0435 \u043F\u0440\u0435\u0434\u0443\u043F\u0440\u0435\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u043C\u0435\u0440\u044B \u043F\u0440\u0435\u0434\u043F\u043E\u0447\u0442\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0442\u044C \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0431\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u0438.<br><br><strong>\u0413\u0440\u0443\u0434\u043D\u043E\u0435 \u0432\u0441\u043A\u0430\u0440\u043C\u043B\u0438\u0432\u0430\u043D\u0438\u0435</strong><br><br>\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E, \u043F\u0440\u043E\u043D\u0438\u043A\u0430\u0435\u0442 \u043B\u0438 \u043E\u0447\u0438\u0449\u0435\u043D\u043D\u0430\u044F \u043C\u0438\u043A\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0444\u043B\u0430\u0432\u043E\u043D\u043E\u0438\u0434\u043D\u0430\u044F \u0444\u0440\u0430\u043A\u0446\u0438\u044F (\u043C\u0435\u0442\u0430\u0431\u043E\u043B\u0438\u0442\u044B) \u0432 \u0433\u0440\u0443\u0434\u043D\u043E\u0435 \u043C\u043E\u043B\u043E\u043A\u043E \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430.<br><br>\u041D\u0435 \u0438\u0441\u043A\u043B\u044E\u0447\u0435\u043D \u0440\u0438\u0441\u043A \u0434\u043B\u044F \u043D\u043E\u0432\u043E\u0440\u043E\u0436\u0434\u0435\u043D\u043D\u044B\u0445 \u0438 \u0434\u0435\u0442\u0435\u0439 \u0433\u0440\u0443\u0434\u043D\u043E\u0433\u043E \u0432\u043E\u0437\u0440\u0430\u0441\u0442\u0430. \u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043F\u0440\u0438\u043D\u044F\u0442\u044C \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043B\u0438\u0431\u043E \u043E \u043F\u0440\u0435\u043A\u0440\u0430\u0449\u0435\u043D\u0438\u0438 \u0433\u0440\u0443\u0434\u043D\u043E\u0433\u043E \u0432\u0441\u043A\u0430\u0440\u043C\u043B\u0438\u0432\u0430\u043D\u0438\u044F, \u043B\u0438\u0431\u043E \u043E\u0431 \u043E\u0442\u043C\u0435\u043D\u0435 \u0442\u0435\u0440\u0430\u043F\u0438\u0438 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u043E\u043C \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432, \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u044F \u0432\u043E \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u0435 \u043F\u043E\u043B\u044C\u0437\u0443 \u0433\u0440\u0443\u0434\u043D\u043E\u0433\u043E \u0432\u0441\u043A\u0430\u0440\u043C\u043B\u0438\u0432\u0430\u043D\u0438\u044F \u0434\u043B\u044F \u0440\u0435\u0431\u0435\u043D\u043A\u0430 \u0438 \u043F\u043E\u043B\u044C\u0437\u0443 \u0442\u0435\u0440\u0430\u043F\u0438\u0438 \u0434\u043B\u044F \u0436\u0435\u043D\u0449\u0438\u043D\u044B.<br><br>\u041F\u043E\u043B\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0430 \u0432 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438 \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E (\u0441\u043C. \u0418\u041C\u041F) </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F, \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u044E\u0449\u0430\u044F \u043F\u0440\u0435\u0442\u0435\u043D\u0437\u0438\u0438 \u043F\u043E\u0442\u0440\u0435\u0431\u0438\u0442\u0435\u043B\u0435\u0439</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u041E\u041E\u041E \xAB\u0422\u0435\u0432\u0430\xBB, 115054, \u041C\u043E\u0441\u043A\u0432\u0430, \u0443\u043B. \u0412\u0430\u043B\u043E\u0432\u0430\u044F, 35, <br>\u0442\u0435\u043B.: +7 (495) 644 22 34, \u0444\u0430\u043A\u0441: +7 (495) 644 22 35 <br>\u0410\u0434\u0440\u0435\u0441 \u0432 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442\u0435: www.teva.ru<br>\u041F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u0438\u0442\u0435\u043B\u044C \u0444\u0438\u0440\u043C\u044B \u0427\u0435\u0440\u043D\u044B\u0448\u0435\u0432\u0430 \u0422.\u0412. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0421\u043F\u043E\u0441\u043E\u0431 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0438 \u0434\u043E\u0437\u044B</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0414\u043E\u0437\u0438\u0440\u043E\u0432\u043A\u0430 1000 \u043C\u0433<br><br>\u0412\u043D\u0443\u0442\u0440\u044C.<br><br>\u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u043C\u0430\u044F \u0434\u043E\u0437\u0430 \u043F\u0440\u0438 \u0432\u0435\u043D\u043E\u0437\u043D\u043E-\u043B\u0438\u043C\u0444\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438 \u2014 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0432 \u0441\u0443\u0442\u043A\u0438 \u043F\u0440\u0435\u0434\u043F\u043E\u0447\u0442\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u0443\u0442\u0440\u043E\u043C, \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u043F\u0440\u0438\u0435\u043C\u0430 \u043F\u0438\u0449\u0438. \u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0441\u043B\u0435\u0434\u0443\u0435\u0442 \u043F\u0440\u043E\u0433\u043B\u0430\u0442\u044B\u0432\u0430\u0442\u044C \u0446\u0435\u043B\u0438\u043A\u043E\u043C, \u0437\u0430\u043F\u0438\u0432\u0430\u044F \u0432\u043E\u0434\u043E\u0439. \u0420\u0438\u0441\u043A\u0430 \u043D\u0430 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u043F\u0440\u0435\u0434\u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0430 \u0438\u0441\u043A\u043B\u044E\u0447\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u0434\u043B\u044F \u0434\u0435\u043B\u0435\u043D\u0438\u044F \u0441 \u0446\u0435\u043B\u044C\u044E \u043E\u0431\u043B\u0435\u0433\u0447\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0433\u043B\u0430\u0442\u044B\u0432\u0430\u043D\u0438\u044F.<br><br>\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u043A\u0443\u0440\u0441\u0430 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u043C\u043E\u0436\u0435\u0442 \u0441\u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043C\u0435\u0441\u044F\u0446\u0435\u0432 (\u0432\u043F\u043B\u043E\u0442\u044C \u0434\u043E 12 \u043C\u0435\u0441\u044F\u0446\u0435\u0432). \u0412 \u0441\u043B\u0443\u0447\u0430\u0435 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0433\u043E \u0432\u043E\u0437\u043D\u0438\u043A\u043D\u043E\u0432\u0435\u043D\u0438\u044F \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432, \u043F\u043E \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u0438 \u0432\u0440\u0430\u0447\u0430, \u043A\u0443\u0440\u0441 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u043F\u043E\u0432\u0442\u043E\u0440\u0435\u043D.<br><br>\u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u043C\u0430\u044F \u0434\u043E\u0437\u0430 \u043F\u0440\u0438 \u043E\u0441\u0442\u0440\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435 \u2014 3 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0432 \u0441\u0443\u0442\u043A\u0438: \u043F\u043E 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u0443\u0442\u0440\u043E\u043C, \u0434\u043D\u0435\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 4 \u0434\u043D\u0435\u0439, \u0437\u0430\u0442\u0435\u043C \u043F\u043E 2 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0432 \u0441\u0443\u0442\u043A\u0438: \u043F\u043E 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0435 \u0443\u0442\u0440\u043E\u043C \u0438 \u0432\u0435\u0447\u0435\u0440\u043E\u043C \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u043F\u043E\u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0445 3 \u0434\u043D\u0435\u0439. \u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u043C\u0430\u044F \u0434\u043E\u0437\u0430 \u043F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435 \u2014 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0430 \u0432 \u0441\u0443\u0442\u043A\u0438 \u0441 \u043F\u0440\u0438\u0435\u043C\u043E\u043C \u043F\u0438\u0449\u0438. </div></div></div><div class="instruction__list"><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u043E\u0431\u043E\u0447\u043D\u043E\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u041F\u043E\u0431\u043E\u0447\u043D\u044B\u0435 \u044D\u0444\u0444\u0435\u043A\u0442\u044B, \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u0435\u043C\u044B\u0435 \u0432 \u0445\u043E\u0434\u0435 \u043A\u043B\u0438\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0439, \u0431\u044B\u043B\u0438 \u043B\u0451\u0433\u043A\u043E\u0439 \u0441\u0442\u0435\u043F\u0435\u043D\u0438 \u0432\u044B\u0440\u0430\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u0438.<br><br>\u0427\u0430\u0441\u0442\u043E\u0442\u0430 \u043F\u043E\u0431\u043E\u0447\u043D\u044B\u0445 \u044D\u0444\u0444\u0435\u043A\u0442\u043E\u0432 \u043A\u043B\u0430\u0441\u0441\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0432 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0438 \u0441 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u044F\u043C\u0438 \u0412\u0441\u0435\u043C\u0438\u0440\u043D\u043E\u0439 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u0437\u0434\u0440\u0430\u0432\u043E\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F: \u043E\u0447\u0435\u043D\u044C \u0447\u0430\u0441\u0442\u043E (\u02C31/10); \u0447\u0430\u0441\u0442\u043E (\u02C31/100, &lt;1/10); \u043D\u0435\u0447\u0430\u0441\u0442\u043E (\u02C31/1000, &lt;1/100); \u0440\u0435\u0434\u043A\u043E (\u02C31/10000, &lt;1/1000); \u043E\u0447\u0435\u043D\u044C \u0440\u0435\u0434\u043A\u043E (\u0432\u043A\u043B\u044E\u0447\u0430\u044F \u0435\u0434\u0438\u043D\u0438\u0447\u043D\u044B\u0435 \u0441\u043B\u0443\u0447\u0430\u0438) (&lt;1/10000), \u043D\u0435\u0443\u0442\u043E\u0447\u043D\u0435\u043D\u043D\u043E\u0439 \u0447\u0430\u0441\u0442\u043E\u0442\u044B (\u0447\u0430\u0441\u0442\u043E\u0442\u0430 \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u043F\u043E\u0434\u0441\u0447\u0438\u0442\u0430\u043D\u0430 \u043F\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u043C \u0434\u0430\u043D\u043D\u044B\u043C).<br><br>\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u0438\u044F \u0441\u043E \u0441\u0442\u043E\u0440\u043E\u043D\u044B \u0436\u0435\u043B\u0443\u0434\u043E\u0447\u043D\u043E-\u043A\u0438\u0448\u0435\u0447\u043D\u043E\u0433\u043E \u0442\u0440\u0430\u043A\u0442\u0430: \u0447\u0430\u0441\u0442\u043E \u2014 \u0442\u043E\u0448\u043D\u043E\u0442\u0430, \u0440\u0432\u043E\u0442\u0430, \u0434\u0438\u0430\u0440\u0435\u044F, \u0434\u0438\u0441\u043F\u0435\u043F\u0441\u0438\u044F; \u043D\u0435\u0447\u0430\u0441\u0442\u043E \u2014 \u043A\u043E\u043B\u0438\u0442; \u043D\u0435\u0443\u0442\u043E\u0447\u043D\u0435\u043D\u043D\u043E\u0439 \u0447\u0430\u0441\u0442\u043E\u0442\u044B \u2014 \u0431\u043E\u043B\u0438 \u0432 \u0436\u0438\u0432\u043E\u0442\u0435. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u0435\u0440\u0435\u0434\u043E\u0437\u0438\u0440\u043E\u0432\u043A\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0421\u043B\u0443\u0447\u0430\u0435\u0432 \u043F\u0435\u0440\u0435\u0434\u043E\u0437\u0438\u0440\u043E\u0432\u043A\u0438 \u043D\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u043E.<br><br>\u041F\u0440\u0438 \u043F\u0435\u0440\u0435\u0434\u043E\u0437\u0438\u0440\u043E\u0432\u043A\u0435 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u043D\u0435\u043C\u0435\u0434\u043B\u0435\u043D\u043D\u043E \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u0435\u0441\u044C \u0437\u0430 \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u0439 \u043F\u043E\u043C\u043E\u0449\u044C\u044E. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041E\u0441\u043E\u0431\u044B\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0438\u044F</h5><div class="accordion-btn"></div></div><div class="instruction__desc"><ul><li>\u041F\u0435\u0440\u0435\u0434 \u0442\u0435\u043C \u043A\u0430\u043A \u043D\u0430\u0447\u0430\u0442\u044C \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0442\u044C \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432, \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u0442\u0441\u044F \u043F\u0440\u043E\u043A\u043E\u043D\u0441\u0443\u043B\u044C\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u0441 \u0432\u0440\u0430\u0447\u043E\u043C.</li><li>\u041F\u0440\u0438 \u043E\u0431\u043E\u0441\u0442\u0440\u0435\u043D\u0438\u0438 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u044F \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u043D\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u0435\u0442 \u0441\u043F\u0435\u0446\u0438\u0444\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0434\u0440\u0443\u0433\u0438\u0445 \u0430\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043D\u0430\u0440\u0443\u0448\u0435\u043D\u0438\u0439. \u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u0434\u043E\u043B\u0436\u043D\u0430 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0442\u044C \u0441\u0440\u043E\u043A\u0438, \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u044B\u0435 \u0432 \u0440\u0430\u0437\u0434\u0435\u043B\u0435 \xAB\u0421\u043F\u043E\u0441\u043E\u0431 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0438 \u0434\u043E\u0437\u044B\xBB. \u0412 \u0442\u043E\u043C \u0441\u043B\u0443\u0447\u0430\u0435, \u0435\u0441\u043B\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u044B \u043D\u0435 \u0438\u0441\u0447\u0435\u0437\u0430\u044E\u0442 \u043F\u043E\u0441\u043B\u0435 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u043C\u043E\u0433\u043E \u043A\u0443\u0440\u0441\u0430 \u0442\u0435\u0440\u0430\u043F\u0438\u0438, \u0441\u043B\u0435\u0434\u0443\u0435\u0442 \u043F\u0440\u043E\u0439\u0442\u0438 \u043E\u0441\u043C\u043E\u0442\u0440 \u0443 \u043F\u0440\u043E\u043A\u0442\u043E\u043B\u043E\u0433\u0430, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u043F\u043E\u0434\u0431\u0435\u0440\u0435\u0442 \u0434\u0430\u043B\u044C\u043D\u0435\u0439\u0448\u0443\u044E \u0442\u0435\u0440\u0430\u043F\u0438\u044E.</li><li>\u041F\u0440\u0438 \u043D\u0430\u043B\u0438\u0447\u0438\u0438 \u043D\u0430\u0440\u0443\u0448\u0435\u043D\u0438\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0433\u043E \u043A\u0440\u043E\u0432\u043E\u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u044B\u0439 \u044D\u0444\u0444\u0435\u043A\u0442 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0438\u0432\u0430\u0435\u0442\u0441\u044F \u0441\u043E\u0447\u0435\u0442\u0430\u043D\u0438\u0435\u043C \u0442\u0435\u0440\u0430\u043F\u0438\u0438 \u0441\u043E \u0437\u0434\u043E\u0440\u043E\u0432\u044B\u043C (\u0441\u0431\u0430\u043B\u0430\u043D\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u043C) \u043E\u0431\u0440\u0430\u0437\u043E\u043C \u0436\u0438\u0437\u043D\u0438: \u0436\u0435\u043B\u0430\u0442\u0435\u043B\u044C\u043D\u043E \u0438\u0437\u0431\u0435\u0433\u0430\u0442\u044C \u0434\u043E\u043B\u0433\u043E\u0433\u043E \u043F\u0440\u0435\u0431\u044B\u0432\u0430\u043D\u0438\u044F \u043D\u0430 \u0441\u043E\u043B\u043D\u0446\u0435, \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u0431\u044B\u0432\u0430\u043D\u0438\u044F \u043D\u0430 \u043D\u043E\u0433\u0430\u0445, \u0430 \u0442\u0430\u043A\u0436\u0435, \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u0442\u0441\u044F \u0441\u043D\u0438\u0436\u0435\u043D\u0438\u0435 \u0438\u0437\u0431\u044B\u0442\u043E\u0447\u043D\u043E\u0439 \u043C\u0430\u0441\u0441\u044B \u0442\u0435\u043B\u0430. \u041F\u0435\u0448\u0438\u0435 \u043F\u0440\u043E\u0433\u0443\u043B\u043A\u0438 \u0438, \u0432 \u043D\u0435\u043A\u043E\u0442\u043E\u0440\u044B\u0445 \u0441\u043B\u0443\u0447\u0430\u044F\u0445, \u043D\u043E\u0448\u0435\u043D\u0438\u0435 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0445 \u0447\u0443\u043B\u043E\u043A \u0441\u043F\u043E\u0441\u043E\u0431\u0441\u0442\u0432\u0443\u0435\u0442 \u0443\u043B\u0443\u0447\u0448\u0435\u043D\u0438\u044E \u0446\u0438\u0440\u043A\u0443\u043B\u044F\u0446\u0438\u0438 \u043A\u0440\u043E\u0432\u0438.</li></ul><br><br>\u041D\u0435\u0437\u0430\u043C\u0435\u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u0435\u0441\u044C \u043A \u0432\u0440\u0430\u0447\u0443, \u0435\u0441\u043B\u0438 \u0432 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0432\u0430\u0448\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u0443\u0445\u0443\u0434\u0448\u0438\u043B\u043E\u0441\u044C \u0438\u043B\u0438 \u0443\u043B\u0443\u0447\u0448\u0435\u043D\u0438\u044F \u043D\u0435 \u043D\u0430\u0441\u0442\u0443\u043F\u0438\u043B\u043E. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0424\u043E\u0440\u043C\u0430 \u0432\u044B\u043F\u0443\u0441\u043A\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438, \u043F\u043E\u043A\u0440\u044B\u0442\u044B\u0435 \u043F\u043B\u0435\u043D\u043E\u0447\u043D\u043E\u0439 \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u043E\u0439 1000 \u043C\u0433.<br><br>\u041F\u043E 10 \u0442\u0430\u0431\u043B\u0435\u0442\u043E\u043A \u0432 \u0431\u043B\u0438\u0441\u0442\u0435\u0440 \u0438\u0437 \u041F\u0412\u0425 \u0438 \u0430\u043B\u044E\u043C\u0438\u043D\u0438\u0435\u0432\u043E\u0439 \u0444\u043E\u043B\u044C\u0433\u0438.<br><br>\u041F\u043E 3, 6 \u0438\u043B\u0438 9 \u0431\u043B\u0438\u0441\u0442\u0435\u0440\u043E\u0432 \u0432\u043C\u0435\u0441\u0442\u0435 \u0441 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0435\u0439 \u043F\u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043F\u043E\u043C\u0435\u0449\u0430\u044E\u0442 \u0432 \u043A\u0430\u0440\u0442\u043E\u043D\u043D\u0443\u044E \u043F\u0430\u0447\u043A\u0443 \u0441 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u0435\u043C \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u0432\u0441\u043A\u0440\u044B\u0442\u0438\u044F. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0425\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u0440\u0438 \u0442\u0435\u043C\u043F\u0435\u0440\u0430\u0442\u0443\u0440\u0435 \u043D\u0435 \u0432\u044B\u0448\u0435 25 \xBA\u0421.<br>\u0425\u0440\u0430\u043D\u0438\u0442\u044C \u0432 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E\u043C \u0434\u043B\u044F \u0434\u0435\u0442\u0435\u0439 \u043C\u0435\u0441\u0442\u0435! </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0421\u0440\u043E\u043A \u0433\u043E\u0434\u043D\u043E\u0441\u0442\u0438</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> 2 \u0433\u043E\u0434\u0430.<br>\u041D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0442\u044C \u043F\u043E \u0438\u0441\u0442\u0435\u0447\u0435\u043D\u0438\u0438 \u0441\u0440\u043E\u043A\u0430 \u0433\u043E\u0434\u043D\u043E\u0441\u0442\u0438. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u043E\u0442\u043F\u0443\u0441\u043A\u0430</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u041E\u0442\u043F\u0443\u0441\u043A\u0430\u044E\u0442 \u0431\u0435\u0437 \u0440\u0435\u0446\u0435\u043F\u0442\u0430 </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u0422\u0435\u0432\u0430 \u041E\u043F\u0435\u0440\u0435\u0439\u0448\u043D\u0441 \u041F\u043E\u043B\u0430\u043D\u0434 \u0421\u043F. \u0437 \u043E.\u043E.,<br>\u0443\u043B. \u041C\u043E\u0433\u0438\u043B\u044C\u0441\u043A\u0430 80, 31-546 \u041A\u0440\u0430\u043A\u043E\u0432, \u041F\u043E\u043B\u044C\u0448\u0430. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u041F\u0440\u043E\u0442\u0438\u0432\u043E\u043F\u043E\u043A\u0430\u0437\u0430\u043D\u0438\u044F</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u041F\u043E\u0432\u044B\u0448\u0435\u043D\u043D\u0430\u044F \u0447\u0443\u0432\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u043A \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u043C \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430\u043C \u0438\u043B\u0438 \u043A \u0432\u0441\u043F\u043E\u043C\u043E\u0433\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u043C \u0432\u0435\u0449\u0435\u0441\u0442\u0432\u0430\u043C, \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u043C \u0432 \u0441\u043E\u0441\u0442\u0430\u0432 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0412\u043B\u0438\u044F\u043D\u0438\u0435 \u043D\u0430 \u0441\u043F\u043E\u0441\u043E\u0431\u043D\u043E\u0441\u0442\u044C \u043A \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044E \u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u043D\u044B\u043C\u0438 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438 \u0438 \u043C\u0435\u0445\u0430\u043D\u0438\u0437\u043C\u0430\u043C\u0438</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u041A\u043B\u0438\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0439 \u043F\u043E \u0438\u0437\u0443\u0447\u0435\u043D\u0438\u044E \u0432\u043B\u0438\u044F\u043D\u0438\u044F \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u043D\u0430 \u0441\u043F\u043E\u0441\u043E\u0431\u043D\u043E\u0441\u0442\u044C \u0443\u043F\u0440\u0430\u0432\u043B\u044F\u0442\u044C \u0430\u0432\u0442\u043E\u043C\u043E\u0431\u0438\u043B\u0435\u043C \u0438 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0442\u044C \u0440\u0430\u0431\u043E\u0442\u044B, \u0442\u0440\u0435\u0431\u0443\u044E\u0449\u0438\u0435 \u0432\u044B\u0441\u043E\u043A\u043E\u0439 \u0441\u043A\u043E\u0440\u043E\u0441\u0442\u0438 \u043F\u0441\u0438\u0445\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0438 \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0440\u0435\u0430\u043A\u0446\u0438\u0439, \u043D\u0435 \u043F\u0440\u043E\u0432\u043E\u0434\u0438\u043B\u043E\u0441\u044C. \u041E\u0434\u043D\u0430\u043A\u043E \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u043F\u043E \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438, \u043C\u043E\u0436\u043D\u043E \u0441\u0434\u0435\u043B\u0430\u0442\u044C \u0432\u044B\u0432\u043E\u0434, \u0447\u0442\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u043D\u0435 \u0432\u043B\u0438\u044F\u0435\u0442 (\u043D\u0435 \u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0437\u043D\u0430\u0447\u0438\u043C\u043E\u0433\u043E \u0432\u043B\u0438\u044F\u043D\u0438\u044F) \u043D\u0430 \u044D\u0442\u0438 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u044B. </div></div><div class="instruction__item"><div class="instruction__title"><h5>\u0412\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0441 \u0434\u0440\u0443\u0433\u0438\u043C\u0438 \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u043C\u0438 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438</h5><div class="accordion-btn"></div></div><div class="instruction__desc"> \u041A\u043B\u0438\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0439 \u043F\u043E \u0438\u0437\u0443\u0447\u0435\u043D\u0438\u044E \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439 \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u0441 \u0434\u0440\u0443\u0433\u0438\u043C\u0438 \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u043C\u0438 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438 \u043D\u0435 \u043F\u0440\u043E\u0432\u043E\u0434\u0438\u043B\u043E\u0441\u044C. \u0414\u043E \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0435\u0433\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u043D\u0435 \u0441\u043E\u043E\u0431\u0449\u0430\u043B\u043E\u0441\u044C \u043E \u0432\u044B\u044F\u0432\u043B\u0435\u043D\u043D\u044B\u0445 \u0441\u043B\u0443\u0447\u0430\u044F\u0445 \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F. </div></div></div></div><div class="faq__download"><a href="/pdf/instruction_troxactive.pdf" download>`);
      _push(ssrRenderComponent(_component_Button, {
        label: "\u0421\u043A\u0430\u0447\u0430\u0442\u044C PDF",
        rounded: ""
      }, null, _parent));
      _push(`</a></div></div></div></section><section class="sources"><div class="sources__wrapper container"><p>*\u0421\u0438\u043C\u043F\u0442\u043E\u043C\u044B \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0439 \u0432\u0435\u043D <br>** \u041F\u0440\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u0430\u0445 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438 <br>1. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u041B\u041F-\u2116 (000726)-(\u0420\u0413-RU) <br>2. \u041D\u0430\u0438\u0431\u043E\u043B\u0435\u0435 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u043C\u043E\u0435 \u0432\u0440\u0430\u0447\u0430\u043C\u0438 \u041C\u041D\u041D \u0434\u043B\u044F \u0434\u043B\u044F \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0425\u0417\u0412 (\u041C\u043E\u043D\u0438\u0442\u043E\u0440\u0438\u043D\u0433 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u041B\u041F \u0432\u0440\u0430\u0447\u0430\u043C\u0438 PrIndex (\u041F\u0440\u0438\u043D\u0434\u0435\u043A\u0441), 3\u043A\u0432 2022) <br>3. \u0413\u0420\u041B\u0421, \u0414\u0430\u0442\u0430 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 09.02.2023 <br>4. Garner RC, et al. J Pharm Sci. 2002;91(1):32\u201340 // \u0413\u0430\u0440\u043D\u0435\u0440 \u0420\u0421 \u0438 \u0434\u0440. \u0416\u0443\u0440\u043D\u0430\u043B \u0424\u0430\u0440\u043C\u0430\u0446\u0435\u0432\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u041D\u0430\u0443\u043A. 2002;91(1):32\u201340 <br>5. \u041F\u043E \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E \u0441 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432\u043E\u043C 30\u0448\u0442. \u041F\u0440\u043E\u0446\u0435\u043D\u0442 \u044D\u043A\u043E\u043D\u043E\u043C\u0438\u0438 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D \u043F\u043E \u043E\u0442\u043F\u0443\u0441\u043A\u043D\u044B\u043C \u0446\u0435\u043D\u0430\u043C \u041E\u041E\u041E \xAB\u0422\u0435\u0432\u0430\xBB \u043D\u0430 1 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0443 (\u041C\u0430\u0440\u0442 2023) <br>6. \u041B\u0438\u0441\u0442\u043E\u043A-\u0432\u043A\u043B\u0430\u0434\u044B\u0448 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u041D\u0435\u043E \u041B\u041F-\u2116(001509)-(\u0420\u0413-RU) https://portal.eaeunion.org/sites/commonprocesses/ru-ru/Pages/CardView.aspx?documentId=6206058bfb44f12d3bb0566b&amp;codeId=P.MM.01 <br>7. \u0420\u043E\u0437\u043D\u0438\u0447\u043D\u0430\u044F \u0446\u0435\u043D\u0430 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0433\u0435\u043B\u044C 2% 40\u0433 - 360.4\u0440 (IQVIA, \u0434\u0435\u043A\u0430\u0431\u0440\u044C 2022) <br>8. \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0432 \u0420\u043E\u0441\u0441\u0438\u0438 \u0441 1981 \u0433. \u0420\u0423 \u0411-8-242 \u21162654 <br>9. \u0420\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u041C\u041E\u0424\u0424 \u043F\u0440\u0438 \u0425\u0417\u0412. \u0411\u043E\u0433\u0430\u0447\u0435\u0432 \u0412.\u042E., \u0411\u043E\u043B\u0434\u0438\u043D \u0411.\u0412., \u0438 \u0434\u0440. \u0421\u043E\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0435 \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u0438\u044F \u043A \u0444\u043B\u0435\u0431\u043E\u0442\u0440\u043E\u043F\u043D\u043E\u0439 \u0442\u0435\u0440\u0430\u043F\u0438\u0438 \u0438 \u0435\u0451 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C. \u0410\u043C\u0431\u0443\u043B\u0430\u0442\u043E\u0440\u043D\u0430\u044F \u0445\u0438\u0440\u0443\u0440\u0433\u0438\u044F: 2021;18(1):13-23 <br>10. \u0420\u043E\u0437\u043D\u0438\u0447\u043D\u0430\u044F \u0446\u0435\u043D\u0430 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432\u0430 30 \u0442\u0430\u0431 \u2013 1197,66 \u0440\u0443\u0431 (IQVIA, \u0414\u0435\u043A\u0430\u0431\u0440\u044C 2022) </p></div></section>`);
      _push(ssrRenderComponent(_component_ModalMoff, {
        visible: unref(visible),
        "onUpdate:visible": ($event) => isRef(visible) ? visible.value = $event : null
      }, null, _parent));
      _push(ssrRenderComponent(_component_ModalUteka, {
        visible: unref(visibleUteka),
        "onUpdate:visible": ($event) => isRef(visibleUteka) ? visibleUteka.value = $event : null,
        "url-products": unref(productsForUteka),
        troxactive: true
      }, null, _parent));
      _push(`</main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/troxactive.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=troxactive-1de0a250.mjs.map
