import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { u as useHead, _ as __nuxt_component_0$1, a as __nuxt_component_0$2, b as __nuxt_component_3$1 } from '../server.mjs';
import { _ as _imports_2, a as _imports_3, b as _imports_6, c as _imports_7, d as _imports_8, e as _imports_9, f as _imports_11, g as _imports_12, h as _imports_15, i as _imports_16, j as _imports_17, k as _imports_18, l as __nuxt_component_2 } from './symptom-case-3_2x-e03ad760.mjs';
import { ref, withCtx, createVNode, unref, createTextVNode, isRef, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1 } from './header-1_2x-507a714e.mjs';
import { _ as _imports_4, a as _imports_5, b as _imports_10, c as _imports_13, d as _imports_14, e as _imports_19, f as _imports_20, g as _imports_21 } from './doc-269ff25e.mjs';
import { _ as _imports_28 } from './other-gel-neo-1056c3e4.mjs';
import { _ as _imports_28$1 } from './other-troxactive-4cd7fa82.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Navigation } from 'swiper';
import 'vue-bundle-renderer/runtime';
import 'h3';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _imports_22 = "" + publicAssetsURL("img/case/vozdey-hard.png");
const _sfc_main = {
  __name: "case-varikoz-hard",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0412\u0430\u0440\u0438\u043A\u043E\u0437"
    });
    const onSwiper = (swiper) => {
    };
    ref(null);
    const visible = ref(false);
    const visibleUteka = ref(false);
    let productsForUteka = null;
    const openUteka = (i) => {
      if (i && typeof i === "string")
        productsForUteka = i;
      visibleUteka.value = true;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Button = __nuxt_component_0$1;
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_ModalVeni = __nuxt_component_2;
      const _component_ModalUteka = __nuxt_component_3$1;
      _push(`<main${ssrRenderAttrs(_attrs)}><header class="header-case" id="header"><div class="header-case__wrapper container"><div class="header-case__top"><h1 class="title-h1 header-case__title">\u0412\u0430\u0440\u0438\u043A\u043E\u0437<sup>*</sup> \u043C\u043E\u0436\u0435\u0442 \u0441\u043E\u043F\u0440\u043E\u0432\u043E\u0436\u0434\u0430\u0442\u044C\u0441\u044F \u0442\u0430\u043A\u0438\u043C\u0438 \u043F\u0440\u043E\u044F\u0432\u043B\u0435\u043D\u0438\u044F\u043C\u0438 \u043A\u0430\u043A <strong>\u043E\u0442\u0435\u043A\u0438 \u0438 \u0441\u0443\u0434\u043E\u0440\u043E\u0433\u0438 \u0432 \u043D\u043E\u0433\u0430\u0445<sup>1</sup></strong></h1><div class="header-case__img"><img${ssrRenderAttr("src", _imports_0)}${ssrRenderAttr("srcset", _imports_1 + " 2x")} alt="" loading="lazy"></div></div><div class="header-case__list"><div class="header-case__item"><img${ssrRenderAttr("src", _imports_2)}${ssrRenderAttr("srcset", _imports_3 + " 2x")} alt="" loading="lazy"><p>\u0417\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0435 \u043C\u043E\u0436\u0435\u0442 \u043F\u0440\u043E\u0433\u0440\u0435\u0441\u0441\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u2014 <strong>\u043D\u0430 \u0442\u044F\u0436\u0435\u043B\u044B\u0445 \u0441\u0442\u0430\u0434\u0438\u044F\u0445 \u043B\u044E\u0434\u0438 \u043C\u043E\u0433\u0443\u0442 \u0441\u0442\u0430\u043B\u043A\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u0434\u0430\u0436\u0435 \u0441 \u0442\u0440\u043E\u0444\u0438\u0447\u0435\u0441\u043A\u0438\u043C\u0438 \u044F\u0437\u0432\u0430\u043C\u0438</strong>. \u0423\u0447\u0435\u043D\u044B\u0435 \u0432\u044B\u0434\u0435\u043B\u044F\u044E\u0442 7 \u043A\u043B\u0430\u0441\u0441\u043E\u0432 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0439 \u0432\u0435\u043D. \u0412\u043E\u0442 \u043A\u0430\u043A \u043E\u043D\u0438 <i>\u0440\u0430\u0437\u043B\u0438\u0447\u0430\u044E\u0442\u0441\u044F</i>. </p></div><div class="header-case__item"><img${ssrRenderAttr("src", _imports_4)}${ssrRenderAttr("srcset", _imports_5 + " 2x")} alt="" loading="lazy"><p>\u041F\u0440\u0438 \u043F\u0435\u0440\u0432\u044B\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0430\u0445 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u044F <strong>\u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u044C\u0441\u044F \u043A \u0432\u0440\u0430\u0447\u0443</strong> \u0438 \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043F\u043B\u0430\u043D \u043B\u0435\u0447\u0435\u043D\u0438\u044F, \u0447\u0442\u043E\u0431\u044B \u0438\u0437\u0431\u0435\u0436\u0430\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0435\u0441\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u044F. </p></div></div></div></header><section class="factors" id="factors"><div class="factors__wrapper container"><div class="factors__content"><h2 class="title-h1">\u0424\u0430\u043A\u0442\u043E\u0440\u044B \u0440\u0438\u0441\u043A\u0430 \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u0439 \u0432\u0435\u043D<sup>1</sup></h2><ul class="factors__list"><li class="factors__item"><img${ssrRenderAttr("src", _imports_6)} alt="" loading="lazy"><p>\u041E\u0436\u0438\u0440\u0435\u043D\u0438\u0435</p></li><li class="factors__item"><img${ssrRenderAttr("src", _imports_7)} alt="" loading="lazy"><p>\u0412\u043E\u0437\u0440\u0430\u0441\u0442</p></li><li class="factors__item"><img${ssrRenderAttr("src", _imports_8)} alt="" loading="lazy"><p>\u0411\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u044C</p></li><li class="factors__item factors-50"><img${ssrRenderAttr("src", _imports_9)} alt="" loading="lazy"><p>\u0413\u0435\u043D\u0435\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F <br> \u043F\u0440\u0435\u0434\u0440\u0430\u0441\u043F\u043E\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u044C</p></li><li class="factors__item factors-50"><img${ssrRenderAttr("src", _imports_10)} alt="" loading="lazy"><p>\u0421\u0438\u0434\u044F\u0447\u0430\u044F \u0438\u043B\u0438 <br> \u0441\u0442\u043E\u044F\u0447\u0430\u044F \u0440\u0430\u0431\u043E\u0442\u0430</p></li></ul></div></div></section><section class="symptoms" id="symptoms"><div class="symptoms__wrapper container"><div class="symptoms__content"><div class="symptoms__head"><h2 class="title-h1">\u0414\u043B\u044F \u0431\u043E\u0440\u044C\u0431\u044B \u0441 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u043E\u043C<sup>*</sup></h2><p>\u041C\u043E\u0436\u0435\u0442 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0442\u044C\u0441\u044F \u043A\u043E\u043C\u0431\u0438\u043D\u0430\u0446\u0438\u044F \u0440\u0430\u0437\u043B\u0438\u0447\u043D\u044B\u0445 \u043C\u0435\u0442\u043E\u0434\u043E\u0432 \u043B\u0435\u0447\u0435\u043D\u0438\u044F</p></div><div class="symptoms__img"><img${ssrRenderAttr("src", _imports_11)}${ssrRenderAttr("srcset", _imports_12 + " 2x")} alt="" loading="lazy"></div><ul class="symptoms__list"><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_13)}${ssrRenderAttr("srcset", _imports_14 + " 2x")} alt="" loading="lazy"><p>\u041C\u0435\u0434\u0438\u043A\u0430\u043C\u0435\u043D\u0442\u043E\u0437\u043D\u0430\u044F <br>\u0442\u0435\u0440\u0430\u043F\u0438\u044F</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_15)}${ssrRenderAttr("srcset", _imports_16 + " 2x")} alt="" loading="lazy"><p>\u041A\u043E\u043C\u043F\u0440\u0435\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0439 <br>\u0442\u0440\u0438\u043A\u043E\u0442\u0430\u0436</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_17)}${ssrRenderAttr("srcset", _imports_18 + " 2x")} alt="" loading="lazy"><p>\u041B\u0435\u0447\u0435\u0431\u043D\u0430\u044F <br>\u0444\u0438\u0437\u043A\u0443\u043B\u044C\u0442\u0443\u0440\u0430</p></li><li class="symptoms__item"><img${ssrRenderAttr("src", _imports_19)}${ssrRenderAttr("srcset", _imports_20 + " 2x")} alt="" loading="lazy"><p>\u0425\u0438\u0440\u0443\u0440\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0435 <br>\u0432\u043C\u0435\u0448\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E</p></li></ul><div class="symptoms__doctor"><img${ssrRenderAttr("src", _imports_21)} alt="" loading="lazy"><p>\u041D\u0435 \u0437\u0430\u0431\u044B\u0432\u0430\u0439\u0442\u0435 \u2014 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443 \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0432 \u043A\u0430\u0436\u0434\u043E\u043C \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u043E\u043C \u0441\u043B\u0443\u0447\u0430\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0430\u0435\u0442 \u0432\u0440\u0430\u0447 </p></div></div></div></section><section class="vozdeystvyi" id="vozdeystvyi"><div class="vozdeystvyi__wrapper container"><div class="vozdeystvyi__content"><div class="vozdeystvyi__head"><h2 class="title-h1">\u0414\u043B\u044F \u0432\u043E\u0437\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043D\u0430 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u044B <br> \u0438\u0437\u043D\u0443\u0442\u0440\u0438 \u0438 \u0441\u043D\u0430\u0440\u0443\u0436\u0438</h2></div><div class="vozdeystvyi__body"><div class="vozdeystvyi__left"><p>\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u0434\u043B\u044F \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043D\u0430 \u0432\u0435\u043D\u044B \u0438\u0437\u043D\u0443\u0442\u0440\u0438<sup>3</sup> \u0438 \u0433\u0435\u043B\u044C \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u041D\u0435\u043E \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439<sup>**</sup> \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439 \u0434\u043B\u044F \u0432\u043E\u0437\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043D\u0430 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u044B \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup>*</sup> \u0441\u043D\u0430\u0440\u0443\u0436\u0438<sup>2 </sup></p>`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944&productIds=266995&productIds=377032"),
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: ""
      }, null, _parent));
      _push(`<span>** \u041F\u043E \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E \u0441 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0433\u0435\u043B\u044C 2 % </span></div><div class="vozdeystvyi__right"><img${ssrRenderAttr("src", _imports_22)} alt="" loading="lazy">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944&productIds=266995&productIds=377032"),
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: ""
      }, null, _parent));
      _push(`</div></div></div></div></section><section class="others" id="products"><div class="others__wrapper container"><div class="others__content"><div class="others__list"><div class="others__item swiper-gel-1"><h2 class="title-h1">\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> <br> \u041D\u0435\u043E \u0433\u0435\u043B\u044C</h2><img${ssrRenderAttr("src", _imports_28)} alt="" loading="lazy"><p><strong class="others-violet">\u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u044F \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u2014 </strong> \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u041D\u0435\u043E \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439<sup>**</sup> \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439<sup>2</sup></p><div class="others__btns">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=266995&productIds=377032"),
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_neo"
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/neo",
        id: "neo"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="others__item swiper-gel-1"><h2 class="title-h1">\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 <br>\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438</h2><img${ssrRenderAttr("src", _imports_28$1)} alt="" loading="lazy"><p><strong class="others-orange">\u0421\u0430\u043C\u0430\u044F \u0432\u043E\u0441\u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u0430 (\u041C\u041D\u041D)<sup>4</sup></strong><br> \u0432 \u043B\u0435\u0447\u0435\u043D\u0438\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 <br> \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup>*</sup></p><div class="others__btns">`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944"),
        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
        arrowRight: "",
        id: "buy_troxactive"
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/troxactive",
        id: "troxactive"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div><div class="others__swiper">`);
      _push(ssrRenderComponent(unref(Swiper), {
        "slides-per-view": 1,
        "space-between": 20,
        onSwiper,
        modules: [unref(Navigation)],
        navigation: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="others__item"${_scopeId2}><h2 class="title-h1"${_scopeId2}>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> <br${_scopeId2}> \u041D\u0435\u043E \u0433\u0435\u043B\u044C</h2><img${ssrRenderAttr("src", _imports_28)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}><strong class="others-violet"${_scopeId2}>\u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u044F \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> \u2014 </strong>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> \u041D\u0435\u043E \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439<sup${_scopeId2}>**</sup> \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439<sup${_scopeId2}>2</sup></p><div class="others__btns"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_Button, {
                    onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=266995&productIds=377032"),
                    label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                    arrowRight: "",
                    id: "buy_neo"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/neo",
                    id: "neo"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "others__item" }, [
                      createVNode("h2", { class: "title-h1" }, [
                        createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(),
                        createVNode("br"),
                        createTextVNode(" \u041D\u0435\u043E \u0433\u0435\u043B\u044C")
                      ]),
                      createVNode("img", {
                        src: _imports_28,
                        alt: "",
                        loading: "lazy"
                      }),
                      createVNode("p", null, [
                        createVNode("strong", { class: "others-violet" }, [
                          createTextVNode("\u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u044F \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                          createVNode("sup", null, "\xAE"),
                          createTextVNode(" \u2014 ")
                        ]),
                        createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(" \u041D\u0435\u043E \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439"),
                        createVNode("sup", null, "**"),
                        createTextVNode(" \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439"),
                        createVNode("sup", null, "2")
                      ]),
                      createVNode("div", { class: "others__btns" }, [
                        createVNode(_component_Button, {
                          onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=266995&productIds=377032"),
                          label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                          arrowRight: "",
                          id: "buy_neo"
                        }, null, 8, ["onClick"]),
                        createVNode(_component_NuxtLink, {
                          to: "/neo",
                          id: "neo"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_Button, {
                              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                              rounded: ""
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="others__item"${_scopeId2}><h2 class="title-h1"${_scopeId2}>\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 <br${_scopeId2}>\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438</h2><img${ssrRenderAttr("src", _imports_28$1)} alt="" loading="lazy"${_scopeId2}><p${_scopeId2}><strong class="others-orange"${_scopeId2}>\u0421\u0430\u043C\u0430\u044F \u0432\u043E\u0441\u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u0430 (\u041C\u041D\u041D)<sup${_scopeId2}>4</sup></strong><br${_scopeId2}> \u0432 \u043B\u0435\u0447\u0435\u043D\u0438\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 <br${_scopeId2}> \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup${_scopeId2}>*</sup></p><div class="others__btns"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_Button, {
                    onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944"),
                    label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                    arrowRight: "",
                    id: "buy_troxactive"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/troxactive",
                    id: "troxactive"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "others__item" }, [
                      createVNode("h2", { class: "title-h1" }, [
                        createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 "),
                        createVNode("br"),
                        createTextVNode("\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438")
                      ]),
                      createVNode("img", {
                        src: _imports_28$1,
                        alt: "",
                        loading: "lazy"
                      }),
                      createVNode("p", null, [
                        createVNode("strong", { class: "others-orange" }, [
                          createTextVNode("\u0421\u0430\u043C\u0430\u044F \u0432\u043E\u0441\u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u0430 (\u041C\u041D\u041D)"),
                          createVNode("sup", null, "4")
                        ]),
                        createVNode("br"),
                        createTextVNode(" \u0432 \u043B\u0435\u0447\u0435\u043D\u0438\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 "),
                        createVNode("br"),
                        createTextVNode(" \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430"),
                        createVNode("sup", null, "*")
                      ]),
                      createVNode("div", { class: "others__btns" }, [
                        createVNode(_component_Button, {
                          onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944"),
                          label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                          arrowRight: "",
                          id: "buy_troxactive"
                        }, null, 8, ["onClick"]),
                        createVNode(_component_NuxtLink, {
                          to: "/troxactive",
                          id: "troxactive"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_Button, {
                              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                              rounded: ""
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "others__item" }, [
                    createVNode("h2", { class: "title-h1" }, [
                      createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                      createVNode("sup", null, "\xAE"),
                      createTextVNode(),
                      createVNode("br"),
                      createTextVNode(" \u041D\u0435\u043E \u0433\u0435\u043B\u044C")
                    ]),
                    createVNode("img", {
                      src: _imports_28,
                      alt: "",
                      loading: "lazy"
                    }),
                    createVNode("p", null, [
                      createVNode("strong", { class: "others-violet" }, [
                        createTextVNode("\u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u044F \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(" \u2014 ")
                      ]),
                      createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                      createVNode("sup", null, "\xAE"),
                      createTextVNode(" \u041D\u0435\u043E \u0441 \u0443\u0441\u0438\u043B\u0435\u043D\u043D\u043E\u0439"),
                      createVNode("sup", null, "**"),
                      createTextVNode(" \u0442\u0440\u0435\u0445\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439"),
                      createVNode("sup", null, "2")
                    ]),
                    createVNode("div", { class: "others__btns" }, [
                      createVNode(_component_Button, {
                        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=266995&productIds=377032"),
                        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                        arrowRight: "",
                        id: "buy_neo"
                      }, null, 8, ["onClick"]),
                      createVNode(_component_NuxtLink, {
                        to: "/neo",
                        id: "neo"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "others__item" }, [
                    createVNode("h2", { class: "title-h1" }, [
                      createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 "),
                      createVNode("br"),
                      createTextVNode("\u0422\u0430\u0431\u043B\u0435\u0442\u043A\u0438")
                    ]),
                    createVNode("img", {
                      src: _imports_28$1,
                      alt: "",
                      loading: "lazy"
                    }),
                    createVNode("p", null, [
                      createVNode("strong", { class: "others-orange" }, [
                        createTextVNode("\u0421\u0430\u043C\u0430\u044F \u0432\u043E\u0441\u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u0430 (\u041C\u041D\u041D)"),
                        createVNode("sup", null, "4")
                      ]),
                      createVNode("br"),
                      createTextVNode(" \u0432 \u043B\u0435\u0447\u0435\u043D\u0438\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 "),
                      createVNode("br"),
                      createTextVNode(" \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430"),
                      createVNode("sup", null, "*")
                    ]),
                    createVNode("div", { class: "others__btns" }, [
                      createVNode(_component_Button, {
                        onClick: ($event) => openUteka("https://widget.uteka.ru/widgets/full/?productIds=376787&productIds=376941&productIds=376944"),
                        label: "\u041A\u0443\u043F\u0438\u0442\u044C",
                        arrowRight: "",
                        id: "buy_troxactive"
                      }, null, 8, ["onClick"]),
                      createVNode(_component_NuxtLink, {
                        to: "/troxactive",
                        id: "troxactive"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><p class="others__footnote">** \u041F\u043E \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E \u0441 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0433\u0435\u043B\u044C 2 %</p></div></div></section><section class="sources"><div class="sources__wrapper container"><p>* \u0425\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438 <br>1. \u0412\u0430\u0440\u0438\u043A\u043E\u0437\u043D\u043E\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0432\u0435\u043D \u043D\u0438\u0436\u043D\u0438\u0445 \u043A\u043E\u043D\u0435\u0447\u043D\u043E\u0441\u0442\u0435\u0439. \u041A\u043B\u0438\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u0438 \u041C\u0417 \u0420\u0424, \u0433\u043E\u0434 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F 2024 <br>2. \u041B\u0438\u0441\u0442\u043E\u043A-\u0432\u043A\u043B\u0430\u0434\u044B\u0448 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u041D\u0435\u043E \u041B\u041F-\u2116(001509)-(\u0420\u0413-RU) https://storage.brandquad.ru/accounts-media/TEVA/DAM/origin/0f2faedc-c44e-11ef-a2ec-061441bd84b0.pdf. \u0414\u0430\u0442\u0430 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F: 21.04.2025. <br>3. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u041B\u041F-\u2116(000726)-(\u0420\u0413-RU) <br>4. \u041D\u0430\u0438\u0431\u043E\u043B\u0435\u0435 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u043C\u043E\u0435 \u0432\u0440\u0430\u0447\u0430\u043C\u0438 \u041C\u041D\u041D \u0434\u043B\u044F \u043B\u0435\u0447\u0435\u043D\u0438\u044F \u0425\u0417\u0412 (\u041C\u043E\u043D\u0438\u0442\u043E\u0440\u0438\u043D\u0433 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u041B\u041F \u0432\u0440\u0430\u0447\u0430\u043C\u0438 PrIndex (\u041F\u0440\u0438\u043D\u0434\u0435\u043A\u0441), 4\u043A\u0432 2024) </p></div></section>`);
      _push(ssrRenderComponent(_component_ModalVeni, {
        visible: unref(visible),
        "onUpdate:visible": ($event) => isRef(visible) ? visible.value = $event : null
      }, null, _parent));
      _push(ssrRenderComponent(_component_ModalUteka, {
        visible: unref(visibleUteka),
        "onUpdate:visible": ($event) => isRef(visibleUteka) ? visibleUteka.value = $event : null,
        "url-products": unref(productsForUteka)
      }, null, _parent));
      _push(`</main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/case-varikoz-hard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=case-varikoz-hard-50987507.mjs.map
