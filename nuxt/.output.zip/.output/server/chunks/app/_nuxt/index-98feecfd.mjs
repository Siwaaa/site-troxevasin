import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { u as useHead, a as __nuxt_component_0$2, _ as __nuxt_component_0$1 } from '../server.mjs';
import { withCtx, createTextVNode, createVNode, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Navigation } from 'swiper';
import 'vue-bundle-renderer/runtime';
import 'h3';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _imports_0 = "" + publicAssetsURL("img/main_fon-mobile.webp");
const _imports_1 = "" + publicAssetsURL("img/ico.svg");
const _imports_2 = "" + publicAssetsURL("img/product-1.png");
const _imports_3 = "" + publicAssetsURL("img/product-1@2x.png");
const _imports_4 = "" + publicAssetsURL("img/product-2.png");
const _imports_5 = "" + publicAssetsURL("img/product-2@2x.png");
const _imports_6 = "" + publicAssetsURL("img/product-3.png");
const _imports_7 = "" + publicAssetsURL("img/product-3@2x.png");
const _imports_8 = "" + publicAssetsURL("img/product-4.png");
const _imports_9 = "" + publicAssetsURL("img/product-4@2x.png");
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"
    });
    const onSwiper = (swiper) => {
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_Button = __nuxt_component_0$1;
      _push(`<main${ssrRenderAttrs(_attrs)}><header class="header"><div class="header__wrapper container"><div class="header__content"><h1 class="title-h1">\u0422\u0420\u041E\u041A\u0421\u0415\u0412\u0410\u0417\u0418\u041D<sup>\xAE</sup> \u2014 <br> \u0448\u0430\u0433 \u0432\u043F\u0435\u0440\u0435\u0434 \u043A \u043B\u0435\u0447\u0435\u043D\u0438\u044E \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup>*</sup></h1><p>\u042D\u043A\u0441\u043F\u0435\u0440\u0442\u044B \u0431\u0440\u0435\u043D\u0434\u0430 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u0432\u0441\u0451 \u0437\u043D\u0430\u044E\u0442 \u043E \u043B\u0435\u0447\u0435\u043D\u0438\u0438 \u0441\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup>*</sup> \u0438 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u044F<sup>3</sup>. </p><p><strong>\u041E \u0447\u0435\u043C \u0445\u043E\u0442\u0435\u043B\u0438 \u0431\u044B \u0443\u0437\u043D\u0430\u0442\u044C \u0432\u044B?</strong></p><div class="header__menu">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/case-varikoz-lite",
        class: "btn-hexagon"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u0417\u0432\u0435\u0437\u0434\u043E\u0447\u043A\u0438, \u0442\u044F\u0436\u0435\u0441\u0442\u044C, <br${_scopeId}> \u0443\u0441\u0442\u0430\u043B\u043E\u0441\u0442\u044C \u0432 \u043D\u043E\u0433\u0430\u0445 <div class="btn-hexagon__arrow"${_scopeId}></div>`);
          } else {
            return [
              createTextVNode(" \u0417\u0432\u0435\u0437\u0434\u043E\u0447\u043A\u0438, \u0442\u044F\u0436\u0435\u0441\u0442\u044C, "),
              createVNode("br"),
              createTextVNode(" \u0443\u0441\u0442\u0430\u043B\u043E\u0441\u0442\u044C \u0432 \u043D\u043E\u0433\u0430\u0445 "),
              createVNode("div", { class: "btn-hexagon__arrow" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/case-varikoz-middle",
        class: "btn-hexagon"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u0412\u044B\u043F\u0438\u0440\u0430\u044E\u0449\u0438\u0435 \u0432\u0435\u043D\u044B <br${_scopeId}> \u0438 \u0431\u043E\u043B\u044C \u0432 \u043D\u043E\u0433\u0430\u0445 <div class="btn-hexagon__arrow"${_scopeId}></div>`);
          } else {
            return [
              createTextVNode(" \u0412\u044B\u043F\u0438\u0440\u0430\u044E\u0449\u0438\u0435 \u0432\u0435\u043D\u044B "),
              createVNode("br"),
              createTextVNode(" \u0438 \u0431\u043E\u043B\u044C \u0432 \u043D\u043E\u0433\u0430\u0445 "),
              createVNode("div", { class: "btn-hexagon__arrow" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/case-varikoz-hard",
        class: "btn-hexagon"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u041E\u0442\u0435\u043A\u0438 \u0438 \u0441\u0443\u0434\u043E\u0440\u043E\u0433\u0438 <br${_scopeId}> \u0432 \u043D\u043E\u0433\u0430\u0445 <div class="btn-hexagon__arrow"${_scopeId}></div>`);
          } else {
            return [
              createTextVNode(" \u041E\u0442\u0435\u043A\u0438 \u0438 \u0441\u0443\u0434\u043E\u0440\u043E\u0433\u0438 "),
              createVNode("br"),
              createTextVNode(" \u0432 \u043D\u043E\u0433\u0430\u0445 "),
              createVNode("div", { class: "btn-hexagon__arrow" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/case-hemorrhoids",
        class: "btn-hexagon"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u0414\u0438\u0441\u043A\u043E\u043C\u0444\u043E\u0440\u0442 \u0438 \u0431\u043E\u043B\u044C <br${_scopeId}> \u043F\u0440\u0438 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435 <div class="btn-hexagon__arrow"${_scopeId}></div>`);
          } else {
            return [
              createTextVNode(" \u0414\u0438\u0441\u043A\u043E\u043C\u0444\u043E\u0440\u0442 \u0438 \u0431\u043E\u043B\u044C "),
              createVNode("br"),
              createTextVNode(" \u043F\u0440\u0438 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435 "),
              createVNode("div", { class: "btn-hexagon__arrow" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="header-mobile"><img${ssrRenderAttr("src", _imports_0)} alt="" loading="lazy"></div></div></div></header><section class="expert"><div class="expert__wrapper container"><div class="expert__img"><img${ssrRenderAttr("src", _imports_1)} alt="" loading="lazy"></div><div class="expert__content"><p class="expert__title">\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> \u0431\u043E\u043B\u044C\u0448\u0435 40 \u043B\u0435\u0442<sup>1</sup> \u043F\u0440\u0438\u0445\u043E\u0434\u0438\u0442 \u043D\u0430 \u043F\u043E\u043C\u043E\u0449\u044C \u043B\u044E\u0434\u044F\u043C, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0441\u0442\u043E\u043B\u043A\u043D\u0443\u043B\u0438\u0441\u044C \u0441 \u043F\u0440\u043E\u044F\u0432\u043B\u0435\u043D\u0438\u044F\u043C\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438<sup>2</sup>. </p><p class="expert__text">\u041C\u044B \u0446\u0435\u043D\u0438\u043C \u0434\u043E\u0432\u0435\u0440\u0438\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u0438\u0445 \u043F\u043E\u043A\u043E\u043B\u0435\u043D\u0438\u0439 \u0438 \u043E\u0442\u0432\u0435\u0447\u0430\u0435\u043C \u043D\u0430 \u043D\u0435\u0433\u043E \u0448\u0438\u0440\u043E\u043A\u043E\u0439 \u043B\u0438\u043D\u0435\u0439\u043A\u043E\u0439 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u043E\u0432 \u0435\u0432\u0440\u043E\u043F\u0435\u0439\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0430<sup>2</sup> \u0438 \u043F\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u043C \u0446\u0435\u043D\u0430\u043C<sup>4</sup>. </p></div></div></section><section class="products" id="products"><div class="products__wrapper container"><div class="products__list"><div class="products__item"><div class="products__item-content"><h3 class="products__item-title">\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> <br>\u041D\u0435\u043E \u0433\u0435\u043B\u044C </h3><div class="products__item-img"><img${ssrRenderAttr("src", _imports_2)}${ssrRenderAttr("srcset", _imports_3 + " 2x")} alt="" loading="lazy"></div><p class="products__item-desc">\u0423\u0441\u0438\u043B\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u0430<sup>5</sup> \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0441 \u0442\u0440\u043E\u0439\u043D\u044B\u043C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435\u043C<sup>6</sup></p></div><div class="products__item-btn">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/neo",
        id: "neo"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="products__item"><div class="products__item-content"><h3 class="products__item-title">\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> <br>\u0433\u0435\u043B\u044C 2 %</h3><div class="products__item-img"><img${ssrRenderAttr("src", _imports_4)}${ssrRenderAttr("srcset", _imports_5 + " 2x")} alt="" loading="lazy"></div><p class="products__item-desc">\u0421\u0430\u043C\u044B\u0439 \u043F\u0440\u043E\u0434\u0430\u0432\u0430\u0435\u043C\u044B\u0439 \u0433\u0435\u043B\u044C<sup>7</sup> \u043F\u0440\u043E\u0442\u0438\u0432 \u0442\u044F\u0436\u0435\u0441\u0442\u0438 \u0438 \u0431\u043E\u043B\u0438 \u0432 \u043D\u043E\u0433\u0430\u0445 \u043F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435<sup>**,8</sup></p></div><div class="products__item-btn">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/gel",
        id: "gel"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="products__item"><div class="products__item-content"><h3 class="products__item-title">\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 <br>\u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438</h3><div class="products__item-img"><img${ssrRenderAttr("src", _imports_6)}${ssrRenderAttr("srcset", _imports_7 + " 2x")} alt="" loading="lazy"></div><p class="products__item-desc">\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0442 \u043D\u0430 \u0432\u0435\u043D\u044B \u0438\u0437\u043D\u0443\u0442\u0440\u0438<sup>9</sup> \u043F\u0440\u0438 \u0425\u0412\u041D<sup>*</sup>. \u0421\u0430\u043C\u0430\u044F \u0432\u043E\u0441\u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u043D\u0430\u044F<sup>10</sup> \u0444\u043E\u0440\u043C\u0443\u043B\u0430 (\u041C\u041D\u041D) \u0432 \u043B\u0435\u0447\u0435\u043D\u0438\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup>*</sup></p></div><div class="products__item-btn">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/troxactive",
        id: "troxactive"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="products__item"><div class="products__item-content"><h3 class="products__item-title">\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup>\xAE</sup> <br>\u043A\u0430\u043F\u0441\u0443\u043B\u044B</h3><div class="products__item-img"><img${ssrRenderAttr("src", _imports_8)}${ssrRenderAttr("srcset", _imports_9 + " 2x")} alt="" loading="lazy"></div><p class="products__item-desc">\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043E<sup>12</sup> \u043F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438 \u0438 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435<sup>11</sup></p></div><div class="products__item-btn">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/capsules",
        id: "capsules"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Button, {
              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
              rounded: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Button, {
                label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                rounded: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div><div class="products__swiper">`);
      _push(ssrRenderComponent(unref(Swiper), {
        "slides-per-view": 1,
        "space-between": 20,
        onSwiper,
        modules: [unref(Navigation)],
        navigation: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="products__item"${_scopeId2}><div class="products__item-content"${_scopeId2}><h3 class="products__item-title"${_scopeId2}>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> <br${_scopeId2}>\u041D\u0435\u043E \u0433\u0435\u043B\u044C </h3><div class="products__item-img"${_scopeId2}><img${ssrRenderAttr("src", _imports_2)}${ssrRenderAttr("srcset", _imports_3 + " 2x")} alt="" loading="lazy"${_scopeId2}></div><p class="products__item-desc"${_scopeId2}>\u0423\u0441\u0438\u043B\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u0430<sup${_scopeId2}>5</sup> \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0441 \u0442\u0440\u043E\u0439\u043D\u044B\u043C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435\u043C<sup${_scopeId2}>6</sup></p></div><div class="products__item-btn"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_NuxtLink, { to: "/neo" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "products__item" }, [
                      createVNode("div", { class: "products__item-content" }, [
                        createVNode("h3", { class: "products__item-title" }, [
                          createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                          createVNode("sup", null, "\xAE"),
                          createTextVNode(),
                          createVNode("br"),
                          createTextVNode("\u041D\u0435\u043E \u0433\u0435\u043B\u044C ")
                        ]),
                        createVNode("div", { class: "products__item-img" }, [
                          createVNode("img", {
                            src: _imports_2,
                            srcset: _imports_3 + " 2x",
                            alt: "",
                            loading: "lazy"
                          })
                        ]),
                        createVNode("p", { class: "products__item-desc" }, [
                          createTextVNode("\u0423\u0441\u0438\u043B\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u0430"),
                          createVNode("sup", null, "5"),
                          createTextVNode(" \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0441 \u0442\u0440\u043E\u0439\u043D\u044B\u043C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435\u043C"),
                          createVNode("sup", null, "6")
                        ])
                      ]),
                      createVNode("div", { class: "products__item-btn" }, [
                        createVNode(_component_NuxtLink, { to: "/neo" }, {
                          default: withCtx(() => [
                            createVNode(_component_Button, {
                              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                              rounded: ""
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="products__item"${_scopeId2}><div class="products__item-content"${_scopeId2}><h3 class="products__item-title"${_scopeId2}>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> <br${_scopeId2}>\u0433\u0435\u043B\u044C 2 %</h3><div class="products__item-img"${_scopeId2}><img${ssrRenderAttr("src", _imports_4)}${ssrRenderAttr("srcset", _imports_5 + " 2x")} alt="" loading="lazy"${_scopeId2}></div><p class="products__item-desc"${_scopeId2}>\u0421\u0430\u043C\u044B\u0439 \u043F\u0440\u043E\u0434\u0430\u0432\u0430\u0435\u043C\u044B\u0439 \u0433\u0435\u043B\u044C<sup${_scopeId2}>7</sup> \u043F\u0440\u043E\u0442\u0438\u0432 \u0442\u044F\u0436\u0435\u0441\u0442\u0438 \u0438 \u0431\u043E\u043B\u0438 \u0432 \u043D\u043E\u0433\u0430\u0445 \u043F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435<sup${_scopeId2}>**,8</sup></p></div><div class="products__item-btn"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_NuxtLink, { to: "/gel" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "products__item" }, [
                      createVNode("div", { class: "products__item-content" }, [
                        createVNode("h3", { class: "products__item-title" }, [
                          createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                          createVNode("sup", null, "\xAE"),
                          createTextVNode(),
                          createVNode("br"),
                          createTextVNode("\u0433\u0435\u043B\u044C 2 %")
                        ]),
                        createVNode("div", { class: "products__item-img" }, [
                          createVNode("img", {
                            src: _imports_4,
                            srcset: _imports_5 + " 2x",
                            alt: "",
                            loading: "lazy"
                          })
                        ]),
                        createVNode("p", { class: "products__item-desc" }, [
                          createTextVNode("\u0421\u0430\u043C\u044B\u0439 \u043F\u0440\u043E\u0434\u0430\u0432\u0430\u0435\u043C\u044B\u0439 \u0433\u0435\u043B\u044C"),
                          createVNode("sup", null, "7"),
                          createTextVNode(" \u043F\u0440\u043E\u0442\u0438\u0432 \u0442\u044F\u0436\u0435\u0441\u0442\u0438 \u0438 \u0431\u043E\u043B\u0438 \u0432 \u043D\u043E\u0433\u0430\u0445 \u043F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435"),
                          createVNode("sup", null, "**,8")
                        ])
                      ]),
                      createVNode("div", { class: "products__item-btn" }, [
                        createVNode(_component_NuxtLink, { to: "/gel" }, {
                          default: withCtx(() => [
                            createVNode(_component_Button, {
                              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                              rounded: ""
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="products__item"${_scopeId2}><div class="products__item-content"${_scopeId2}><h3 class="products__item-title"${_scopeId2}>\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 <br${_scopeId2}>\u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438</h3><div class="products__item-img"${_scopeId2}><img${ssrRenderAttr("src", _imports_6)}${ssrRenderAttr("srcset", _imports_7 + " 2x")} alt="" loading="lazy"${_scopeId2}></div><p class="products__item-desc"${_scopeId2}>\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0442 \u043D\u0430 \u0432\u0435\u043D\u044B \u0438\u0437\u043D\u0443\u0442\u0440\u0438<sup${_scopeId2}>9</sup> \u043F\u0440\u0438 \u0425\u0412\u041D<sup${_scopeId2}>*</sup>. \u0421\u0430\u043C\u0430\u044F \u0432\u043E\u0441\u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u043D\u0430\u044F<sup${_scopeId2}>10</sup> \u0444\u043E\u0440\u043C\u0443\u043B\u0430 (\u041C\u041D\u041D) \u0432 \u043B\u0435\u0447\u0435\u043D\u0438\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430<sup${_scopeId2}>*</sup></p></div><div class="products__item-btn"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_NuxtLink, { to: "/troxactive" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "products__item" }, [
                      createVNode("div", { class: "products__item-content" }, [
                        createVNode("h3", { class: "products__item-title" }, [
                          createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 "),
                          createVNode("br"),
                          createTextVNode("\u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438")
                        ]),
                        createVNode("div", { class: "products__item-img" }, [
                          createVNode("img", {
                            src: _imports_6,
                            srcset: _imports_7 + " 2x",
                            alt: "",
                            loading: "lazy"
                          })
                        ]),
                        createVNode("p", { class: "products__item-desc" }, [
                          createTextVNode("\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0442 \u043D\u0430 \u0432\u0435\u043D\u044B \u0438\u0437\u043D\u0443\u0442\u0440\u0438"),
                          createVNode("sup", null, "9"),
                          createTextVNode(" \u043F\u0440\u0438 \u0425\u0412\u041D"),
                          createVNode("sup", null, "*"),
                          createTextVNode(". \u0421\u0430\u043C\u0430\u044F \u0432\u043E\u0441\u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u043D\u0430\u044F"),
                          createVNode("sup", null, "10"),
                          createTextVNode(" \u0444\u043E\u0440\u043C\u0443\u043B\u0430 (\u041C\u041D\u041D) \u0432 \u043B\u0435\u0447\u0435\u043D\u0438\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430"),
                          createVNode("sup", null, "*")
                        ])
                      ]),
                      createVNode("div", { class: "products__item-btn" }, [
                        createVNode(_component_NuxtLink, { to: "/troxactive" }, {
                          default: withCtx(() => [
                            createVNode(_component_Button, {
                              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                              rounded: ""
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(SwiperSlide), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="products__item"${_scopeId2}><div class="products__item-content"${_scopeId2}><h3 class="products__item-title"${_scopeId2}>\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D<sup${_scopeId2}>\xAE</sup> <br${_scopeId2}>\u043A\u0430\u043F\u0441\u0443\u043B\u044B</h3><div class="products__item-img"${_scopeId2}><img${ssrRenderAttr("src", _imports_8)}${ssrRenderAttr("srcset", _imports_9 + " 2x")} alt="" loading="lazy"${_scopeId2}></div><p class="products__item-desc"${_scopeId2}>\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043E<sup${_scopeId2}>12</sup> \u043F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438\u0438 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435<sup${_scopeId2}>11</sup></p></div><div class="products__item-btn"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_NuxtLink, { to: "/capsules" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Button, {
                          label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                          rounded: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "products__item" }, [
                      createVNode("div", { class: "products__item-content" }, [
                        createVNode("h3", { class: "products__item-title" }, [
                          createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                          createVNode("sup", null, "\xAE"),
                          createTextVNode(),
                          createVNode("br"),
                          createTextVNode("\u043A\u0430\u043F\u0441\u0443\u043B\u044B")
                        ]),
                        createVNode("div", { class: "products__item-img" }, [
                          createVNode("img", {
                            src: _imports_8,
                            srcset: _imports_9 + " 2x",
                            alt: "",
                            loading: "lazy"
                          })
                        ]),
                        createVNode("p", { class: "products__item-desc" }, [
                          createTextVNode("\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043E"),
                          createVNode("sup", null, "12"),
                          createTextVNode(" \u043F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438\u0438 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435"),
                          createVNode("sup", null, "11")
                        ])
                      ]),
                      createVNode("div", { class: "products__item-btn" }, [
                        createVNode(_component_NuxtLink, { to: "/capsules" }, {
                          default: withCtx(() => [
                            createVNode(_component_Button, {
                              label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                              rounded: ""
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "products__item" }, [
                    createVNode("div", { class: "products__item-content" }, [
                      createVNode("h3", { class: "products__item-title" }, [
                        createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(),
                        createVNode("br"),
                        createTextVNode("\u041D\u0435\u043E \u0433\u0435\u043B\u044C ")
                      ]),
                      createVNode("div", { class: "products__item-img" }, [
                        createVNode("img", {
                          src: _imports_2,
                          srcset: _imports_3 + " 2x",
                          alt: "",
                          loading: "lazy"
                        })
                      ]),
                      createVNode("p", { class: "products__item-desc" }, [
                        createTextVNode("\u0423\u0441\u0438\u043B\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u0430"),
                        createVNode("sup", null, "5"),
                        createTextVNode(" \u0432 \u043B\u0438\u043D\u0435\u0439\u043A\u0435 \u0441 \u0442\u0440\u043E\u0439\u043D\u044B\u043C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435\u043C"),
                        createVNode("sup", null, "6")
                      ])
                    ]),
                    createVNode("div", { class: "products__item-btn" }, [
                      createVNode(_component_NuxtLink, { to: "/neo" }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "products__item" }, [
                    createVNode("div", { class: "products__item-content" }, [
                      createVNode("h3", { class: "products__item-title" }, [
                        createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(),
                        createVNode("br"),
                        createTextVNode("\u0433\u0435\u043B\u044C 2 %")
                      ]),
                      createVNode("div", { class: "products__item-img" }, [
                        createVNode("img", {
                          src: _imports_4,
                          srcset: _imports_5 + " 2x",
                          alt: "",
                          loading: "lazy"
                        })
                      ]),
                      createVNode("p", { class: "products__item-desc" }, [
                        createTextVNode("\u0421\u0430\u043C\u044B\u0439 \u043F\u0440\u043E\u0434\u0430\u0432\u0430\u0435\u043C\u044B\u0439 \u0433\u0435\u043B\u044C"),
                        createVNode("sup", null, "7"),
                        createTextVNode(" \u043F\u0440\u043E\u0442\u0438\u0432 \u0442\u044F\u0436\u0435\u0441\u0442\u0438 \u0438 \u0431\u043E\u043B\u0438 \u0432 \u043D\u043E\u0433\u0430\u0445 \u043F\u0440\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0435"),
                        createVNode("sup", null, "**,8")
                      ])
                    ]),
                    createVNode("div", { class: "products__item-btn" }, [
                      createVNode(_component_NuxtLink, { to: "/gel" }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "products__item" }, [
                    createVNode("div", { class: "products__item-content" }, [
                      createVNode("h3", { class: "products__item-title" }, [
                        createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 "),
                        createVNode("br"),
                        createTextVNode("\u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438")
                      ]),
                      createVNode("div", { class: "products__item-img" }, [
                        createVNode("img", {
                          src: _imports_6,
                          srcset: _imports_7 + " 2x",
                          alt: "",
                          loading: "lazy"
                        })
                      ]),
                      createVNode("p", { class: "products__item-desc" }, [
                        createTextVNode("\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0442 \u043D\u0430 \u0432\u0435\u043D\u044B \u0438\u0437\u043D\u0443\u0442\u0440\u0438"),
                        createVNode("sup", null, "9"),
                        createTextVNode(" \u043F\u0440\u0438 \u0425\u0412\u041D"),
                        createVNode("sup", null, "*"),
                        createTextVNode(". \u0421\u0430\u043C\u0430\u044F \u0432\u043E\u0441\u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u043D\u0430\u044F"),
                        createVNode("sup", null, "10"),
                        createTextVNode(" \u0444\u043E\u0440\u043C\u0443\u043B\u0430 (\u041C\u041D\u041D) \u0432 \u043B\u0435\u0447\u0435\u043D\u0438\u0438 \u0432\u0430\u0440\u0438\u043A\u043E\u0437\u0430"),
                        createVNode("sup", null, "*")
                      ])
                    ]),
                    createVNode("div", { class: "products__item-btn" }, [
                      createVNode(_component_NuxtLink, { to: "/troxactive" }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }),
              createVNode(unref(SwiperSlide), null, {
                default: withCtx(() => [
                  createVNode("div", { class: "products__item" }, [
                    createVNode("div", { class: "products__item-content" }, [
                      createVNode("h3", { class: "products__item-title" }, [
                        createTextVNode("\u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D"),
                        createVNode("sup", null, "\xAE"),
                        createTextVNode(),
                        createVNode("br"),
                        createTextVNode("\u043A\u0430\u043F\u0441\u0443\u043B\u044B")
                      ]),
                      createVNode("div", { class: "products__item-img" }, [
                        createVNode("img", {
                          src: _imports_8,
                          srcset: _imports_9 + " 2x",
                          alt: "",
                          loading: "lazy"
                        })
                      ]),
                      createVNode("p", { class: "products__item-desc" }, [
                        createTextVNode("\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043E"),
                        createVNode("sup", null, "12"),
                        createTextVNode(" \u043F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438\u0438 \u0433\u0435\u043C\u043E\u0440\u0440\u043E\u0435"),
                        createVNode("sup", null, "11")
                      ])
                    ]),
                    createVNode("div", { class: "products__item-btn" }, [
                      createVNode(_component_NuxtLink, { to: "/capsules" }, {
                        default: withCtx(() => [
                          createVNode(_component_Button, {
                            label: "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
                            rounded: ""
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></section><section class="sources"><div class="sources__wrapper container"><p>*\u0421\u0438\u043C\u043F\u0442\u043E\u043C\u043E\u0432 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043D\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438. **\u041F\u0440\u0438 \u0445\u0440\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0435\u043D\u043E\u0437\u043D\u043E\u0439 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E\u0441\u0442\u0438 <br>1. \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0432 \u0420\u043E\u0441\u0441\u0438\u0438 \u0441 1981 \u0433. \u0420\u0423 \u0411-8-242 \u21162654 <br>2. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438 \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0445 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u043E\u0432 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u041F N012713/02, \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u041B\u041F-\u2116 (000726)-(\u0420\u0413-RU), \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u043A\u0430\u043F\u0441\u0443\u043B\u044B \u041B\u041F-\u2116(000083)-(\u0420\u0413-RU), \u043B\u0438\u0441\u0442\u043E\u043A-\u0432\u043A\u043B\u0430\u0434\u044B\u0448 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u041D\u0435\u043E \u041B\u041F-\u2116-(001509)-\u0420\u0413-RU \u043E\u0442 05.12.2022 <br>3. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438 \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0445 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u043E\u0432 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u041B\u041F-\u2116 (000726)-(\u0420\u0413-RU), \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u043A\u0430\u043F\u0441\u0443\u043B\u044B \u041B\u041F-\u2116(000083)-(\u0420\u0413-RU) <br>4. \u0420\u043E\u0437\u043D\u0438\u0447\u043D\u044B\u0435 \u0446\u0435\u043D\u044B \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0433\u0435\u043B\u044C 2% 40\u0433 \u2013 360.4, \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u041D\u0435\u043E \u0433\u0435\u043B\u044C 40 \u0433 \u2013 500.2, \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 30\u0448\u0442 \u2013 1197.7, \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u043A\u0430\u043F\u0441\u0443\u043B\u044B 50\u0448\u0442 \u2013 782.7 (\u0410\u0419\u041A\u042C\u042E\u0412\u0418\u0410, \u0434\u0435\u043A\u0430\u0431\u0440\u044C 2022) <br>5. \u041F\u043E \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044E \u0441 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u0433\u0435\u043B\u044C 2% <br>6. \u0412\u0435\u043D\u043E\u0442\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u044E\u0449\u0435\u0435, \u043F\u0440\u043E\u0442\u0438\u0432\u043E\u0432\u043E\u0441\u043F\u0430\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435, \u043F\u0440\u043E\u0442\u0438\u0432\u043E\u043E\u0442\u0435\u0447\u043D\u043E\u0435. \u041B\u0438\u0441\u0442\u043E\u043A-\u0432\u043A\u043B\u0430\u0434\u044B\u0448 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u041D\u0435\u043E \u041B\u041F-\u2116(001509)-(\u0420\u0413-RU) https://portal.eaeunion.org/sites/commonprocesses/ru-ru/Pages/CardView.aspx?documentId=6206058bfb44f12d3bb0566b&amp;codeId=P.MM.01 <br>7. \u0412 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u043D\u0430\u0440\u0443\u0436\u043D\u044B\u0445 \u0432\u0435\u043D\u043E\u0442\u043E\u043D\u0438\u043A\u043E\u0432, \u043F\u043E \u043F\u0440\u043E\u0434\u0430\u0436\u0430\u043C \u0432 \u0434\u0435\u043D\u044C\u0433\u0430\u0445 2018-2022, \u0410\u0419\u041A\u042C\u042E\u0412\u0418\u0410 <br>8. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D \u041F N012713/02 <br>9. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0430 \u0422\u0440\u043E\u043A\u0441\u0430\u043A\u0442\u0438\u0432 \u041B\u041F-\u2116 (000726)-(\u0420\u0413-RU) <br>10. \u041C\u041E\u0424\u0424 \u0413\u0435\u0441\u043F\u0435\u0440\u0438\u0434\u0438\u043D-\u0414\u0438\u043E\u0441\u043C\u0438\u043D \u2013 \u044D\u0442\u043E \u043D\u0430\u0438\u0431\u043E\u043B\u0435\u0435 \u043F\u0440\u043E\u0434\u0430\u0432\u0430\u0435\u043C\u043E\u0435 \u041C\u041D\u041D \u0432 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u0432\u0435\u043D\u043E\u0442\u043E\u043D\u0438\u043A\u043E\u0432, \u043F\u0440\u043E\u0434\u0430\u0436\u0438 \u0432 \u0434\u0435\u043D\u044C\u0433\u0430\u0445 2018-2022, \u0410\u0419\u041A\u042C\u042E\u0412\u0418\u0410 <br>11. \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F \u043F\u043E \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044E \u043B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u0422\u0440\u043E\u043A\u0441\u0435\u0432\u0430\u0437\u0438\u043D\xAE \u043A\u0430\u043F\u0441\u0443\u043B\u044B \u041B\u041F-\u2116(000083)-(\u0420\u0413-RU) <br>12. \u0421 2008 \u0433. \u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u043E\u0435 \u0443\u0434\u043E\u0441\u0442\u043E\u0432\u0435\u0440\u0435\u043D\u0438\u0435 \u2116 \u041F N012713/01 \u043E\u0442 25.03.2008 </p></div></section></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-98feecfd.mjs.map
