globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import 'node-fetch-native/polyfill';
import { Server as Server$1 } from 'node:http';
import { Server } from 'node:https';
import destr from 'destr';
import { defineEventHandler, handleCacheHeaders, createEvent, eventHandler, setHeaders, sendRedirect, proxyRequest, getRequestHeader, getRequestHeaders, setResponseHeader, createError, createApp, createRouter as createRouter$1, toNodeListener, fetchWithEvent, lazyEventHandler } from 'h3';
import { createFetch as createFetch$1, Headers } from 'ofetch';
import { createCall, createFetch } from 'unenv/runtime/fetch/index';
import { createHooks } from 'hookable';
import { snakeCase } from 'scule';
import defu, { defuFn } from 'defu';
import { hash } from 'ohash';
import { parseURL, withoutBase, joinURL, withQuery, withLeadingSlash, withoutTrailingSlash } from 'ufo';
import { createStorage, prefixStorage } from 'unstorage';
import { toRouteMatcher, createRouter } from 'radix3';
import { promises } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'pathe';

const inlineAppConfig = {};



const appConfig = defuFn(inlineAppConfig);

const _runtimeConfig = {"app":{"baseURL":"/","buildAssetsDir":"/_nuxt/","cdnURL":""},"nitro":{"envPrefix":"NUXT_","routeRules":{"/__nuxt_error":{"cache":false},"/_nuxt/**":{"headers":{"cache-control":"public, max-age=31536000, immutable"}}}},"public":{}};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _runtimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
overrideConfig(_runtimeConfig);
const runtimeConfig = deepFreeze(_runtimeConfig);
const useRuntimeConfig = () => runtimeConfig;
deepFreeze(appConfig);
function getEnv(key) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]
  );
}
function isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function overrideConfig(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey);
    if (isObject(obj[key])) {
      if (isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      overrideConfig(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
}
function deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      deepFreeze(value);
    }
  }
  return Object.freeze(object);
}

const _assets = {

};

function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

const storage = createStorage({});

storage.mount('/assets', assets$1);

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  const validate = opts.validate || (() => true);
  async function get(key, resolver, shouldInvalidateCache) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || !validate(entry);
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry)) {
          useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = opts.shouldInvalidateCache?.(...args);
    const entry = await get(key, () => fn(...args), shouldInvalidateCache);
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return key.replace(/[^\dA-Za-z]/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const key = await opts.getKey?.(event);
      if (key) {
        return escapeKey(key);
      }
      const url = event.node.req.originalUrl || event.node.req.url;
      const friendlyName = escapeKey(decodeURI(parseURL(url).pathname)).slice(
        0,
        16
      );
      const urlHash = hash(url);
      return `${friendlyName}.${urlHash}`;
    },
    validate: (entry) => {
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: [opts.integrity, handler]
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const reqProxy = cloneWithProxy(incomingEvent.node.req, { headers: {} });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            for (const header in headers2) {
              this.setHeader(header, headers2[header]);
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.context = incomingEvent.context;
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = headers.Etag || headers.etag || `W/"${hash(body)}"`;
      headers["last-modified"] = headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString();
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      event.node.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler() {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      return sendRedirect(
        event,
        routeRules.redirect.to,
        routeRules.redirect.statusCode
      );
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      }
      return proxyRequest(event, target, {
        fetch: $fetch.raw,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    const path = new URL(event.node.req.url, "http://localhost").pathname;
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(path, useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

const plugins = [
  
];

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error) {
  const cwd = typeof process.cwd === "function" ? process.cwd() : "/";
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.node.req.url,
    statusCode,
    statusMessage,
    message,
    stack: "",
    data: error.data
  };
  event.node.res.statusCode = errorObject.statusCode !== 200 && errorObject.statusCode || 500;
  if (errorObject.statusMessage) {
    event.node.res.statusMessage = errorObject.statusMessage;
  }
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (isJsonRequest(event)) {
    event.node.res.setHeader("Content-Type", "application/json");
    event.node.res.end(JSON.stringify(errorObject));
    return;
  }
  const isErrorPage = event.node.req.url?.startsWith("/__nuxt_error");
  const res = !isErrorPage ? await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject), {
    headers: getRequestHeaders(event),
    redirect: "manual"
  }).catch(() => null) : null;
  if (!res) {
    const { template } = await import('../error-500.mjs');
    event.node.res.setHeader("Content-Type", "text/html;charset=UTF-8");
    event.node.res.end(template(errorObject));
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  if (res.status && res.status !== 200) {
    event.node.res.statusCode = res.status;
  }
  if (res.statusText) {
    event.node.res.statusMessage = res.statusText;
  }
  event.node.res.end(await res.text());
});

const assets = {
  "/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1804-FynbcrPsdS2AG2pB34nNKvcLcJw\"",
    "mtime": "2023-05-05T22:08:37.832Z",
    "size": 6148,
    "path": "../public/.DS_Store"
  },
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"3aee-Acb/iz2w1ApgrZ+hLF7akurGhyU\"",
    "mtime": "2023-05-05T22:08:37.830Z",
    "size": 15086,
    "path": "../public/favicon.ico"
  },
  "/_nuxt/capsules.4345bb17.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4879-XtfvmVuLkY8/iwv46ecqC9DXBII\"",
    "mtime": "2023-05-05T22:08:36.851Z",
    "size": 18553,
    "path": "../public/_nuxt/capsules.4345bb17.css"
  },
  "/_nuxt/capsules.a77b2226.js": {
    "type": "application/javascript",
    "etag": "\"8c38-OFoZt5ntloNHS0OdwtUaXmbaxDU\"",
    "mtime": "2023-05-05T22:08:36.850Z",
    "size": 35896,
    "path": "../public/_nuxt/capsules.a77b2226.js"
  },
  "/_nuxt/case-hemorrhoids.5f9d965e.js": {
    "type": "application/javascript",
    "etag": "\"39c1-nH9CqqAXopMEE/yBcsSag35ctkc\"",
    "mtime": "2023-05-05T22:08:36.850Z",
    "size": 14785,
    "path": "../public/_nuxt/case-hemorrhoids.5f9d965e.js"
  },
  "/_nuxt/case-hemorrhoids.c49e69b7.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3a5e-ZcGsfIcIejjQg7z9JJtzLI1uxNU\"",
    "mtime": "2023-05-05T22:08:36.849Z",
    "size": 14942,
    "path": "../public/_nuxt/case-hemorrhoids.c49e69b7.css"
  },
  "/_nuxt/case-varikoz-hard.4d670b72.js": {
    "type": "application/javascript",
    "etag": "\"2b8a-9/HDW3ERCdrP+l8SF1UdFiRFRwc\"",
    "mtime": "2023-05-05T22:08:36.848Z",
    "size": 11146,
    "path": "../public/_nuxt/case-varikoz-hard.4d670b72.js"
  },
  "/_nuxt/case-varikoz-lite.c67f7879.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2d12-i+O2xEByynitGtmPdhpMtRtrk6U\"",
    "mtime": "2023-05-05T22:08:36.846Z",
    "size": 11538,
    "path": "../public/_nuxt/case-varikoz-lite.c67f7879.css"
  },
  "/_nuxt/case-varikoz-lite.db7e7c7c.js": {
    "type": "application/javascript",
    "etag": "\"2d83-8nwirL5sA4jH2ThKhHWvz8sZbT8\"",
    "mtime": "2023-05-05T22:08:36.845Z",
    "size": 11651,
    "path": "../public/_nuxt/case-varikoz-lite.db7e7c7c.js"
  },
  "/_nuxt/case-varikoz-middle.7fcff6ba.js": {
    "type": "application/javascript",
    "etag": "\"2c9a-y2+oPXwOUy6bik/t04jBT/zTAyc\"",
    "mtime": "2023-05-05T22:08:36.844Z",
    "size": 11418,
    "path": "../public/_nuxt/case-varikoz-middle.7fcff6ba.js"
  },
  "/_nuxt/doc.d07aeab5.js": {
    "type": "application/javascript",
    "etag": "\"2a7-AiE/L49RDv+EyYiYlZ81PgbfODc\"",
    "mtime": "2023-05-05T22:08:36.837Z",
    "size": 679,
    "path": "../public/_nuxt/doc.d07aeab5.js"
  },
  "/_nuxt/effect-fade.96acdb02.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1dc-ZCxXeMDfbxg2s00YyFK3W7zimAw\"",
    "mtime": "2023-05-05T22:08:36.836Z",
    "size": 476,
    "path": "../public/_nuxt/effect-fade.96acdb02.css"
  },
  "/_nuxt/effect-fade.min.89effc40.js": {
    "type": "application/javascript",
    "etag": "\"29c4-MAmLWgRfT1Ckrn873e3WmBEdNlE\"",
    "mtime": "2023-05-05T22:08:36.835Z",
    "size": 10692,
    "path": "../public/_nuxt/effect-fade.min.89effc40.js"
  },
  "/_nuxt/entry.3755f3a2.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"8897-JRNmAZ6c16GFzvQoMc0ZPT/H3B4\"",
    "mtime": "2023-05-05T22:08:36.835Z",
    "size": 34967,
    "path": "../public/_nuxt/entry.3755f3a2.css"
  },
  "/_nuxt/entry.430943a1.js": {
    "type": "application/javascript",
    "etag": "\"3aa61-7Ev8M4jDsve7x31D7i39qlOui20\"",
    "mtime": "2023-05-05T22:08:36.833Z",
    "size": 240225,
    "path": "../public/_nuxt/entry.430943a1.js"
  },
  "/_nuxt/error-404.1bcd0476.js": {
    "type": "application/javascript",
    "etag": "\"8a8-gaf9gz3fEJ2N2jaRmtzeXPVl0yE\"",
    "mtime": "2023-05-05T22:08:36.832Z",
    "size": 2216,
    "path": "../public/_nuxt/error-404.1bcd0476.js"
  },
  "/_nuxt/error-404.627b132b.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"12dc-BwB86T4w4G2MAg7F3iA27xmLoic\"",
    "mtime": "2023-05-05T22:08:36.830Z",
    "size": 4828,
    "path": "../public/_nuxt/error-404.627b132b.css"
  },
  "/_nuxt/error-500.02d991ef.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"811-c2vGD6f+ShO21YJF2crZpDd4o/k\"",
    "mtime": "2023-05-05T22:08:36.830Z",
    "size": 2065,
    "path": "../public/_nuxt/error-500.02d991ef.css"
  },
  "/_nuxt/error-500.6c6c4c3a.js": {
    "type": "application/javascript",
    "etag": "\"74c-mUFS6b1YHtnjR/B1dmx3mGTvJMI\"",
    "mtime": "2023-05-05T22:08:36.829Z",
    "size": 1868,
    "path": "../public/_nuxt/error-500.6c6c4c3a.js"
  },
  "/_nuxt/error-component.6b4b81d2.js": {
    "type": "application/javascript",
    "etag": "\"45e-wKS7EQjAHeBxgIu12i2/qjY2AgU\"",
    "mtime": "2023-05-05T22:08:36.828Z",
    "size": 1118,
    "path": "../public/_nuxt/error-component.6b4b81d2.js"
  },
  "/_nuxt/gel.32b551fd.js": {
    "type": "application/javascript",
    "etag": "\"7602-8CWPlcEk1s5kgGGGvWMq+ToSO7A\"",
    "mtime": "2023-05-05T22:08:36.828Z",
    "size": 30210,
    "path": "../public/_nuxt/gel.32b551fd.js"
  },
  "/_nuxt/header-1_2x.a816f54a.js": {
    "type": "application/javascript",
    "etag": "\"ae-l5XzYpa7OaSYlSLlQt8ZVNcrmTI\"",
    "mtime": "2023-05-05T22:08:36.827Z",
    "size": 174,
    "path": "../public/_nuxt/header-1_2x.a816f54a.js"
  },
  "/_nuxt/index.4b82367b.js": {
    "type": "application/javascript",
    "etag": "\"2d89-Aql+Kl+R2vCn5SJifMleR61jQX8\"",
    "mtime": "2023-05-05T22:08:36.827Z",
    "size": 11657,
    "path": "../public/_nuxt/index.4b82367b.js"
  },
  "/_nuxt/index.78f6b5aa.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1554-MqK+eaGctiChFTh0H6pnFGt/Tc0\"",
    "mtime": "2023-05-05T22:08:36.826Z",
    "size": 5460,
    "path": "../public/_nuxt/index.78f6b5aa.css"
  },
  "/_nuxt/maternity.af60a341.js": {
    "type": "application/javascript",
    "etag": "\"fd-kDiq8vM0f0X6aJPyep/wxXi/IwI\"",
    "mtime": "2023-05-05T22:08:36.825Z",
    "size": 253,
    "path": "../public/_nuxt/maternity.af60a341.js"
  },
  "/_nuxt/neo.d661dac5.js": {
    "type": "application/javascript",
    "etag": "\"8390-unEKK+fa9RbunqeVHodHe3RcqF8\"",
    "mtime": "2023-05-05T22:08:36.825Z",
    "size": 33680,
    "path": "../public/_nuxt/neo.d661dac5.js"
  },
  "/_nuxt/other-gel-neo.8b91ea1e.js": {
    "type": "application/javascript",
    "etag": "\"75-4H7TsmsVKT5tjlMAgSpRPfM3Ksw\"",
    "mtime": "2023-05-05T22:08:36.824Z",
    "size": 117,
    "path": "../public/_nuxt/other-gel-neo.8b91ea1e.js"
  },
  "/_nuxt/other-gel.39e02974.js": {
    "type": "application/javascript",
    "etag": "\"71-Y0U1YjnffE+v2XaTOASuorF+1To\"",
    "mtime": "2023-05-05T22:08:36.824Z",
    "size": 113,
    "path": "../public/_nuxt/other-gel.39e02974.js"
  },
  "/_nuxt/other-troxactive.21f4120f.js": {
    "type": "application/javascript",
    "etag": "\"78-QIduSSKSEOJxAV2Bc4ZgA1oj+sI\"",
    "mtime": "2023-05-05T22:08:36.823Z",
    "size": 120,
    "path": "../public/_nuxt/other-troxactive.21f4120f.js"
  },
  "/_nuxt/step-4.f807f21d.js": {
    "type": "application/javascript",
    "etag": "\"1c4-RudztASf1bmpNrZ2doryN58XF3I\"",
    "mtime": "2023-05-05T22:08:36.821Z",
    "size": 452,
    "path": "../public/_nuxt/step-4.f807f21d.js"
  },
  "/_nuxt/symptom-3_2x.964e754c.js": {
    "type": "application/javascript",
    "etag": "\"bb-2dRjkEx7YoZqwRDox0/oA2XtaKk\"",
    "mtime": "2023-05-05T22:08:36.819Z",
    "size": 187,
    "path": "../public/_nuxt/symptom-3_2x.964e754c.js"
  },
  "/_nuxt/symptom-6_2x.444a7ca9.js": {
    "type": "application/javascript",
    "etag": "\"bb-qvkMRUqq7jCLF0wCbN/nmOQwzfI\"",
    "mtime": "2023-05-05T22:08:36.814Z",
    "size": 187,
    "path": "../public/_nuxt/symptom-6_2x.444a7ca9.js"
  },
  "/_nuxt/symptom-8_2x.ff637d88.js": {
    "type": "application/javascript",
    "etag": "\"bb-YpR/GEDrdRgy1BAggo2WbdYp/7U\"",
    "mtime": "2023-05-05T22:08:36.813Z",
    "size": 187,
    "path": "../public/_nuxt/symptom-8_2x.ff637d88.js"
  },
  "/_nuxt/symptom-case-3_2x.97e20884.js": {
    "type": "application/javascript",
    "etag": "\"13c4-GMuGO5STD0ZvAtCgnBd8Uh2Aqdw\"",
    "mtime": "2023-05-05T22:08:36.812Z",
    "size": 5060,
    "path": "../public/_nuxt/symptom-case-3_2x.97e20884.js"
  },
  "/_nuxt/symptom-case-3_2x.ea65c6d9.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"b9d-WSo7Mo6AiZSyMAwvtR3VLPyX/Dc\"",
    "mtime": "2023-05-05T22:08:36.808Z",
    "size": 2973,
    "path": "../public/_nuxt/symptom-case-3_2x.ea65c6d9.css"
  },
  "/_nuxt/troxactive.843c6c39.js": {
    "type": "application/javascript",
    "etag": "\"8f8d-Y9ZNI5YQ3mxSgSZFTuuzzLpmzT4\"",
    "mtime": "2023-05-05T22:08:36.807Z",
    "size": 36749,
    "path": "../public/_nuxt/troxactive.843c6c39.js"
  },
  "/_nuxt/troxactive.dbc8c02b.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"533e-NzRRCpV2jB1AkalAcMNSO7y1iUM\"",
    "mtime": "2023-05-05T22:08:36.805Z",
    "size": 21310,
    "path": "../public/_nuxt/troxactive.dbc8c02b.css"
  },
  "/img/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1804-7HXK7LZ0+KVHBtLm+xf9SWX85Cs\"",
    "mtime": "2023-05-05T22:08:37.829Z",
    "size": 6148,
    "path": "../public/img/.DS_Store"
  },
  "/img/hexagon-arrow.svg": {
    "type": "image/svg+xml",
    "etag": "\"18c-7YUxRvDVIaEo8qGVSWuHXJBArpM\"",
    "mtime": "2023-05-05T22:08:37.737Z",
    "size": 396,
    "path": "../public/img/hexagon-arrow.svg"
  },
  "/img/hexagon-arrow_mob.svg": {
    "type": "image/svg+xml",
    "etag": "\"c2-mJNk0ntcbOPNp5zB8dIvkA7/IHI\"",
    "mtime": "2023-05-05T22:08:37.736Z",
    "size": 194,
    "path": "../public/img/hexagon-arrow_mob.svg"
  },
  "/img/ico.svg": {
    "type": "image/svg+xml",
    "etag": "\"1d5a-qbQGDYlmyAnaCf+0RlrKGLLmrg8\"",
    "mtime": "2023-05-05T22:08:37.735Z",
    "size": 7514,
    "path": "../public/img/ico.svg"
  },
  "/img/ico_fon.png": {
    "type": "image/png",
    "etag": "\"2362-9WPMlC6DM5DlqmFi4/KHyxp/clc\"",
    "mtime": "2023-05-05T22:08:37.735Z",
    "size": 9058,
    "path": "../public/img/ico_fon.png"
  },
  "/img/logo.svg": {
    "type": "image/svg+xml",
    "etag": "\"1207-NU20B1/rwaGNO8gMNDlqx0UxD2U\"",
    "mtime": "2023-05-05T22:08:37.734Z",
    "size": 4615,
    "path": "../public/img/logo.svg"
  },
  "/img/main_fon-mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"934a-TFwbpwJGnfrQ8Byrk/VSXlO81V0\"",
    "mtime": "2023-05-05T22:08:37.733Z",
    "size": 37706,
    "path": "../public/img/main_fon-mobile.jpg"
  },
  "/img/main_fon-mobile.webp": {
    "type": "image/webp",
    "etag": "\"174de-mC7IeRjFiAF6wo2P9rp7SesFWaw\"",
    "mtime": "2023-05-05T22:08:37.731Z",
    "size": 95454,
    "path": "../public/img/main_fon-mobile.webp"
  },
  "/img/main_fon.png": {
    "type": "image/png",
    "etag": "\"1cdf7-IDEn2zZgTukbkSc3vNIlT1GuM20\"",
    "mtime": "2023-05-05T22:08:37.730Z",
    "size": 118263,
    "path": "../public/img/main_fon.png"
  },
  "/img/main_fon.webp": {
    "type": "image/webp",
    "etag": "\"cf76-asrjUpNS6qPDY9mP+suNEDsnG6I\"",
    "mtime": "2023-05-05T22:08:37.727Z",
    "size": 53110,
    "path": "../public/img/main_fon.webp"
  },
  "/img/main_fon_case.png": {
    "type": "image/png",
    "etag": "\"b43a-vSoIJ0oBWz4p8b8E/HbUSc39bQ4\"",
    "mtime": "2023-05-05T22:08:37.726Z",
    "size": 46138,
    "path": "../public/img/main_fon_case.png"
  },
  "/img/product-1.png": {
    "type": "image/png",
    "etag": "\"434c-ULbdsQioXaP53OxaIoSbPDxSeGU\"",
    "mtime": "2023-05-05T22:08:36.903Z",
    "size": 17228,
    "path": "../public/img/product-1.png"
  },
  "/img/product-1@2x.png": {
    "type": "image/png",
    "etag": "\"df60-ZNzy2jr/H4TY/9xCMy5Jik0vZDA\"",
    "mtime": "2023-05-05T22:08:36.902Z",
    "size": 57184,
    "path": "../public/img/product-1@2x.png"
  },
  "/img/product-2.png": {
    "type": "image/png",
    "etag": "\"3fd2-sx+uwYtanc/97KKOvsb3xNwFwVY\"",
    "mtime": "2023-05-05T22:08:36.900Z",
    "size": 16338,
    "path": "../public/img/product-2.png"
  },
  "/img/product-2@2x.png": {
    "type": "image/png",
    "etag": "\"d18a-5oOkwH55HbrzhpcSUt0oLnnWPLk\"",
    "mtime": "2023-05-05T22:08:36.898Z",
    "size": 53642,
    "path": "../public/img/product-2@2x.png"
  },
  "/img/product-3.png": {
    "type": "image/png",
    "etag": "\"4964-ASUfDN3VdsrHJoRb9rrsK4v00U0\"",
    "mtime": "2023-05-05T22:08:36.894Z",
    "size": 18788,
    "path": "../public/img/product-3.png"
  },
  "/img/product-3@2x.png": {
    "type": "image/png",
    "etag": "\"ee50-BLqfvcdP9nnq4EODrYxnNgdXkWM\"",
    "mtime": "2023-05-05T22:08:36.893Z",
    "size": 61008,
    "path": "../public/img/product-3@2x.png"
  },
  "/img/product-4.png": {
    "type": "image/png",
    "etag": "\"4994-ne1309jOI0nFknqBugq34zLqYzY\"",
    "mtime": "2023-05-05T22:08:36.892Z",
    "size": 18836,
    "path": "../public/img/product-4.png"
  },
  "/img/product-4@2x.png": {
    "type": "image/png",
    "etag": "\"ff3f-UDVBVLgzuxZ6Oz8Y7urAc3tF2fs\"",
    "mtime": "2023-05-05T22:08:36.890Z",
    "size": 65343,
    "path": "../public/img/product-4@2x.png"
  },
  "/img/swiper-nav.svg": {
    "type": "image/svg+xml",
    "etag": "\"b7-URjzjnyUNHwr1FmzfMwnKIbPx68\"",
    "mtime": "2023-05-05T22:08:36.888Z",
    "size": 183,
    "path": "../public/img/swiper-nav.svg"
  },
  "/img/teva.svg": {
    "type": "image/svg+xml",
    "etag": "\"10a5-YJYyS+BOPMTMi9rCpSLTHC17riE\"",
    "mtime": "2023-05-05T22:08:36.884Z",
    "size": 4261,
    "path": "../public/img/teva.svg"
  },
  "/img/uteka_fon.jpg": {
    "type": "image/jpeg",
    "etag": "\"1236d-lawJCPNnl8cuA4Eud6vMujX4qQY\"",
    "mtime": "2023-05-05T22:08:36.883Z",
    "size": 74605,
    "path": "../public/img/uteka_fon.jpg"
  },
  "/pdf/instruction_capsules.pdf": {
    "type": "application/pdf",
    "etag": "\"691ea-R5ThVZ1+oVZVy3G72q8BtPC9AtA\"",
    "mtime": "2023-05-05T22:08:36.879Z",
    "size": 430570,
    "path": "../public/pdf/instruction_capsules.pdf"
  },
  "/pdf/instruction_gel.pdf": {
    "type": "application/pdf",
    "etag": "\"654bc-0t4JbFqrw0hYdi5rPJ+Ucy3A3m4\"",
    "mtime": "2023-05-05T22:08:36.871Z",
    "size": 414908,
    "path": "../public/pdf/instruction_gel.pdf"
  },
  "/pdf/instruction_neo.pdf": {
    "type": "application/pdf",
    "etag": "\"38293-mb33E7pV7D8wIOIDDiNiCEubnn8\"",
    "mtime": "2023-05-05T22:08:36.866Z",
    "size": 230035,
    "path": "../public/pdf/instruction_neo.pdf"
  },
  "/pdf/instruction_troxactive.pdf": {
    "type": "application/pdf",
    "etag": "\"3f5b0-gsT80aO/Vgh+yci3CZpGslcNMwU\"",
    "mtime": "2023-05-05T22:08:36.863Z",
    "size": 259504,
    "path": "../public/pdf/instruction_troxactive.pdf"
  },
  "/img/apteks/36.png": {
    "type": "image/png",
    "etag": "\"d2f-coeXg9W3qGQDIWJEGZxX8AzRNCg\"",
    "mtime": "2023-05-05T22:08:37.827Z",
    "size": 3375,
    "path": "../public/img/apteks/36.png"
  },
  "/img/apteks/aptekaru.png": {
    "type": "image/png",
    "etag": "\"85b-Q+Ssa105JiPskAaa+nXcyXAR5YE\"",
    "mtime": "2023-05-05T22:08:37.826Z",
    "size": 2139,
    "path": "../public/img/apteks/aptekaru.png"
  },
  "/img/apteks/eapteka.png": {
    "type": "image/png",
    "etag": "\"691-Xf7SvpXidOXDHuFAQSxn6o+ubPs\"",
    "mtime": "2023-05-05T22:08:37.825Z",
    "size": 1681,
    "path": "../public/img/apteks/eapteka.png"
  },
  "/img/apteks/gorzdrav.png": {
    "type": "image/png",
    "etag": "\"9af-NyY60CDZC8dCL7Yh462B+6InSAQ\"",
    "mtime": "2023-05-05T22:08:37.825Z",
    "size": 2479,
    "path": "../public/img/apteks/gorzdrav.png"
  },
  "/img/apteks/ozerki.png": {
    "type": "image/png",
    "etag": "\"1127-pCOHMeXJ4i29ywf7LXiDks4mvy0\"",
    "mtime": "2023-05-05T22:08:37.824Z",
    "size": 4391,
    "path": "../public/img/apteks/ozerki.png"
  },
  "/img/apteks/planet.png": {
    "type": "image/png",
    "etag": "\"cbd-qP/2U975xAB8WWf9L2ZqFf0GYSE\"",
    "mtime": "2023-05-05T22:08:37.823Z",
    "size": 3261,
    "path": "../public/img/apteks/planet.png"
  },
  "/img/apteks/rigla.png": {
    "type": "image/png",
    "etag": "\"ea6-6tAe4M+4b8LX0n+sxpUSuejBup0\"",
    "mtime": "2023-05-05T22:08:37.822Z",
    "size": 3750,
    "path": "../public/img/apteks/rigla.png"
  },
  "/img/apteks/stoletov.png": {
    "type": "image/png",
    "etag": "\"e6e-GJt3uY8W1u3pN1GEpM8dVhTGs+I\"",
    "mtime": "2023-05-05T22:08:37.821Z",
    "size": 3694,
    "path": "../public/img/apteks/stoletov.png"
  },
  "/img/apteks/superapteka.png": {
    "type": "image/png",
    "etag": "\"e1f-iC+zQ4KFI0zOC4VNwh7NEBbo620\"",
    "mtime": "2023-05-05T22:08:37.821Z",
    "size": 3615,
    "path": "../public/img/apteks/superapteka.png"
  },
  "/img/apteks/zdravsiti.png": {
    "type": "image/png",
    "etag": "\"866-yioW2f+wzfIgQYb1VQo2oxW2aKQ\"",
    "mtime": "2023-05-05T22:08:37.820Z",
    "size": 2150,
    "path": "../public/img/apteks/zdravsiti.png"
  },
  "/img/case/doc.png": {
    "type": "image/png",
    "etag": "\"2313-Cjk8vvFSDjLwqBE+zSPwg5yMhZg\"",
    "mtime": "2023-05-05T22:08:37.817Z",
    "size": 8979,
    "path": "../public/img/case/doc.png"
  },
  "/img/case/factor-1.png": {
    "type": "image/png",
    "etag": "\"967f-6PfPVmlAb4OZaLd+/a2NnI6vbWY\"",
    "mtime": "2023-05-05T22:08:37.813Z",
    "size": 38527,
    "path": "../public/img/case/factor-1.png"
  },
  "/img/case/factor-2.png": {
    "type": "image/png",
    "etag": "\"ae5b-1E69wm7kDVN886Cb9qt9CsO6bzM\"",
    "mtime": "2023-05-05T22:08:37.811Z",
    "size": 44635,
    "path": "../public/img/case/factor-2.png"
  },
  "/img/case/factor-3.png": {
    "type": "image/png",
    "etag": "\"97b8-cSmfeHhFB3clME4XEEj9/4oYSsI\"",
    "mtime": "2023-05-05T22:08:37.810Z",
    "size": 38840,
    "path": "../public/img/case/factor-3.png"
  },
  "/img/case/factor-4.png": {
    "type": "image/png",
    "etag": "\"28411-Wc9PfzWbfKIfVkFxdNS0pX4omE4\"",
    "mtime": "2023-05-05T22:08:37.809Z",
    "size": 164881,
    "path": "../public/img/case/factor-4.png"
  },
  "/img/case/factor-5.png": {
    "type": "image/png",
    "etag": "\"8c9e-0gG/4DQQWTa9T4ebBCSQaE2H8vI\"",
    "mtime": "2023-05-05T22:08:37.806Z",
    "size": 35998,
    "path": "../public/img/case/factor-5.png"
  },
  "/img/case/factor-6.png": {
    "type": "image/png",
    "etag": "\"a3b1-yIQhmVO7jOZEh0bAJJZQIRLuDCo\"",
    "mtime": "2023-05-05T22:08:37.804Z",
    "size": 41905,
    "path": "../public/img/case/factor-6.png"
  },
  "/img/case/factor-7.png": {
    "type": "image/png",
    "etag": "\"1dd6-Lhiw2qBZNbmPmIAUU4sgcxr+8N8\"",
    "mtime": "2023-05-05T22:08:37.802Z",
    "size": 7638,
    "path": "../public/img/case/factor-7.png"
  },
  "/img/case/factor-8.png": {
    "type": "image/png",
    "etag": "\"9821-cTztxDFufRBiLF/pE2yIZ7ZOkUY\"",
    "mtime": "2023-05-05T22:08:37.799Z",
    "size": 38945,
    "path": "../public/img/case/factor-8.png"
  },
  "/img/case/factor-9.png": {
    "type": "image/png",
    "etag": "\"c681-3dx9JyAbnKrmpryl/eHoz+cB/xw\"",
    "mtime": "2023-05-05T22:08:37.796Z",
    "size": 50817,
    "path": "../public/img/case/factor-9.png"
  },
  "/img/case/factors_fon.png": {
    "type": "image/png",
    "etag": "\"a3c6-ZnmlZfFXIyqfuFiUUNoTGUlhwo4\"",
    "mtime": "2023-05-05T22:08:37.794Z",
    "size": 41926,
    "path": "../public/img/case/factors_fon.png"
  },
  "/img/case/h-list-1.png": {
    "type": "image/png",
    "etag": "\"b7c-fqszUwYTYAAQNP4I4GSe48+13N0\"",
    "mtime": "2023-05-05T22:08:37.792Z",
    "size": 2940,
    "path": "../public/img/case/h-list-1.png"
  },
  "/img/case/h-list-1@2x.png": {
    "type": "image/png",
    "etag": "\"17dd-xyTg85Ou00jtAZsyXQJZizPHq/M\"",
    "mtime": "2023-05-05T22:08:37.791Z",
    "size": 6109,
    "path": "../public/img/case/h-list-1@2x.png"
  },
  "/img/case/h-list-2.png": {
    "type": "image/png",
    "etag": "\"c55-qtRctIUquOLbXIdygYayW/Nk1wc\"",
    "mtime": "2023-05-05T22:08:37.791Z",
    "size": 3157,
    "path": "../public/img/case/h-list-2.png"
  },
  "/img/case/h-list-2@2x.png": {
    "type": "image/png",
    "etag": "\"1d15-8JytyKW+DhwiLd/AG+4k79QqcUA\"",
    "mtime": "2023-05-05T22:08:37.790Z",
    "size": 7445,
    "path": "../public/img/case/h-list-2@2x.png"
  },
  "/img/case/h-list-3.png": {
    "type": "image/png",
    "etag": "\"c3b-dnlHYlux0ykxTuQ+LK5XivQlF24\"",
    "mtime": "2023-05-05T22:08:37.789Z",
    "size": 3131,
    "path": "../public/img/case/h-list-3.png"
  },
  "/img/case/h-list-3@2x.png": {
    "type": "image/png",
    "etag": "\"1d8b-1gPQTiKCOnG4GmFQ7AZso2atvZs\"",
    "mtime": "2023-05-05T22:08:37.788Z",
    "size": 7563,
    "path": "../public/img/case/h-list-3@2x.png"
  },
  "/img/case/header-1.png": {
    "type": "image/png",
    "etag": "\"167d0-VbDqfz1EC3Nr3ay4xew1Xq1ku94\"",
    "mtime": "2023-05-05T22:08:37.787Z",
    "size": 92112,
    "path": "../public/img/case/header-1.png"
  },
  "/img/case/header-1@2x.png": {
    "type": "image/png",
    "etag": "\"e6a91-kctbpRiLt/3uKHrKLbsHOi1LIa4\"",
    "mtime": "2023-05-05T22:08:37.785Z",
    "size": 944785,
    "path": "../public/img/case/header-1@2x.png"
  },
  "/img/case/header-1@2x.webp": {
    "type": "image/webp",
    "etag": "\"265ca-1nHc8v2WqxQiiWgkQkkSKQhnxm8\"",
    "mtime": "2023-05-05T22:08:37.776Z",
    "size": 157130,
    "path": "../public/img/case/header-1@2x.webp"
  },
  "/img/case/header-case.png": {
    "type": "image/png",
    "etag": "\"11b62-hqNptxXcPvaXeCqNwYA72AxufXE\"",
    "mtime": "2023-05-05T22:08:37.771Z",
    "size": 72546,
    "path": "../public/img/case/header-case.png"
  },
  "/img/case/header-case@2x.png": {
    "type": "image/png",
    "etag": "\"dee4a-ShrQatHJGP9ZIVbmFg28ExilSS0\"",
    "mtime": "2023-05-05T22:08:37.768Z",
    "size": 912970,
    "path": "../public/img/case/header-case@2x.png"
  },
  "/img/case/header-case@2x.webp": {
    "type": "image/webp",
    "etag": "\"23020-wj31Ennv49TThiXnTGyYMHWymBI\"",
    "mtime": "2023-05-05T22:08:37.763Z",
    "size": 143392,
    "path": "../public/img/case/header-case@2x.webp"
  },
  "/img/case/header-hemo.png": {
    "type": "image/png",
    "etag": "\"17496-IPMqaPRuThOF5KyQjYkRHbu3De8\"",
    "mtime": "2023-05-05T22:08:37.761Z",
    "size": 95382,
    "path": "../public/img/case/header-hemo.png"
  },
  "/img/case/header-hemo@2x.png": {
    "type": "image/png",
    "etag": "\"edc5a-L0Qnoc2AiDf8XnJj44JTfU7p+bc\"",
    "mtime": "2023-05-05T22:08:37.756Z",
    "size": 973914,
    "path": "../public/img/case/header-hemo@2x.png"
  },
  "/img/case/header-hemo@2x.webp": {
    "type": "image/webp",
    "etag": "\"26ff0-TNK1TuPhQeYqe3FsQP26RTbK/6Q\"",
    "mtime": "2023-05-05T22:08:37.751Z",
    "size": 159728,
    "path": "../public/img/case/header-hemo@2x.webp"
  },
  "/img/case/stats-hemo.png": {
    "type": "image/png",
    "etag": "\"4fc20-MGcGq/G2zgIkUhxXk4kXkkN9rzc\"",
    "mtime": "2023-05-05T22:08:37.749Z",
    "size": 326688,
    "path": "../public/img/case/stats-hemo.png"
  },
  "/img/case/stats.png": {
    "type": "image/png",
    "etag": "\"4f11b-rxTNHYiLayQaYZVcB0XyINJp/4E\"",
    "mtime": "2023-05-05T22:08:37.745Z",
    "size": 323867,
    "path": "../public/img/case/stats.png"
  },
  "/img/case/vozdey-hard.png": {
    "type": "image/png",
    "etag": "\"12cca-FuwJFDoOJ3MC86tVzMojcgUPQNY\"",
    "mtime": "2023-05-05T22:08:37.742Z",
    "size": 77002,
    "path": "../public/img/case/vozdey-hard.png"
  },
  "/img/case/vozdey.png": {
    "type": "image/png",
    "etag": "\"12b6a-wZGZoAFub1qjgLCpbRcyomICJng\"",
    "mtime": "2023-05-05T22:08:37.740Z",
    "size": 76650,
    "path": "../public/img/case/vozdey.png"
  },
  "/img/modal/c0.png": {
    "type": "image/png",
    "etag": "\"27f7-pN6WTxMeppQJNewIrgoZ4/REo7Y\"",
    "mtime": "2023-05-05T22:08:37.725Z",
    "size": 10231,
    "path": "../public/img/modal/c0.png"
  },
  "/img/modal/c0@2x.png": {
    "type": "image/png",
    "etag": "\"6d7d-RKPOzULsr0CA3Cf0FNauJGemsLE\"",
    "mtime": "2023-05-05T22:08:37.724Z",
    "size": 28029,
    "path": "../public/img/modal/c0@2x.png"
  },
  "/img/modal/c1.png": {
    "type": "image/png",
    "etag": "\"2bb8-TQ/1q/HYNzEYBphYo8/vKa2LPq0\"",
    "mtime": "2023-05-05T22:08:37.723Z",
    "size": 11192,
    "path": "../public/img/modal/c1.png"
  },
  "/img/modal/c1@2x.png": {
    "type": "image/png",
    "etag": "\"79b0-J3HCwgbXcHXHzlQZHvy8gqJCXiU\"",
    "mtime": "2023-05-05T22:08:37.722Z",
    "size": 31152,
    "path": "../public/img/modal/c1@2x.png"
  },
  "/img/modal/c2.png": {
    "type": "image/png",
    "etag": "\"2c6c-h3C/IDVCKAX4vepsZxRzAjZRbgA\"",
    "mtime": "2023-05-05T22:08:37.720Z",
    "size": 11372,
    "path": "../public/img/modal/c2.png"
  },
  "/img/modal/c2@2x.png": {
    "type": "image/png",
    "etag": "\"7ab9-h8YDCHy4PMvTraMHtfHbu/H2RWk\"",
    "mtime": "2023-05-05T22:08:37.719Z",
    "size": 31417,
    "path": "../public/img/modal/c2@2x.png"
  },
  "/img/modal/c3.png": {
    "type": "image/png",
    "etag": "\"28d3-69epMioGXpdMoK4ejtpUKZUvpDQ\"",
    "mtime": "2023-05-05T22:08:37.718Z",
    "size": 10451,
    "path": "../public/img/modal/c3.png"
  },
  "/img/modal/c3@2x.png": {
    "type": "image/png",
    "etag": "\"730b-VI4Hij7hJTyrpthJKiBOm3qpPNQ\"",
    "mtime": "2023-05-05T22:08:37.717Z",
    "size": 29451,
    "path": "../public/img/modal/c3@2x.png"
  },
  "/img/modal/c4.png": {
    "type": "image/png",
    "etag": "\"2fcf-/or2XNgnBPG6i752YOssAm9GjEs\"",
    "mtime": "2023-05-05T22:08:37.716Z",
    "size": 12239,
    "path": "../public/img/modal/c4.png"
  },
  "/img/modal/c4@2x.png": {
    "type": "image/png",
    "etag": "\"8788-+sBNC4tTZ3FMeysTxvbx32x2GR4\"",
    "mtime": "2023-05-05T22:08:37.715Z",
    "size": 34696,
    "path": "../public/img/modal/c4@2x.png"
  },
  "/img/modal/c5.png": {
    "type": "image/png",
    "etag": "\"2c0e-zW7dAQv34k88lUI/SDyydF4JcFI\"",
    "mtime": "2023-05-05T22:08:37.714Z",
    "size": 11278,
    "path": "../public/img/modal/c5.png"
  },
  "/img/modal/c5@2x.png": {
    "type": "image/png",
    "etag": "\"7a42-jSor/gXBs2dW6AiHjsq3NraEqn8\"",
    "mtime": "2023-05-05T22:08:37.713Z",
    "size": 31298,
    "path": "../public/img/modal/c5@2x.png"
  },
  "/img/modal/c6.png": {
    "type": "image/png",
    "etag": "\"2e7a-7u3UeMRaKvy6c0kKyDIX4CNBfSI\"",
    "mtime": "2023-05-05T22:08:37.711Z",
    "size": 11898,
    "path": "../public/img/modal/c6.png"
  },
  "/img/modal/c6@2x.png": {
    "type": "image/png",
    "etag": "\"842e-A/vTe9awR6hCPPjbJCEPJoJejEo\"",
    "mtime": "2023-05-05T22:08:37.710Z",
    "size": 33838,
    "path": "../public/img/modal/c6@2x.png"
  },
  "/img/modal/gem-1.png": {
    "type": "image/png",
    "etag": "\"89cc-YpNV8xy9EOuOZfmKosho/s0YIck\"",
    "mtime": "2023-05-05T22:08:37.708Z",
    "size": 35276,
    "path": "../public/img/modal/gem-1.png"
  },
  "/img/modal/gem-1@2x.png": {
    "type": "image/png",
    "etag": "\"14595-nmApQf3nEmGkvw6ni9Lj5hk9vPU\"",
    "mtime": "2023-05-05T22:08:37.707Z",
    "size": 83349,
    "path": "../public/img/modal/gem-1@2x.png"
  },
  "/img/modal/gem-2.png": {
    "type": "image/png",
    "etag": "\"920d-up9gRkXOdpvpJ9eG5Rk4b36NHHU\"",
    "mtime": "2023-05-05T22:08:37.698Z",
    "size": 37389,
    "path": "../public/img/modal/gem-2.png"
  },
  "/img/modal/gem-2@2x.png": {
    "type": "image/png",
    "etag": "\"167b8-a1sZf0s1JOyilO2MEJJ5BR7KD/o\"",
    "mtime": "2023-05-05T22:08:37.696Z",
    "size": 92088,
    "path": "../public/img/modal/gem-2@2x.png"
  },
  "/img/modal/gem-3.png": {
    "type": "image/png",
    "etag": "\"9775-ljYkNc07IKZ0lPFSxvatzPfsd/4\"",
    "mtime": "2023-05-05T22:08:37.694Z",
    "size": 38773,
    "path": "../public/img/modal/gem-3.png"
  },
  "/img/modal/gem-3@2x.png": {
    "type": "image/png",
    "etag": "\"16afe-0PjmkEi1XMDDhaFIDOigmnknKHo\"",
    "mtime": "2023-05-05T22:08:37.692Z",
    "size": 92926,
    "path": "../public/img/modal/gem-3@2x.png"
  },
  "/img/modal/gem-4.png": {
    "type": "image/png",
    "etag": "\"9aaf-qG9BW/4yUlqtgPvjqfbuUujGMlg\"",
    "mtime": "2023-05-05T22:08:37.691Z",
    "size": 39599,
    "path": "../public/img/modal/gem-4.png"
  },
  "/img/modal/gem-4@2x.png": {
    "type": "image/png",
    "etag": "\"176c9-KVlKzqrZCjPswc1kcO1ROBG42rc\"",
    "mtime": "2023-05-05T22:08:37.688Z",
    "size": 95945,
    "path": "../public/img/modal/gem-4@2x.png"
  },
  "/img/modal/table-mob.svg": {
    "type": "image/svg+xml",
    "etag": "\"23b4e-woEBXJYUTlJfEXTKyRPxlaxLfAs\"",
    "mtime": "2023-05-05T22:08:37.686Z",
    "size": 146254,
    "path": "../public/img/modal/table-mob.svg"
  },
  "/img/modal/table.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a76f-t3GV8zeIm9B9+Umn4QmclAD4Pqs\"",
    "mtime": "2023-05-05T22:08:37.638Z",
    "size": 173935,
    "path": "../public/img/modal/table.svg"
  },
  "/img/navbar/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1804-3y++sUAKzaCQmjLBz2v0kvESHgc\"",
    "mtime": "2023-05-05T22:08:37.636Z",
    "size": 6148,
    "path": "../public/img/navbar/.DS_Store"
  },
  "/img/navbar/item-1.png": {
    "type": "image/png",
    "etag": "\"7d2b-/h8JVv7ivQcCQWmOoFY7VfRXBMM\"",
    "mtime": "2023-05-05T22:08:37.635Z",
    "size": 32043,
    "path": "../public/img/navbar/item-1.png"
  },
  "/img/navbar/item-2.png": {
    "type": "image/png",
    "etag": "\"7788-ExcoRerJmIgNXMGEbKIyxZZOPTI\"",
    "mtime": "2023-05-05T22:08:37.634Z",
    "size": 30600,
    "path": "../public/img/navbar/item-2.png"
  },
  "/img/navbar/item-3.png": {
    "type": "image/png",
    "etag": "\"78cf-mB3SJcZVPq60m5MEioyYF9MiPu8\"",
    "mtime": "2023-05-05T22:08:37.632Z",
    "size": 30927,
    "path": "../public/img/navbar/item-3.png"
  },
  "/img/navbar/item-4.png": {
    "type": "image/png",
    "etag": "\"6f81-BYmJSI9lyeMvmJtlJmVK6ZxZzS0\"",
    "mtime": "2023-05-05T22:08:37.631Z",
    "size": 28545,
    "path": "../public/img/navbar/item-4.png"
  },
  "/img/product/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1804-yr9Bu6pHdN4w69fqezFZVbEqWIo\"",
    "mtime": "2023-05-05T22:08:37.629Z",
    "size": 6148,
    "path": "../public/img/product/.DS_Store"
  },
  "/img/product/aorta.png": {
    "type": "image/png",
    "etag": "\"789a7-Ewv9FgM93vBjXZbNxdoWs+Zpwms\"",
    "mtime": "2023-05-05T22:08:37.628Z",
    "size": 493991,
    "path": "../public/img/product/aorta.png"
  },
  "/img/product/aorta.webp": {
    "type": "image/webp",
    "etag": "\"9eb2-Qziv6Zjv1se6VW6bB/xWZy+V8oA\"",
    "mtime": "2023-05-05T22:08:37.624Z",
    "size": 40626,
    "path": "../public/img/product/aorta.webp"
  },
  "/img/product/aorta_mob@2x.png": {
    "type": "image/png",
    "etag": "\"20850-mRxWcujUDkX2LXhVxNrsDFPA0AQ\"",
    "mtime": "2023-05-05T22:08:37.623Z",
    "size": 133200,
    "path": "../public/img/product/aorta_mob@2x.png"
  },
  "/img/product/aorta_mob@2x.webp": {
    "type": "image/webp",
    "etag": "\"3b82-aqZ5ALeFGuLljtoHC3LWzth0WzU\"",
    "mtime": "2023-05-05T22:08:37.621Z",
    "size": 15234,
    "path": "../public/img/product/aorta_mob@2x.webp"
  },
  "/img/product/article.jpg": {
    "type": "image/jpeg",
    "etag": "\"12d33-QBuQ8q4dTMxXXSHZykFCfCAk+v0\"",
    "mtime": "2023-05-05T22:08:37.620Z",
    "size": 77107,
    "path": "../public/img/product/article.jpg"
  },
  "/img/product/chronic-1.png": {
    "type": "image/png",
    "etag": "\"4211-48RjVrHjWDl04GjHXKSG4jpQJ2Y\"",
    "mtime": "2023-05-05T22:08:37.618Z",
    "size": 16913,
    "path": "../public/img/product/chronic-1.png"
  },
  "/img/product/chronic-1@2x.png": {
    "type": "image/png",
    "etag": "\"8b8a-d4G4feGWziW5gI3wkb4CRtrso8E\"",
    "mtime": "2023-05-05T22:08:37.617Z",
    "size": 35722,
    "path": "../public/img/product/chronic-1@2x.png"
  },
  "/img/product/chronic-1@2x.webp": {
    "type": "image/webp",
    "etag": "\"269c-CHQJHe5dpFImSPDpruUC1573Acc\"",
    "mtime": "2023-05-05T22:08:37.616Z",
    "size": 9884,
    "path": "../public/img/product/chronic-1@2x.webp"
  },
  "/img/product/chronic-2.png": {
    "type": "image/png",
    "etag": "\"162b-SiB4QLQP3RC+3HF9ZpWFQNoXHco\"",
    "mtime": "2023-05-05T22:08:37.615Z",
    "size": 5675,
    "path": "../public/img/product/chronic-2.png"
  },
  "/img/product/chronic-2@2x.png": {
    "type": "image/png",
    "etag": "\"8269-oHBR5pSXAS35VRua5eNg1S/0vno\"",
    "mtime": "2023-05-05T22:08:37.614Z",
    "size": 33385,
    "path": "../public/img/product/chronic-2@2x.png"
  },
  "/img/product/chronic-2@2x.webp": {
    "type": "image/webp",
    "etag": "\"1ea2-pGerZNc1mWl7kA1a7ytTk7SU6wU\"",
    "mtime": "2023-05-05T22:08:37.613Z",
    "size": 7842,
    "path": "../public/img/product/chronic-2@2x.webp"
  },
  "/img/product/chronic-3.png": {
    "type": "image/png",
    "etag": "\"148c-5Z1KelJA+pYDFmMeoU5c0/WGOfQ\"",
    "mtime": "2023-05-05T22:08:37.612Z",
    "size": 5260,
    "path": "../public/img/product/chronic-3.png"
  },
  "/img/product/chronic-3@2x.png": {
    "type": "image/png",
    "etag": "\"8bb8-AdiibILQ/We6KczzfbKXgOkS/Vo\"",
    "mtime": "2023-05-05T22:08:37.610Z",
    "size": 35768,
    "path": "../public/img/product/chronic-3@2x.png"
  },
  "/img/product/chronic-3@2x.webp": {
    "type": "image/webp",
    "etag": "\"1f4c-6K6CYy+di+tzn+8QlEcsl4lor0g\"",
    "mtime": "2023-05-05T22:08:37.609Z",
    "size": 8012,
    "path": "../public/img/product/chronic-3@2x.webp"
  },
  "/img/product/economy-15.png": {
    "type": "image/png",
    "etag": "\"11c96-29Ky/nL3Nv38prRLZue6on/K78o\"",
    "mtime": "2023-05-05T22:08:37.608Z",
    "size": 72854,
    "path": "../public/img/product/economy-15.png"
  },
  "/img/product/economy-15@2x.png": {
    "type": "image/png",
    "etag": "\"cc45d-5C9AkKJKEztuDghEzHvzxprAvs4\"",
    "mtime": "2023-05-05T22:08:37.603Z",
    "size": 836701,
    "path": "../public/img/product/economy-15@2x.png"
  },
  "/img/product/economy-15@2x.webp": {
    "type": "image/webp",
    "etag": "\"2c264-PUaWGOqLHTzSpHLrwS+1JYdMbiI\"",
    "mtime": "2023-05-05T22:08:37.597Z",
    "size": 180836,
    "path": "../public/img/product/economy-15@2x.webp"
  },
  "/img/product/economy-25-neo.png": {
    "type": "image/png",
    "etag": "\"12e78-IvFQgsMnmSFkwkKvWKs2gHMYF6I\"",
    "mtime": "2023-05-05T22:08:37.595Z",
    "size": 77432,
    "path": "../public/img/product/economy-25-neo.png"
  },
  "/img/product/economy-25-neo@2x.png": {
    "type": "image/png",
    "etag": "\"c6086-T/glWTcQ0yLqkDiqdPydNK1Loyw\"",
    "mtime": "2023-05-05T22:08:37.592Z",
    "size": 811142,
    "path": "../public/img/product/economy-25-neo@2x.png"
  },
  "/img/product/economy-25-neo@2x.webp": {
    "type": "image/webp",
    "etag": "\"2df38-/DoRt6SK+mWpBxdpuWcZHDCmzwA\"",
    "mtime": "2023-05-05T22:08:37.587Z",
    "size": 188216,
    "path": "../public/img/product/economy-25-neo@2x.webp"
  },
  "/img/product/economy-25.png": {
    "type": "image/png",
    "etag": "\"b9776-UCcCvqcsvjHsmHqwhoR5kH2PxKU\"",
    "mtime": "2023-05-05T22:08:37.584Z",
    "size": 759670,
    "path": "../public/img/product/economy-25.png"
  },
  "/img/product/economy-25.webp": {
    "type": "image/webp",
    "etag": "\"2c9a2-/k8JAexnGKBpVcFak91R8k1mwL8\"",
    "mtime": "2023-05-05T22:08:37.567Z",
    "size": 182690,
    "path": "../public/img/product/economy-25.webp"
  },
  "/img/product/economy-two-1.jpg": {
    "type": "image/jpeg",
    "etag": "\"73077-hmYXBw1I3KMw0nQPbByTqNykSU4\"",
    "mtime": "2023-05-05T22:08:37.562Z",
    "size": 471159,
    "path": "../public/img/product/economy-two-1.jpg"
  },
  "/img/product/economy-two-1.webp": {
    "type": "image/webp",
    "etag": "\"5798a-c3/zLzNhs4w21YhIgvcYiQyle90\"",
    "mtime": "2023-05-05T22:08:37.558Z",
    "size": 358794,
    "path": "../public/img/product/economy-two-1.webp"
  },
  "/img/product/economy-two-2.jpg": {
    "type": "image/jpeg",
    "etag": "\"74254-3RuIk8pCTx0oj8XqIIZyEomnpDc\"",
    "mtime": "2023-05-05T22:08:37.546Z",
    "size": 475732,
    "path": "../public/img/product/economy-two-2.jpg"
  },
  "/img/product/economy-two-2.webp": {
    "type": "image/webp",
    "etag": "\"58ca6-iHQpfPh+ZdryiOHtiqcNqGxlRgc\"",
    "mtime": "2023-05-05T22:08:37.528Z",
    "size": 363686,
    "path": "../public/img/product/economy-two-2.webp"
  },
  "/img/product/foots.png": {
    "type": "image/png",
    "etag": "\"28ddd-q0FIZIwIkbSs7CP1wIJToWZ0ETw\"",
    "mtime": "2023-05-05T22:08:37.525Z",
    "size": 167389,
    "path": "../public/img/product/foots.png"
  },
  "/img/product/gel-1.png": {
    "type": "image/png",
    "etag": "\"1016f-PXM1JjuXk/vVQ1wkQu+M8zERcko\"",
    "mtime": "2023-05-05T22:08:37.523Z",
    "size": 65903,
    "path": "../public/img/product/gel-1.png"
  },
  "/img/product/guide-1.svg": {
    "type": "image/svg+xml",
    "etag": "\"51c-lxP/BWulpaFHqxQhv3xOHwsgxrI\"",
    "mtime": "2023-05-05T22:08:37.521Z",
    "size": 1308,
    "path": "../public/img/product/guide-1.svg"
  },
  "/img/product/guide-2.svg": {
    "type": "image/svg+xml",
    "etag": "\"2892-JTtTb7hzOyAvsPZbVqcYDbDQ4c8\"",
    "mtime": "2023-05-05T22:08:37.520Z",
    "size": 10386,
    "path": "../public/img/product/guide-2.svg"
  },
  "/img/product/guide-3.svg": {
    "type": "image/svg+xml",
    "etag": "\"1f82-qwWy9Jln7Z4koWOG+lBocy0uR2c\"",
    "mtime": "2023-05-05T22:08:37.519Z",
    "size": 8066,
    "path": "../public/img/product/guide-3.svg"
  },
  "/img/product/guide-4.svg": {
    "type": "image/svg+xml",
    "etag": "\"613-2px+/f4JmPt1gOi0DzmKnMp+0ac\"",
    "mtime": "2023-05-05T22:08:37.519Z",
    "size": 1555,
    "path": "../public/img/product/guide-4.svg"
  },
  "/img/product/guide-5.svg": {
    "type": "image/svg+xml",
    "etag": "\"5e6-SXyJPV69quUw7EGE1EshSgAb+d4\"",
    "mtime": "2023-05-05T22:08:37.518Z",
    "size": 1510,
    "path": "../public/img/product/guide-5.svg"
  },
  "/img/product/guide-6.svg": {
    "type": "image/svg+xml",
    "etag": "\"7dd-/YGzY8PnYe5zep/MDPKtbUpILNE\"",
    "mtime": "2023-05-05T22:08:37.517Z",
    "size": 2013,
    "path": "../public/img/product/guide-6.svg"
  },
  "/img/product/guide-7.svg": {
    "type": "image/svg+xml",
    "etag": "\"624-Pyn6TwOiwUTsIYjlSqcySiwspaw\"",
    "mtime": "2023-05-05T22:08:37.516Z",
    "size": 1572,
    "path": "../public/img/product/guide-7.svg"
  },
  "/img/product/maternity.png": {
    "type": "image/png",
    "etag": "\"254d1-DVhSZCmqRklFMhojkIDXA70/kxQ\"",
    "mtime": "2023-05-05T22:08:37.515Z",
    "size": 152785,
    "path": "../public/img/product/maternity.png"
  },
  "/img/product/other-caps.png": {
    "type": "image/png",
    "etag": "\"f2b8-6FDI7G2y1euc/b5x6fih4ZGyEAU\"",
    "mtime": "2023-05-05T22:08:37.513Z",
    "size": 62136,
    "path": "../public/img/product/other-caps.png"
  },
  "/img/product/other-gel-1-40.png": {
    "type": "image/png",
    "etag": "\"32c34-ngzmDlAtks+jF7IMGat5y5m029Y\"",
    "mtime": "2023-05-05T22:08:37.511Z",
    "size": 207924,
    "path": "../public/img/product/other-gel-1-40.png"
  },
  "/img/product/other-gel-neo.png": {
    "type": "image/png",
    "etag": "\"33ba0-NNHe2cdVLQHFbBIica7m3rutaig\"",
    "mtime": "2023-05-05T22:08:37.508Z",
    "size": 211872,
    "path": "../public/img/product/other-gel-neo.png"
  },
  "/img/product/other-gel.png": {
    "type": "image/png",
    "etag": "\"e379-HaKJZUXIT12v6H0+MsMghEnGFFE\"",
    "mtime": "2023-05-05T22:08:37.506Z",
    "size": 58233,
    "path": "../public/img/product/other-gel.png"
  },
  "/img/product/other-troxactive.png": {
    "type": "image/png",
    "etag": "\"f6e7-GsJ/SfFoY9OPKpf0TjQVaCvYTx8\"",
    "mtime": "2023-05-05T22:08:37.504Z",
    "size": 63207,
    "path": "../public/img/product/other-troxactive.png"
  },
  "/img/product/p-caps-1.png": {
    "type": "image/png",
    "etag": "\"7d398-meQcoQeMyAF8+QeSJ7iXV0+L8+c\"",
    "mtime": "2023-05-05T22:08:37.502Z",
    "size": 512920,
    "path": "../public/img/product/p-caps-1.png"
  },
  "/img/product/p-caps-1@2x.png": {
    "type": "image/png",
    "etag": "\"14a21e-2PR+p0de4QzpXFUKTVihjNzvvKg\"",
    "mtime": "2023-05-05T22:08:37.495Z",
    "size": 1352222,
    "path": "../public/img/product/p-caps-1@2x.png"
  },
  "/img/product/p-caps-1@2x.webp": {
    "type": "image/webp",
    "etag": "\"3c07a-v/YQxzEJA4ug7rHgZX381qdzABE\"",
    "mtime": "2023-05-05T22:08:37.489Z",
    "size": 245882,
    "path": "../public/img/product/p-caps-1@2x.webp"
  },
  "/img/product/p-caps-2.png": {
    "type": "image/png",
    "etag": "\"7cc27-c8u97LVlIBNvqlItAXcGNG+40TY\"",
    "mtime": "2023-05-05T22:08:37.485Z",
    "size": 511015,
    "path": "../public/img/product/p-caps-2.png"
  },
  "/img/product/p-caps-2@2x.png": {
    "type": "image/png",
    "etag": "\"149eb5-oO1l4CnwdG6EAOMlhJaXVws9axA\"",
    "mtime": "2023-05-05T22:08:37.478Z",
    "size": 1351349,
    "path": "../public/img/product/p-caps-2@2x.png"
  },
  "/img/product/p-caps-2@2x.webp": {
    "type": "image/webp",
    "etag": "\"3bd20-aBddj07VG4acgWZkGe8Wyz5C2k0\"",
    "mtime": "2023-05-05T22:08:37.471Z",
    "size": 245024,
    "path": "../public/img/product/p-caps-2@2x.webp"
  },
  "/img/product/p-gel-2.png": {
    "type": "image/png",
    "etag": "\"7b7ac-IK9prEb7O+0UKLtRbGVGGNoq6lc\"",
    "mtime": "2023-05-05T22:08:37.467Z",
    "size": 505772,
    "path": "../public/img/product/p-gel-2.png"
  },
  "/img/product/p-gel-2@2x.png": {
    "type": "image/png",
    "etag": "\"7b7ac-IK9prEb7O+0UKLtRbGVGGNoq6lc\"",
    "mtime": "2023-05-05T22:08:37.462Z",
    "size": 505772,
    "path": "../public/img/product/p-gel-2@2x.png"
  },
  "/img/product/p-gel-2@2x.webp": {
    "type": "image/webp",
    "etag": "\"7560c-S3EsFsB0gREalREVc3991C2dq2U\"",
    "mtime": "2023-05-05T22:08:37.455Z",
    "size": 480780,
    "path": "../public/img/product/p-gel-2@2x.webp"
  },
  "/img/product/p-neo-1.png": {
    "type": "image/png",
    "etag": "\"8342f-/JkpKRqfY03QiVfiQnFB06x8ZHw\"",
    "mtime": "2023-05-05T22:08:37.449Z",
    "size": 537647,
    "path": "../public/img/product/p-neo-1.png"
  },
  "/img/product/p-neo-1@2x.png": {
    "type": "image/png",
    "etag": "\"1208ae-qUpAleMcsj7CrS2NyZVCsEbCufY\"",
    "mtime": "2023-05-05T22:08:37.443Z",
    "size": 1181870,
    "path": "../public/img/product/p-neo-1@2x.png"
  },
  "/img/product/p-neo-1@2x.webp": {
    "type": "image/webp",
    "etag": "\"3de44-jjPaEAdhjLHQZg27LfJL85nq/3s\"",
    "mtime": "2023-05-05T22:08:37.436Z",
    "size": 253508,
    "path": "../public/img/product/p-neo-1@2x.webp"
  },
  "/img/product/p-neo-2.png": {
    "type": "image/png",
    "etag": "\"80374-uMYfxjk9CqlgDMJrZunnabMuLGs\"",
    "mtime": "2023-05-05T22:08:37.433Z",
    "size": 525172,
    "path": "../public/img/product/p-neo-2.png"
  },
  "/img/product/p-neo-2@2x.png": {
    "type": "image/png",
    "etag": "\"151159-Wx1pFXExt5fb2HzxCLUTX1ttVxg\"",
    "mtime": "2023-05-05T22:08:37.421Z",
    "size": 1380697,
    "path": "../public/img/product/p-neo-2@2x.png"
  },
  "/img/product/p-neo-2@2x.webp": {
    "type": "image/webp",
    "etag": "\"3e0c8-fRp0U1n2h9FQXnnt6j3pHfYoBuc\"",
    "mtime": "2023-05-05T22:08:37.414Z",
    "size": 254152,
    "path": "../public/img/product/p-neo-2@2x.webp"
  },
  "/img/product/p-trox-1.png": {
    "type": "image/png",
    "etag": "\"78e87-MndL3tuuKbP0h1sVD/6SHGi55ps\"",
    "mtime": "2023-05-05T22:08:37.405Z",
    "size": 495239,
    "path": "../public/img/product/p-trox-1.png"
  },
  "/img/product/p-trox-1@2x.png": {
    "type": "image/png",
    "etag": "\"13f197-g8pQKT0H3tBXqiFvlprO+UBS7oc\"",
    "mtime": "2023-05-05T22:08:37.396Z",
    "size": 1307031,
    "path": "../public/img/product/p-trox-1@2x.png"
  },
  "/img/product/p-trox-1@2x.webp": {
    "type": "image/webp",
    "etag": "\"3bcb0-3OgmxelS8b3o8oysPk8R7O+IvTY\"",
    "mtime": "2023-05-05T22:08:37.384Z",
    "size": 244912,
    "path": "../public/img/product/p-trox-1@2x.webp"
  },
  "/img/product/p-trox-2.png": {
    "type": "image/png",
    "etag": "\"75c1c-SajEwp07o0xh2W68s4jZOpphBbg\"",
    "mtime": "2023-05-05T22:08:37.379Z",
    "size": 482332,
    "path": "../public/img/product/p-trox-2.png"
  },
  "/img/product/p-trox-2@2x.png": {
    "type": "image/png",
    "etag": "\"12abdf-ivcp13kE5QcanFtyn4KO2ei0OZM\"",
    "mtime": "2023-05-05T22:08:37.374Z",
    "size": 1223647,
    "path": "../public/img/product/p-trox-2@2x.png"
  },
  "/img/product/p-trox-2@2x.webp": {
    "type": "image/webp",
    "etag": "\"3afcc-Mxv8NIjmam2MtnSsZLYVrNtTTu4\"",
    "mtime": "2023-05-05T22:08:37.364Z",
    "size": 241612,
    "path": "../public/img/product/p-trox-2@2x.webp"
  },
  "/img/product/p-trox-3.png": {
    "type": "image/png",
    "etag": "\"763e9-8P7/Hl/49Ll5RisgFM4nkMt0lus\"",
    "mtime": "2023-05-05T22:08:37.360Z",
    "size": 484329,
    "path": "../public/img/product/p-trox-3.png"
  },
  "/img/product/p-trox-3@2x.png": {
    "type": "image/png",
    "etag": "\"12b9db-tyfEDm5Qd2LBgap/JhZRubD+NF8\"",
    "mtime": "2023-05-05T22:08:37.353Z",
    "size": 1227227,
    "path": "../public/img/product/p-trox-3@2x.png"
  },
  "/img/product/p-trox-3@2x.webp": {
    "type": "image/webp",
    "etag": "\"3a958-0yoBKzazODEYl4DOmYiTITrvoZM\"",
    "mtime": "2023-05-05T22:08:37.345Z",
    "size": 239960,
    "path": "../public/img/product/p-trox-3@2x.webp"
  },
  "/img/product/plus.svg": {
    "type": "image/svg+xml",
    "etag": "\"db-xsjOdwz7E1R/M+Xvf0Xp9C46NO4\"",
    "mtime": "2023-05-05T22:08:37.341Z",
    "size": 219,
    "path": "../public/img/product/plus.svg"
  },
  "/img/product/secret-1.png": {
    "type": "image/png",
    "etag": "\"23dd-t3yXRnzrROiRt5TM2iyTj77qjQ4\"",
    "mtime": "2023-05-05T22:08:37.339Z",
    "size": 9181,
    "path": "../public/img/product/secret-1.png"
  },
  "/img/product/secret-1@2x.png": {
    "type": "image/png",
    "etag": "\"1e9c-wA3JuDF3VfDCY1Jb/HB09lm0w88\"",
    "mtime": "2023-05-05T22:08:37.335Z",
    "size": 7836,
    "path": "../public/img/product/secret-1@2x.png"
  },
  "/img/product/secret-2.png": {
    "type": "image/png",
    "etag": "\"fe1-hEaBPWqcfUDCKxxyNtnBMqHXnmk\"",
    "mtime": "2023-05-05T22:08:37.333Z",
    "size": 4065,
    "path": "../public/img/product/secret-2.png"
  },
  "/img/product/secret-2@2x.png": {
    "type": "image/png",
    "etag": "\"2633-7qdOtFwJ60mviImw1iGGcFibg9k\"",
    "mtime": "2023-05-05T22:08:37.330Z",
    "size": 9779,
    "path": "../public/img/product/secret-2@2x.png"
  },
  "/img/product/secret-3.png": {
    "type": "image/png",
    "etag": "\"150a-36ABbE0AZ18uCYcPIHFRohevQvo\"",
    "mtime": "2023-05-05T22:08:37.300Z",
    "size": 5386,
    "path": "../public/img/product/secret-3.png"
  },
  "/img/product/secret-3@2x.png": {
    "type": "image/png",
    "etag": "\"3638-s4TZTHQlWpg8/b99CeaIQdRzjms\"",
    "mtime": "2023-05-05T22:08:37.295Z",
    "size": 13880,
    "path": "../public/img/product/secret-3@2x.png"
  },
  "/img/product/secret-4.png": {
    "type": "image/png",
    "etag": "\"1075-SDzeP1IdVqUwzn694JZ/r5+P+z8\"",
    "mtime": "2023-05-05T22:08:37.294Z",
    "size": 4213,
    "path": "../public/img/product/secret-4.png"
  },
  "/img/product/secret-4@2x.png": {
    "type": "image/png",
    "etag": "\"2a70-VaJukTy9auWreBj4H2O0NrsFoVw\"",
    "mtime": "2023-05-05T22:08:37.293Z",
    "size": 10864,
    "path": "../public/img/product/secret-4@2x.png"
  },
  "/img/product/secret-5.png": {
    "type": "image/png",
    "etag": "\"11e3-JWFUcobB+vnUIVZCT65f1qr0hso\"",
    "mtime": "2023-05-05T22:08:37.291Z",
    "size": 4579,
    "path": "../public/img/product/secret-5.png"
  },
  "/img/product/secret-5@2x.png": {
    "type": "image/png",
    "etag": "\"323b-z4tgTbJZklzchvucvzXcur+pets\"",
    "mtime": "2023-05-05T22:08:37.289Z",
    "size": 12859,
    "path": "../public/img/product/secret-5@2x.png"
  },
  "/img/product/secret-6.png": {
    "type": "image/png",
    "etag": "\"e0a-0eWp8Q+vw9FwPnwqdO4Qx97H+xU\"",
    "mtime": "2023-05-05T22:08:37.289Z",
    "size": 3594,
    "path": "../public/img/product/secret-6.png"
  },
  "/img/product/secret-6@2x.png": {
    "type": "image/png",
    "etag": "\"20f1-b3enME2khHcXpXlInNFjhWq9bVs\"",
    "mtime": "2023-05-05T22:08:37.288Z",
    "size": 8433,
    "path": "../public/img/product/secret-6@2x.png"
  },
  "/img/product/secret-7.png": {
    "type": "image/png",
    "etag": "\"c9d-hYil4sis1QcAwYTbqfaYSNLCTp0\"",
    "mtime": "2023-05-05T22:08:37.286Z",
    "size": 3229,
    "path": "../public/img/product/secret-7.png"
  },
  "/img/product/secret-7@2x.png": {
    "type": "image/png",
    "etag": "\"1a45-xoQ/F9aHQgztxEENa3gsPNhCIhk\"",
    "mtime": "2023-05-05T22:08:37.285Z",
    "size": 6725,
    "path": "../public/img/product/secret-7@2x.png"
  },
  "/img/product/secret-8.png": {
    "type": "image/png",
    "etag": "\"c5f-GdiLUPnG3kTHyKAFycWoT3vheeI\"",
    "mtime": "2023-05-05T22:08:37.284Z",
    "size": 3167,
    "path": "../public/img/product/secret-8.png"
  },
  "/img/product/secret-8@2x.png": {
    "type": "image/png",
    "etag": "\"1df4-RZAzbRzl98stvKPLpyJcWmQlxW4\"",
    "mtime": "2023-05-05T22:08:37.283Z",
    "size": 7668,
    "path": "../public/img/product/secret-8@2x.png"
  },
  "/img/product/secret-9.png": {
    "type": "image/png",
    "etag": "\"a31-E/PYQqMYlrkTt4LiMn5v/RlduTI\"",
    "mtime": "2023-05-05T22:08:37.282Z",
    "size": 2609,
    "path": "../public/img/product/secret-9.png"
  },
  "/img/product/secret-9@2x.png": {
    "type": "image/png",
    "etag": "\"1602-fu8WGbpxOg1ejDENNHyFVee1lAk\"",
    "mtime": "2023-05-05T22:08:37.280Z",
    "size": 5634,
    "path": "../public/img/product/secret-9@2x.png"
  },
  "/img/product/secret_fon.jpg": {
    "type": "image/jpeg",
    "etag": "\"5690-g+7j2GsxGeLCXdQNwm2G7SttTPk\"",
    "mtime": "2023-05-05T22:08:37.279Z",
    "size": 22160,
    "path": "../public/img/product/secret_fon.jpg"
  },
  "/img/product/slider_fon.png": {
    "type": "image/png",
    "etag": "\"18365-ipR976mHyQ6ZGrZMd/2YdTBgHy0\"",
    "mtime": "2023-05-05T22:08:37.278Z",
    "size": 99173,
    "path": "../public/img/product/slider_fon.png"
  },
  "/img/product/step-1.svg": {
    "type": "image/svg+xml",
    "etag": "\"6ba-sBOG1zITHTqp31K5eHLVgxiKl1s\"",
    "mtime": "2023-05-05T22:08:37.276Z",
    "size": 1722,
    "path": "../public/img/product/step-1.svg"
  },
  "/img/product/step-2.svg": {
    "type": "image/svg+xml",
    "etag": "\"bd1-KpJPbY7UVezKPtLaZHd+B+yk5YY\"",
    "mtime": "2023-05-05T22:08:37.275Z",
    "size": 3025,
    "path": "../public/img/product/step-2.svg"
  },
  "/img/product/step-3.svg": {
    "type": "image/svg+xml",
    "etag": "\"adc-WUtvdWX8EZ4fNLyVSy9Ro9RumcY\"",
    "mtime": "2023-05-05T22:08:37.271Z",
    "size": 2780,
    "path": "../public/img/product/step-3.svg"
  },
  "/img/product/step-4.svg": {
    "type": "image/svg+xml",
    "etag": "\"5f9-a/cXOkGPR/pXEOolMRcMtJ7oT7I\"",
    "mtime": "2023-05-05T22:08:37.270Z",
    "size": 1529,
    "path": "../public/img/product/step-4.svg"
  },
  "/img/product/swiper-nav-product.svg": {
    "type": "image/svg+xml",
    "etag": "\"b6-/hui4sOJ3jbGeGmCrXLIxg97kUg\"",
    "mtime": "2023-05-05T22:08:37.265Z",
    "size": 182,
    "path": "../public/img/product/swiper-nav-product.svg"
  },
  "/img/product/symptom-10.png": {
    "type": "image/png",
    "etag": "\"3299-widrG11/66suDkO461W4uKs8UK8\"",
    "mtime": "2023-05-05T22:08:37.223Z",
    "size": 12953,
    "path": "../public/img/product/symptom-10.png"
  },
  "/img/product/symptom-10@2x.png": {
    "type": "image/png",
    "etag": "\"7b13-4wddTkZcE7T0gnb7qKGZp+dBn20\"",
    "mtime": "2023-05-05T22:08:37.192Z",
    "size": 31507,
    "path": "../public/img/product/symptom-10@2x.png"
  },
  "/img/product/symptom-10@2x.webp": {
    "type": "image/webp",
    "etag": "\"183c-WDe0snJIoeKPGhq4KCQrp/S8Ujc\"",
    "mtime": "2023-05-05T22:08:37.174Z",
    "size": 6204,
    "path": "../public/img/product/symptom-10@2x.webp"
  },
  "/img/product/symptom-11.png": {
    "type": "image/png",
    "etag": "\"34bd-0yBH8KEYwS7JU50VVKvaJvWkfvM\"",
    "mtime": "2023-05-05T22:08:37.157Z",
    "size": 13501,
    "path": "../public/img/product/symptom-11.png"
  },
  "/img/product/symptom-11@2x.png": {
    "type": "image/png",
    "etag": "\"7c4f-ouKgRQaTUtY6mI1eoJZei9xEKb4\"",
    "mtime": "2023-05-05T22:08:37.150Z",
    "size": 31823,
    "path": "../public/img/product/symptom-11@2x.png"
  },
  "/img/product/symptom-11@2x.webp": {
    "type": "image/webp",
    "etag": "\"174c-9BZ2WuehB7DxxlhLD5Un3jsDgt8\"",
    "mtime": "2023-05-05T22:08:37.145Z",
    "size": 5964,
    "path": "../public/img/product/symptom-11@2x.webp"
  },
  "/img/product/symptom-2.png": {
    "type": "image/png",
    "etag": "\"3601-kelkfN2+01HPwHVpoY064pogXKc\"",
    "mtime": "2023-05-05T22:08:37.143Z",
    "size": 13825,
    "path": "../public/img/product/symptom-2.png"
  },
  "/img/product/symptom-2@2x.png": {
    "type": "image/png",
    "etag": "\"9233-MnVY8CvGOG5M9G/Pp8ZrOICWzZ4\"",
    "mtime": "2023-05-05T22:08:37.142Z",
    "size": 37427,
    "path": "../public/img/product/symptom-2@2x.png"
  },
  "/img/product/symptom-2@2x.webp": {
    "type": "image/webp",
    "etag": "\"189e-GTBlYi31mI1s8rVmfqzd4rMUJII\"",
    "mtime": "2023-05-05T22:08:37.140Z",
    "size": 6302,
    "path": "../public/img/product/symptom-2@2x.webp"
  },
  "/img/product/symptom-3.png": {
    "type": "image/png",
    "etag": "\"3639-4qT+06RX7uOF9iZa7h6GxsMXK0Y\"",
    "mtime": "2023-05-05T22:08:37.139Z",
    "size": 13881,
    "path": "../public/img/product/symptom-3.png"
  },
  "/img/product/symptom-3@2x.png": {
    "type": "image/png",
    "etag": "\"8c8d-BIkPbJ3i4JOKqK/FCwE8jfG8ET8\"",
    "mtime": "2023-05-05T22:08:37.138Z",
    "size": 35981,
    "path": "../public/img/product/symptom-3@2x.png"
  },
  "/img/product/symptom-3@2x.webp": {
    "type": "image/webp",
    "etag": "\"19a6-HTu93G8RT0gENc6hMkscIn9BkMM\"",
    "mtime": "2023-05-05T22:08:37.137Z",
    "size": 6566,
    "path": "../public/img/product/symptom-3@2x.webp"
  },
  "/img/product/symptom-4.png": {
    "type": "image/png",
    "etag": "\"32cd-+8eDW/O1fwtw9k6A4Cj+nLpxE54\"",
    "mtime": "2023-05-05T22:08:37.136Z",
    "size": 13005,
    "path": "../public/img/product/symptom-4.png"
  },
  "/img/product/symptom-4@2x.png": {
    "type": "image/png",
    "etag": "\"843c-P8SmVrzHCqj3BDh+D0QXvKPNwyQ\"",
    "mtime": "2023-05-05T22:08:37.132Z",
    "size": 33852,
    "path": "../public/img/product/symptom-4@2x.png"
  },
  "/img/product/symptom-4@2x.webp": {
    "type": "image/webp",
    "etag": "\"1678-1OYtBRAxMeQ3ARjUG7nyS5sKK10\"",
    "mtime": "2023-05-05T22:08:37.129Z",
    "size": 5752,
    "path": "../public/img/product/symptom-4@2x.webp"
  },
  "/img/product/symptom-5.png": {
    "type": "image/png",
    "etag": "\"327a-FbDn3GGkRYnyg176eEdooaAZAUY\"",
    "mtime": "2023-05-05T22:08:37.128Z",
    "size": 12922,
    "path": "../public/img/product/symptom-5.png"
  },
  "/img/product/symptom-5@2x.png": {
    "type": "image/png",
    "etag": "\"82db-bQTmbvlnjZmUymJ6IR/OOrNC1+U\"",
    "mtime": "2023-05-05T22:08:37.126Z",
    "size": 33499,
    "path": "../public/img/product/symptom-5@2x.png"
  },
  "/img/product/symptom-5@2x.webp": {
    "type": "image/webp",
    "etag": "\"15c2-Vt3Ej52oVY5xkeo6KPttxXSlEoE\"",
    "mtime": "2023-05-05T22:08:37.125Z",
    "size": 5570,
    "path": "../public/img/product/symptom-5@2x.webp"
  },
  "/img/product/symptom-6.png": {
    "type": "image/png",
    "etag": "\"31f5-6A1+npkZoqcKv8Q4mtk+/PXb7sY\"",
    "mtime": "2023-05-05T22:08:37.124Z",
    "size": 12789,
    "path": "../public/img/product/symptom-6.png"
  },
  "/img/product/symptom-6@2x.png": {
    "type": "image/png",
    "etag": "\"4aae-IY43fM7Z2vcIT5+9Vu3W8t25KqM\"",
    "mtime": "2023-05-05T22:08:37.123Z",
    "size": 19118,
    "path": "../public/img/product/symptom-6@2x.png"
  },
  "/img/product/symptom-6@2x.webp": {
    "type": "image/webp",
    "etag": "\"1262-dxU9X/6Kdxyx0DEayvZjBwlS10I\"",
    "mtime": "2023-05-05T22:08:37.123Z",
    "size": 4706,
    "path": "../public/img/product/symptom-6@2x.webp"
  },
  "/img/product/symptom-7.png": {
    "type": "image/png",
    "etag": "\"3694-yqEKE/d9e/1ggirAMOCoE7WLF1o\"",
    "mtime": "2023-05-05T22:08:37.121Z",
    "size": 13972,
    "path": "../public/img/product/symptom-7.png"
  },
  "/img/product/symptom-7@2x.png": {
    "type": "image/png",
    "etag": "\"84d3-Y1vyda6QbmOAbUklIgbzP2sduns\"",
    "mtime": "2023-05-05T22:08:37.120Z",
    "size": 34003,
    "path": "../public/img/product/symptom-7@2x.png"
  },
  "/img/product/symptom-7@2x.webp": {
    "type": "image/webp",
    "etag": "\"18c4-I7kHS9R2CPXddH0ueEfmbQvWKno\"",
    "mtime": "2023-05-05T22:08:37.119Z",
    "size": 6340,
    "path": "../public/img/product/symptom-7@2x.webp"
  },
  "/img/product/symptom-8.png": {
    "type": "image/png",
    "etag": "\"37b2-Q2kL7Ez/4qoreVpE2T0ISlJh2Nk\"",
    "mtime": "2023-05-05T22:08:37.117Z",
    "size": 14258,
    "path": "../public/img/product/symptom-8.png"
  },
  "/img/product/symptom-8@2x.png": {
    "type": "image/png",
    "etag": "\"86a1-06ygT28Ub7s1bwPvOXQ4xw1KRwM\"",
    "mtime": "2023-05-05T22:08:37.114Z",
    "size": 34465,
    "path": "../public/img/product/symptom-8@2x.png"
  },
  "/img/product/symptom-8@2x.webp": {
    "type": "image/webp",
    "etag": "\"19a8-jf5MXJUEq3aTn2MVQgf4+wYCy8U\"",
    "mtime": "2023-05-05T22:08:37.112Z",
    "size": 6568,
    "path": "../public/img/product/symptom-8@2x.webp"
  },
  "/img/product/symptom-9.png": {
    "type": "image/png",
    "etag": "\"3716-MBEVPItuR71qq1QEQiae6SYR2zQ\"",
    "mtime": "2023-05-05T22:08:37.111Z",
    "size": 14102,
    "path": "../public/img/product/symptom-9.png"
  },
  "/img/product/symptom-9@2x.png": {
    "type": "image/png",
    "etag": "\"8f8b-rC1RXPdMyGDtYdKVa3ejU1oXSQg\"",
    "mtime": "2023-05-05T22:08:37.109Z",
    "size": 36747,
    "path": "../public/img/product/symptom-9@2x.png"
  },
  "/img/product/symptom-9@2x.webp": {
    "type": "image/webp",
    "etag": "\"1a84-F0rvlVFLLfUsqiKAWmbhCe3c5AU\"",
    "mtime": "2023-05-05T22:08:37.107Z",
    "size": 6788,
    "path": "../public/img/product/symptom-9@2x.webp"
  },
  "/img/product/symptom-case-1.png": {
    "type": "image/png",
    "etag": "\"34d8-JfG+gLf/RybOuRJl5zHBWJEKaOI\"",
    "mtime": "2023-05-05T22:08:37.106Z",
    "size": 13528,
    "path": "../public/img/product/symptom-case-1.png"
  },
  "/img/product/symptom-case-1@2x.png": {
    "type": "image/png",
    "etag": "\"6686-USZi6cdh5JXxv3PZ718r93MJK8M\"",
    "mtime": "2023-05-05T22:08:37.104Z",
    "size": 26246,
    "path": "../public/img/product/symptom-case-1@2x.png"
  },
  "/img/product/symptom-case-1@2x.webp": {
    "type": "image/webp",
    "etag": "\"16a8-wlDUxHqmcOqtOMxYAwYpBSs1fc4\"",
    "mtime": "2023-05-05T22:08:37.103Z",
    "size": 5800,
    "path": "../public/img/product/symptom-case-1@2x.webp"
  },
  "/img/product/symptom-case-2.png": {
    "type": "image/png",
    "etag": "\"3556-F6kq2L+dHjWxPKJmiGoxjKe+Lpk\"",
    "mtime": "2023-05-05T22:08:37.099Z",
    "size": 13654,
    "path": "../public/img/product/symptom-case-2.png"
  },
  "/img/product/symptom-case-2@2x.png": {
    "type": "image/png",
    "etag": "\"8a7d-bIMz6/Qlo2vxOFNxHZf4RR1yswk\"",
    "mtime": "2023-05-05T22:08:37.095Z",
    "size": 35453,
    "path": "../public/img/product/symptom-case-2@2x.png"
  },
  "/img/product/symptom-case-2@2x.webp": {
    "type": "image/webp",
    "etag": "\"16fa-0FBezsuO9V1B9ODNUK6X2+ukRf8\"",
    "mtime": "2023-05-05T22:08:37.094Z",
    "size": 5882,
    "path": "../public/img/product/symptom-case-2@2x.webp"
  },
  "/img/product/symptom-case-3.png": {
    "type": "image/png",
    "etag": "\"31c5-XD7nkcL7m0qG93bv9JTnBBpTnOs\"",
    "mtime": "2023-05-05T22:08:37.093Z",
    "size": 12741,
    "path": "../public/img/product/symptom-case-3.png"
  },
  "/img/product/symptom-case-3@2x.png": {
    "type": "image/png",
    "etag": "\"5466-hFjlz7oU7nJDcDtVuQOnhWOp6HY\"",
    "mtime": "2023-05-05T22:08:37.092Z",
    "size": 21606,
    "path": "../public/img/product/symptom-case-3@2x.png"
  },
  "/img/product/symptom-case-3@2x.webp": {
    "type": "image/webp",
    "etag": "\"1826-fCTR8uSQ6HBITcmunVltp29SuiE\"",
    "mtime": "2023-05-05T22:08:37.090Z",
    "size": 6182,
    "path": "../public/img/product/symptom-case-3@2x.webp"
  },
  "/img/product/symptom-case-4.png": {
    "type": "image/png",
    "etag": "\"3081-6UsmSKBq86RODEWOT2f3M1tt1dI\"",
    "mtime": "2023-05-05T22:08:37.089Z",
    "size": 12417,
    "path": "../public/img/product/symptom-case-4.png"
  },
  "/img/product/symptom-case-4@2x.png": {
    "type": "image/png",
    "etag": "\"70f9-iBNi+ckIfeO9nGBImT0+AeFdFmY\"",
    "mtime": "2023-05-05T22:08:37.087Z",
    "size": 28921,
    "path": "../public/img/product/symptom-case-4@2x.png"
  },
  "/img/product/symptom-case-4@2x.webp": {
    "type": "image/webp",
    "etag": "\"1656-38ItLnckynR/VDovrOvSg/ouaUo\"",
    "mtime": "2023-05-05T22:08:37.086Z",
    "size": 5718,
    "path": "../public/img/product/symptom-case-4@2x.webp"
  },
  "/img/product/symptom-case-5.png": {
    "type": "image/png",
    "etag": "\"2e31-pWZB68tfEsQavK4gIMctuDhAWHM\"",
    "mtime": "2023-05-05T22:08:37.077Z",
    "size": 11825,
    "path": "../public/img/product/symptom-case-5.png"
  },
  "/img/product/symptom-case-5@2x.png": {
    "type": "image/png",
    "etag": "\"55cc-lTtahnM+E063iiKsObYUgMbPyyw\"",
    "mtime": "2023-05-05T22:08:37.076Z",
    "size": 21964,
    "path": "../public/img/product/symptom-case-5@2x.png"
  },
  "/img/product/symptom-case-5@2x.webp": {
    "type": "image/webp",
    "etag": "\"14d0-wSuRK32HMuivsF3bVoXok9O5EtU\"",
    "mtime": "2023-05-05T22:08:37.074Z",
    "size": 5328,
    "path": "../public/img/product/symptom-case-5@2x.webp"
  },
  "/img/product/symptom-case-6.png": {
    "type": "image/png",
    "etag": "\"3157-CBO6ZY2jxgd5VXfe5ixSy6rND7w\"",
    "mtime": "2023-05-05T22:08:37.073Z",
    "size": 12631,
    "path": "../public/img/product/symptom-case-6.png"
  },
  "/img/product/symptom-case-6@2x.png": {
    "type": "image/png",
    "etag": "\"6c2a-nZ2lgAFIffGj2wT6cwclZT0VzLo\"",
    "mtime": "2023-05-05T22:08:37.071Z",
    "size": 27690,
    "path": "../public/img/product/symptom-case-6@2x.png"
  },
  "/img/product/symptom-case-6@2x.webp": {
    "type": "image/webp",
    "etag": "\"1672-ku1h3nZbnwtaeKWg3PP6h1TD+no\"",
    "mtime": "2023-05-05T22:08:37.070Z",
    "size": 5746,
    "path": "../public/img/product/symptom-case-6@2x.webp"
  },
  "/img/product/symptom.png": {
    "type": "image/png",
    "etag": "\"8905-ColnDJbVvNH27hLSC0eteczs4po\"",
    "mtime": "2023-05-05T22:08:37.069Z",
    "size": 35077,
    "path": "../public/img/product/symptom.png"
  },
  "/img/product/symptom@2x.png": {
    "type": "image/png",
    "etag": "\"8905-ColnDJbVvNH27hLSC0eteczs4po\"",
    "mtime": "2023-05-05T22:08:37.066Z",
    "size": 35077,
    "path": "../public/img/product/symptom@2x.png"
  },
  "/img/product/symptom@2x.webp": {
    "type": "image/webp",
    "etag": "\"1728-QNv/DN7Uv4zgftJbHqKkmwiuA5U\"",
    "mtime": "2023-05-05T22:08:37.062Z",
    "size": 5928,
    "path": "../public/img/product/symptom@2x.webp"
  },
  "/img/product/symptoms-caps.png": {
    "type": "image/png",
    "etag": "\"3f192-xlyHHtzDIEj8kE68Y2ux96Y8NIU\"",
    "mtime": "2023-05-05T22:08:37.060Z",
    "size": 258450,
    "path": "../public/img/product/symptoms-caps.png"
  },
  "/img/product/symptoms-caps@2x.png": {
    "type": "image/png",
    "etag": "\"dd6fe-pfAUWG1rQD4QA/SpN7VuHk8YuGQ\"",
    "mtime": "2023-05-05T22:08:37.055Z",
    "size": 907006,
    "path": "../public/img/product/symptoms-caps@2x.png"
  },
  "/img/product/symptoms-caps@2x.webp": {
    "type": "image/webp",
    "etag": "\"448a2-QLTUzI5ipSxsJnzJZQHR+MdOLQo\"",
    "mtime": "2023-05-05T22:08:37.049Z",
    "size": 280738,
    "path": "../public/img/product/symptoms-caps@2x.webp"
  },
  "/img/product/symptoms-gel.png": {
    "type": "image/png",
    "etag": "\"5537b-Ag0RbomEyGqolKzRDMgsws6MN4U\"",
    "mtime": "2023-05-05T22:08:37.044Z",
    "size": 349051,
    "path": "../public/img/product/symptoms-gel.png"
  },
  "/img/product/symptoms-gel@2x.png": {
    "type": "image/png",
    "etag": "\"1184fb-Lhn4ERH67XIZ0C75LuGf23SLSLA\"",
    "mtime": "2023-05-05T22:08:37.034Z",
    "size": 1148155,
    "path": "../public/img/product/symptoms-gel@2x.png"
  },
  "/img/product/symptoms-gel@2x.webp": {
    "type": "image/webp",
    "etag": "\"4879e-kT3MSgq19vaJ/nR+lQHICpmbgVE\"",
    "mtime": "2023-05-05T22:08:37.010Z",
    "size": 296862,
    "path": "../public/img/product/symptoms-gel@2x.webp"
  },
  "/img/product/symptoms-hemo.png": {
    "type": "image/png",
    "etag": "\"3ef26-TT+FV5PbTcrpvf+1KgCjSGCu48I\"",
    "mtime": "2023-05-05T22:08:37.007Z",
    "size": 257830,
    "path": "../public/img/product/symptoms-hemo.png"
  },
  "/img/product/symptoms-hemo@2x.png": {
    "type": "image/png",
    "etag": "\"ceaf8-byZ4cskcxpBcuOhMROqDGEWdMTc\"",
    "mtime": "2023-05-05T22:08:37.004Z",
    "size": 846584,
    "path": "../public/img/product/symptoms-hemo@2x.png"
  },
  "/img/product/symptoms-hemo@2x.webp": {
    "type": "image/webp",
    "etag": "\"44722-+EE0MAlV3yRimUetqV18XTznFdU\"",
    "mtime": "2023-05-05T22:08:36.994Z",
    "size": 280354,
    "path": "../public/img/product/symptoms-hemo@2x.webp"
  },
  "/img/product/symptoms-neo.png": {
    "type": "image/png",
    "etag": "\"558b7-w6nPZJUKKCBdRoBVgzZR1NbWsBc\"",
    "mtime": "2023-05-05T22:08:36.991Z",
    "size": 350391,
    "path": "../public/img/product/symptoms-neo.png"
  },
  "/img/product/symptoms-neo@2x.png": {
    "type": "image/png",
    "etag": "\"12187d-nXNzrfxnSJggpNok20R+eqtks1A\"",
    "mtime": "2023-05-05T22:08:36.985Z",
    "size": 1185917,
    "path": "../public/img/product/symptoms-neo@2x.png"
  },
  "/img/product/symptoms-neo@2x.webp": {
    "type": "image/webp",
    "etag": "\"48afc-63ZLehXDL7sMulLa5uoYoLr75KU\"",
    "mtime": "2023-05-05T22:08:36.975Z",
    "size": 297724,
    "path": "../public/img/product/symptoms-neo@2x.webp"
  },
  "/img/product/symptoms-trox.png": {
    "type": "image/png",
    "etag": "\"40dde-+PuSWTSUU/SadxZ/SOJ5lyAv0ds\"",
    "mtime": "2023-05-05T22:08:36.972Z",
    "size": 265694,
    "path": "../public/img/product/symptoms-trox.png"
  },
  "/img/product/symptoms-trox@2x.png": {
    "type": "image/png",
    "etag": "\"e2418-pISAmEfAmeIrMfxAvp5UnI29B04\"",
    "mtime": "2023-05-05T22:08:36.969Z",
    "size": 926744,
    "path": "../public/img/product/symptoms-trox@2x.png"
  },
  "/img/product/symptoms-trox@2x.webp": {
    "type": "image/webp",
    "etag": "\"463d6-HANUi6vU9WtzlEqJhc0CkjAEWGY\"",
    "mtime": "2023-05-05T22:08:36.960Z",
    "size": 287702,
    "path": "../public/img/product/symptoms-trox@2x.webp"
  },
  "/img/product/symptoms-varikoz.png": {
    "type": "image/png",
    "etag": "\"4dbc2-bTY1Mp9nXiL4FpTw6HzHK9DrWxc\"",
    "mtime": "2023-05-05T22:08:36.957Z",
    "size": 318402,
    "path": "../public/img/product/symptoms-varikoz.png"
  },
  "/img/product/symptoms-varikoz@2x.png": {
    "type": "image/png",
    "etag": "\"10cc96-2N+O04KZZ1GnaCJKLiCh0l7A6Sc\"",
    "mtime": "2023-05-05T22:08:36.953Z",
    "size": 1100950,
    "path": "../public/img/product/symptoms-varikoz@2x.png"
  },
  "/img/product/symptoms-varikoz@2x.webp": {
    "type": "image/webp",
    "etag": "\"4714a-9x3IjXdi/hwM4gWpq0xDDH2OY6k\"",
    "mtime": "2023-05-05T22:08:36.942Z",
    "size": 291146,
    "path": "../public/img/product/symptoms-varikoz@2x.webp"
  },
  "/img/product/test.png": {
    "type": "image/png",
    "etag": "\"47686-+JgI3bObBa7BXI5HvET1FBj1qGI\"",
    "mtime": "2023-05-05T22:08:36.932Z",
    "size": 292486,
    "path": "../public/img/product/test.png"
  },
  "/img/product/test@2x.png": {
    "type": "image/png",
    "etag": "\"14f5fe-spnlwixPVFcR/evldKWZxhzO2N4\"",
    "mtime": "2023-05-05T22:08:36.925Z",
    "size": 1373694,
    "path": "../public/img/product/test@2x.png"
  },
  "/img/product/test@2x.webp": {
    "type": "image/webp",
    "etag": "\"3d0fa-WSIV/kLKkVpqK7IMKhnfRmaFlWE\"",
    "mtime": "2023-05-05T22:08:36.917Z",
    "size": 250106,
    "path": "../public/img/product/test@2x.webp"
  },
  "/img/product/veni.png": {
    "type": "image/png",
    "etag": "\"77a58-O0oLcbq1p0eqkzzb248qeumNpOY\"",
    "mtime": "2023-05-05T22:08:36.911Z",
    "size": 490072,
    "path": "../public/img/product/veni.png"
  },
  "/img/product/veni.webp": {
    "type": "image/webp",
    "etag": "\"7f50-wvKy1IBFf7oQWdu582vX2ORUYQ8\"",
    "mtime": "2023-05-05T22:08:36.907Z",
    "size": 32592,
    "path": "../public/img/product/veni.webp"
  }
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _f4b49z = eventHandler((event) => {
  if (event.node.req.method && !METHODS.has(event.node.req.method)) {
    return;
  }
  let id = decodeURIComponent(
    withLeadingSlash(
      withoutTrailingSlash(parseURL(event.node.req.url).pathname)
    )
  );
  let asset;
  const encodingHeader = String(
    event.node.req.headers["accept-encoding"] || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    event.node.res.setHeader("Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.node.res.removeHeader("cache-control");
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = event.node.req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    event.node.res.statusCode = 304;
    event.node.res.end();
    return;
  }
  const ifModifiedSinceH = event.node.req.headers["if-modified-since"];
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.node.res.statusCode = 304;
    event.node.res.end();
    return;
  }
  if (asset.type && !event.node.res.getHeader("Content-Type")) {
    event.node.res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag && !event.node.res.getHeader("ETag")) {
    event.node.res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime && !event.node.res.getHeader("Last-Modified")) {
    event.node.res.setHeader("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.node.res.getHeader("Content-Encoding")) {
    event.node.res.setHeader("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.node.res.getHeader("Content-Length")) {
    event.node.res.setHeader("Content-Length", asset.size);
  }
  return readAsset(id);
});

const _lazy_y6dIzm = () => import('../handlers/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _f4b49z, lazy: false, middleware: true, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_y6dIzm, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_y6dIzm, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(false),
    onError: errorHandler
  });
  const router = createRouter$1();
  h3App.use(createRouteRulesHandler());
  const localCall = createCall(toNodeListener(h3App));
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({
    fetch: localFetch,
    Headers,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(
    eventHandler((event) => {
      const envContext = event.node.req.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: $fetch });
    })
  );
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const s = server.listen(port, host, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const i = s.address();
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${i.family === "IPv6" ? `[${i.address}]` : i.address}:${i.port}${baseURL}`;
  console.log(`Listening ${url}`);
});
{
  process.on(
    "unhandledRejection",
    (err) => console.error("[nitro] [dev] [unhandledRejection] " + err)
  );
  process.on(
    "uncaughtException",
    (err) => console.error("[nitro] [dev] [uncaughtException] " + err)
  );
}
const nodeServer = {};

export { useRuntimeConfig as a, getRouteRules as g, nodeServer as n, useNitroApp as u };
//# sourceMappingURL=node-server.mjs.map
