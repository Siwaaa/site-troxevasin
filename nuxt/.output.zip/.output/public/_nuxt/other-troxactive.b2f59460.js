import"./entry.7fba306a.js";const o=""+globalThis.__publicAssetsURL("img/product/other-troxactive.png");export{o as _};
