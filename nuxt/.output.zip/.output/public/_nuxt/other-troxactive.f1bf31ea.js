import"./entry.910d3bd0.js";const o=""+globalThis.__publicAssetsURL("img/product/other-troxactive.png");export{o as _};
