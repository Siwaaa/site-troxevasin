import"./entry.eb3e4f68.js";const o=""+globalThis.__publicAssetsURL("img/product/other-troxactive.png");export{o as _};
