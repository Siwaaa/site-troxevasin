import"./entry.eb3e4f68.js";const e=""+globalThis.__publicAssetsURL("img/case/header-1.png"),a=""+globalThis.__publicAssetsURL("img/case/header-1@2x.webp");export{e as _,a};
