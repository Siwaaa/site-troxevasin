import"./entry.910d3bd0.js";const e=""+globalThis.__publicAssetsURL("img/case/header-1.png"),a=""+globalThis.__publicAssetsURL("img/case/header-1@2x.webp");export{e as _,a};
