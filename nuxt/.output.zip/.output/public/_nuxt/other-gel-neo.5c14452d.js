import"./entry.910d3bd0.js";const s=""+globalThis.__publicAssetsURL("img/product/other-gel-neo.png");export{s as _};
