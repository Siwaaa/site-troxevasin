import"./entry.910d3bd0.js";const o=""+globalThis.__publicAssetsURL("img/product/symptom-8.png"),p=""+globalThis.__publicAssetsURL("img/product/symptom-8@2x.webp");export{o as _,p as a};
