import"./entry.430943a1.js";const o=""+globalThis.__publicAssetsURL("img/product/other-troxactive.png");export{o as _};
