import"./entry.430943a1.js";const o=""+globalThis.__publicAssetsURL("img/product/symptom-8.png"),p=""+globalThis.__publicAssetsURL("img/product/symptom-8@2x.webp");export{o as _,p as a};
